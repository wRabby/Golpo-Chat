import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Firebase settings are in res/values/firebase.xml (the same values the google-services plugin would make).

android {
    namespace = "com.mobiletips.golpo"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mobiletips.golpo"
        minSdk = 24
        targetSdk = 36
        versionCode = 100 + (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0)
        versionName = "1.6"
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug-fixed.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        create("release") {
            storeFile = file("upload.jks")
            storePassword = System.getenv("UPLOAD_PASSWORD") ?: ""
            keyAlias = "upload"
            keyPassword = System.getenv("UPLOAD_PASSWORD") ?: ""
        }
    }

    buildTypes {
        release {
            signingConfig = if (System.getenv("UPLOAD_PASSWORD").isNullOrEmpty()) null else signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures { compose = true; buildConfig = true }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.06.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.exifinterface:exifinterface:1.4.1")

    implementation(platform("com.google.firebase:firebase-bom:33.16.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.firebase:firebase-messaging")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.10.2")

    // reads the login code from the SMS by itself (no SMS permission needed)
    implementation("com.google.android.gms:play-services-auth-api-phone:18.2.0")

    // photos
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.getstream:stream-webrtc-android:1.3.8")
    implementation("io.livekit:livekit-android:2.23.1")
}
