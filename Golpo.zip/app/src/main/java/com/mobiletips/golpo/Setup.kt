package com.mobiletips.golpo

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat

/**
 * "Calls ring properly" setup.
 * On many phones a call does not ring because the phone stops the app in the background, hides its
 * full-screen call screen, or turns off its notification sound. Each row checks one thing and opens the
 * exact phone setting that fixes it.
 */
object CallSetup {
    private val brand get() = Build.MANUFACTURER.lowercase()

    fun notifOk(c: Context) = NotificationManagerCompat.from(c).areNotificationsEnabled()

    fun ringOk(c: Context): Boolean = Build.VERSION.SDK_INT < 26 || CallNotif.ringsBySystem(c)

    fun fullScreenOk(c: Context): Boolean = if (Build.VERSION.SDK_INT >= 34) {
        try { c.getSystemService(NotificationManager::class.java).canUseFullScreenIntent() } catch (_: Exception) { true }
    } else true

    fun batteryOk(c: Context): Boolean = try {
        c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)
    } catch (_: Exception) { true }

    /** Phones with their own "Autostart" / background switch. */
    fun hasAutostart() = brand in listOf("xiaomi", "redmi", "poco", "oppo", "realme", "vivo", "iqoo", "huawei", "honor", "oneplus",
        "infinix", "tecno", "itel", "letv", "asus", "meizu", "symphony", "walton")

    fun problems(c: Context): Int = listOf(notifOk(c), ringOk(c), fullScreenOk(c), batteryOk(c)).count { !it }

    private fun go(c: Context, vararg intents: Intent) {
        for (i in intents) {
            try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
        }
        toast(c, t("setup_manual"))
    }

    private fun appDetails(c: Context) = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName))

    fun openNotif(c: Context) = go(c,
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName), appDetails(c))

    fun openRing(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) go(c,
            Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName)
                .putExtra(Settings.EXTRA_CHANNEL_ID, CallNotif.ringChannel(c)),
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName), appDetails(c))
        else go(c, appDetails(c))
    }

    fun openFullScreen(c: Context) {
        if (Build.VERSION.SDK_INT >= 34) go(c, Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + c.packageName)), appDetails(c))
        else go(c, appDetails(c))
    }

    fun openBattery(c: Context) = go(c, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), appDetails(c))

    fun openAutostart(c: Context) {
        val list = listOf(
            ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
            ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
            ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.startup.StartupAppListActivity"),
            ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
            ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
            ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"),
            ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            ComponentName("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"),
            ComponentName("com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity"),
            ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity"),
            ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity"),
        )
        go(c, *(list.map { Intent().setComponent(it) } + appDetails(c)).toTypedArray())
    }

    /** Xiaomi: "Show on lock screen" + "Display pop-up windows while running in the background". */
    fun isXiaomi() = brand in listOf("xiaomi", "redmi", "poco")

    fun openMiuiPerms(c: Context) = go(c,
        Intent("miui.intent.action.APP_PERM_EDITOR").setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
            .putExtra("extra_pkgname", c.packageName),
        Intent("miui.intent.action.APP_PERM_EDITOR").putExtra("extra_pkgname", c.packageName),
        appDetails(c))
}

@Composable
fun CallSetupPage() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    // re-check every time the person comes back from the phone settings
    LaunchedEffect(Repo.foreground) { tick++ }
    if (tick < 0) return
    Text(t("setup_intro"), color = P.tx2, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 10.dp))
    ProCard {
        SetupRow("o_bell", t("setup_notif"), t("setup_notif_s"), CallSetup.notifOk(ctx)) { CallSetup.openNotif(ctx) }
        SetupRow("music", t("setup_ring"), t("setup_ring_s"), CallSetup.ringOk(ctx)) { CallSetup.openRing(ctx) }
        if (Build.VERSION.SDK_INT >= 34)
            SetupRow("o_call", t("setup_full"), t("setup_full_s"), CallSetup.fullScreenOk(ctx)) { CallSetup.openFullScreen(ctx) }
        SetupRow("battery", t("setup_battery"), t("setup_battery_s"), CallSetup.batteryOk(ctx)) { CallSetup.openBattery(ctx) }
        if (CallSetup.hasAutostart())
            SetupRow("o_shortcut", t("setup_auto"), t("setup_auto_s"), null) { CallSetup.openAutostart(ctx) }
        if (CallSetup.isXiaomi())
            SetupRow("o_shield", t("setup_miui"), t("setup_miui_s"), null) { CallSetup.openMiuiPerms(ctx) }
    }
    Text(t("setup_after"), color = P.tx2, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
    Box(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        OutlineButton(t("setup_test"), "o_call", modifier = Modifier.fillMaxWidth()) { Sounds.previewRing(ctx, Prefs.ring) }
    }
}

/** ok: true = done (green ✓), false = needs fixing (red), null = can't be checked (blue "Open"). */
@Composable
private fun SetupRow(icon: String, title: String, sub: String, ok: Boolean?, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().pressRow { onClick() }.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(P.pill), contentAlignment = Alignment.Center) { Ic(icon, Brand, 22.dp) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = P.tx, fontSize = 15.5.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = P.tx2, fontSize = 12.5.sp, lineHeight = 17.sp)
        }
        Spacer(Modifier.width(8.dp))
        when (ok) {
            true -> Box(Modifier.size(28.dp).clip(CircleShape).background(Green), contentAlignment = Alignment.Center) { Ic("check", Color.White, 18.dp) }
            false -> Text(t("fix"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Red).padding(horizontal = 12.dp, vertical = 6.dp))
            null -> Text(t("open"), color = Brand, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(P.pill).padding(horizontal = 12.dp, vertical = 6.dp))
        }
    }
}
