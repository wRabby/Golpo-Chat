package com.mobiletips.golpo

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

// ---------------------------------------------------------------- talking to the Golpo server (VPS)
class ApiError(val code: String) : Exception(code)

object Api {
    var base = ""

    /** The server address lives in Firestore config/app (the server writes it), so a new IP needs no new APK. */
    suspend fun server(): String {
        if (base.isNotEmpty()) return base
        base = Prefs.sp.getString("server", "") ?: ""
        try {
            val d = FirebaseFirestore.getInstance().collection("config").document("app").get().await()
            val s = (d.getString("server") ?: "").trimEnd('/')
            if (s.isNotEmpty()) {
                base = s
                Prefs.sp.edit().putString("server", s).apply()
            }
        } catch (_: Exception) {
        }
        if (base.isEmpty()) throw ApiError("net")
        return base
    }

    private suspend fun call(path: String, body: ByteArray, type: String, auth: Boolean): JSONObject = withContext(Dispatchers.IO) {
        val url = URL(server() + path)
        val token = if (auth) FirebaseAuth.getInstance().currentUser?.getIdToken(false)?.await()?.token else null
        val c = (url.openConnection() as HttpURLConnection)
        try {
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", type)
            if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
            c.outputStream.use { it.write(body) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: "{}"
            val j = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
            if (code !in 200..299) throw ApiError(j.optString("error", if (code == 401) "login" else "server"))
            j
        } catch (e: ApiError) {
            throw e
        } catch (e: Exception) {
            throw ApiError("net")
        } finally {
            c.disconnect()
        }
    }

    suspend fun post(path: String, j: JSONObject, auth: Boolean = false) = call(path, j.toString().toByteArray(), "application/json", auth)

    suspend fun upload(bytes: ByteArray, kind: String): String =
        call("/api/upload?kind=$kind", bytes, "application/octet-stream", true).getString("url")
}

// ---------------------------------------------------------------- data
data class User(
    val uid: String, val phone: String, val name: String, val about: String, val photo: String,
    val online: Boolean, val lastSeen: Long,
) {
    val shown get() = name.ifBlank { phone }
}

data class Chat(
    val id: String, val other: String, val updated: Long, val lastText: String, val lastKind: String,
    val lastFrom: String, val unread: Int, val otherTyping: Long,
)

data class Msg(
    val id: String, val from: String, val kind: String, val text: String, val url: String, val dur: Int,
    val at: Long, val st: Int, val pending: Boolean, val replyName: String, val replyText: String,
    val react: Map<String, String>, val del: Boolean,
)

fun DocumentSnapshot.toUser() = User(
    id, getString("phone") ?: "", getString("name") ?: "", getString("about") ?: "", getString("photo") ?: "",
    getBoolean("online") ?: false,
    getTimestamp("lastSeen", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L,
)

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toMsg(): Msg {
    val r = get("reply") as? Map<String, Any?>
    return Msg(
        id, getString("from") ?: "", getString("kind") ?: "t", getString("text") ?: "", getString("url") ?: "",
        (getLong("dur") ?: 0L).toInt(),
        getTimestamp("at", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: System.currentTimeMillis(),
        (getLong("st") ?: 1L).toInt(), metadata.hasPendingWrites(),
        r?.get("name") as? String ?: "", r?.get("text") as? String ?: "",
        (get("react") as? Map<String, String>) ?: emptyMap(), getBoolean("del") ?: false,
    )
}

fun previewOf(kind: String, text: String) = when (kind) {
    "img" -> t("photo")
    "voice" -> t("voice")
    "del" -> t("deleted")
    else -> text
}

// ---------------------------------------------------------------- Firebase state
object Repo {
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    val uid: String? get() = auth.currentUser?.uid
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val users = mutableStateMapOf<String, User>()
    val chats = mutableStateListOf<Chat>()
    var me by mutableStateOf<User?>(null)
    var meLoaded by mutableStateOf(false)
    var openChat: String? = null        // chat on screen (no notification for it)
    var foreground by mutableStateOf(false)
    private val regs = mutableListOf<ListenerRegistration>()

    fun chatId(a: String, b: String) = listOf(a, b).sorted().joinToString("_")
    fun user(id: String) = users[id]

    fun start() {
        stop()
        val u = uid ?: return
        regs += db.collection("users").document(u).addSnapshotListener { d, _ ->
            if (d == null) return@addSnapshotListener
            if (!d.metadata.isFromCache || d.exists()) meLoaded = true
            me = if (d.exists()) d.toUser() else null
        }
        regs += db.collection("users").addSnapshotListener { s, _ ->
            if (s == null) return@addSnapshotListener
            val m = s.documents.associate { it.id to it.toUser() }
            users.keys.retainAll(m.keys)
            users.putAll(m)
        }
        regs += db.collection("chats").whereArrayContains("members", u).addSnapshotListener { s, _ ->
            if (s == null) return@addSnapshotListener
            val list = s.documents.mapNotNull { d ->
                @Suppress("UNCHECKED_CAST")
                val members = d.get("members") as? List<String> ?: return@mapNotNull null
                val other = members.firstOrNull { it != u } ?: return@mapNotNull null
                @Suppress("UNCHECKED_CAST")
                val last = d.get("last") as? Map<String, Any?> ?: return@mapNotNull null
                @Suppress("UNCHECKED_CAST")
                val unread = (d.get("unread") as? Map<String, Any?>)?.get(u) as? Number
                @Suppress("UNCHECKED_CAST")
                val typing = (d.get("typing") as? Map<String, Any?>)?.get(other) as? Number
                Chat(
                    d.id, other,
                    d.getTimestamp("updated", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L,
                    last["text"] as? String ?: "", last["kind"] as? String ?: "t", last["from"] as? String ?: "",
                    unread?.toInt() ?: 0, typing?.toLong() ?: 0L,
                )
            }.sortedByDescending { it.updated }
            chats.clear()
            chats.addAll(list)
        }
        saveFcmToken()
        setOnline(true)
    }

    fun stop() {
        regs.forEach { it.remove() }
        regs.clear()
    }

    fun signOut() {
        setOnline(false)
        val u = uid
        if (u != null) db.collection("users").document(u).update("fcm", FieldValue.delete())
        stop()
        users.clear(); chats.clear(); me = null; meLoaded = false
        auth.signOut()
    }

    fun saveFcmToken() {
        val u = uid ?: return
        FirebaseMessaging.getInstance().token.addOnSuccessListener { tok ->
            db.collection("users").document(u).set(mapOf("fcm" to tok), SetOptions.merge())
        }
    }

    fun setOnline(on: Boolean) {
        val u = uid ?: return
        if (me == null && !meLoaded) return
        db.collection("users").document(u).set(
            mapOf("online" to on, "lastSeen" to FieldValue.serverTimestamp()), SetOptions.merge()
        )
    }

    fun saveProfile(name: String, about: String, photo: String?, phone: String) {
        val u = uid ?: return
        val m = hashMapOf<String, Any>("name" to name.trim(), "about" to about.trim(), "phone" to phone,
            "online" to true, "lastSeen" to FieldValue.serverTimestamp())
        if (photo != null) m["photo"] = photo
        if (me == null) m["created"] = FieldValue.serverTimestamp()
        db.collection("users").document(u).set(m, SetOptions.merge())
    }

    /** Makes sure the chat document exists (rules let only its two members read the messages). */
    fun ensureChat(other: String): String {
        val u = uid!!
        val id = chatId(u, other)
        db.collection("chats").document(id).set(mapOf("members" to listOf(u, other).sorted()), SetOptions.merge())
        return id
    }

    fun send(chat: String, other: String, kind: String, text: String = "", url: String = "", dur: Int = 0,
             reply: Pair<String, String>? = null) {
        val u = uid ?: return
        val cref = db.collection("chats").document(chat)
        val ref = cref.collection("messages").document()
        val m = hashMapOf<String, Any>(
            "from" to u, "kind" to kind, "text" to text, "url" to url, "dur" to dur,
            "at" to FieldValue.serverTimestamp(), "st" to 1,
        )
        if (reply != null) m["reply"] = mapOf("name" to reply.first, "text" to reply.second)
        val batch = db.batch()
        batch.set(ref, m)
        batch.set(cref, mapOf(
            "members" to listOf(u, other).sorted(),
            "updated" to FieldValue.serverTimestamp(),
            "last" to mapOf("text" to text, "kind" to kind, "from" to u),
            "unread" to mapOf(other to FieldValue.increment(1)),
            "typing" to mapOf(u to 0L),
        ), SetOptions.merge())
        batch.commit().addOnSuccessListener {
            scope.launch {
                try { Api.post("/api/push", JSONObject().put("chat", chat).put("mid", ref.id), auth = true) } catch (_: Exception) {}
            }
        }
    }

    fun markRead(chat: String, msgs: List<Msg>, unread: Int) {
        val u = uid ?: return
        val cref = db.collection("chats").document(chat)
        val todo = msgs.filter { it.from != u && it.st < 3 && !it.pending }
        if (todo.isNotEmpty()) {
            val b = db.batch()
            todo.takeLast(400).forEach { b.update(cref.collection("messages").document(it.id), "st", 3) }
            b.commit()
        }
        if (unread > 0) cref.update("unread.$u", 0)
    }

    fun markDelivered(chat: String, mid: String) {
        val ref = db.collection("chats").document(chat).collection("messages").document(mid)
        ref.get().addOnSuccessListener { d -> if ((d.getLong("st") ?: 3L) < 2L) ref.update("st", 2) }
    }

    fun typing(chat: String) {
        val u = uid ?: return
        db.collection("chats").document(chat).update("typing.$u", System.currentTimeMillis())
    }

    fun react(chat: String, mid: String, emoji: String?) {
        val u = uid ?: return
        db.collection("chats").document(chat).collection("messages").document(mid)
            .update("react.$u", emoji ?: FieldValue.delete())
    }

    fun deleteForAll(chat: String, m: Msg, isLast: Boolean) {
        val cref = db.collection("chats").document(chat)
        cref.collection("messages").document(m.id).update(mapOf("del" to true, "text" to "", "url" to "", "react" to FieldValue.delete()))
        if (isLast) cref.update(mapOf("last.kind" to "del", "last.text" to ""))
    }
}

// ---------------------------------------------------------------- SMS auto-fill: the app's 11-letter hash goes at the end of the SMS
fun appHash(c: Context): String = try {
    val pm = c.packageManager
    val sig = if (Build.VERSION.SDK_INT >= 28) {
        pm.getPackageInfo(c.packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo!!.apkContentsSigners[0]
    } else {
        @Suppress("DEPRECATION")
        pm.getPackageInfo(c.packageName, PackageManager.GET_SIGNATURES).signatures!![0]
    }
    val md = MessageDigest.getInstance("SHA-256")
    md.update("${c.packageName} ${sig.toCharsString()}".toByteArray(Charsets.UTF_8))
    Base64.encodeToString(md.digest().copyOfRange(0, 9), Base64.NO_PADDING or Base64.NO_WRAP).substring(0, 11)
} catch (_: Exception) {
    ""
}
