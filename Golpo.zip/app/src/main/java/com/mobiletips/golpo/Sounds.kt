package com.mobiletips.golpo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.SoundPool
import android.net.Uri
import android.os.Build
import android.provider.Settings

/** Golpo's own ringtones / message tones, previews, and the in-chat send / receive sounds. */
object Sounds {
    val rings = listOf("golpo_classic", "sunrise", "pulse", "kalimba", "phone")
    val tones = listOf("pop", "droplet", "chime", "glass", "bounce", "default", "silent")

    fun ringName(k: String) = when (k) {
        "golpo_classic" -> "Golpo Classic"; "sunrise" -> "Sunrise"; "pulse" -> "Pulse"; "kalimba" -> "Kalimba"
        else -> t("phone_ringtone")
    }

    fun toneName(k: String) = when (k) {
        "pop" -> "Pop"; "droplet" -> "Droplet"; "chime" -> "Chime"; "glass" -> "Glass"; "bounce" -> "Bounce"
        "silent" -> t("silent"); else -> t("phone_default")
    }

    fun ringRes(k: String): Int = when (k) {
        "golpo_classic" -> R.raw.ring_golpo_classic; "sunrise" -> R.raw.ring_sunrise
        "pulse" -> R.raw.ring_pulse; "kalimba" -> R.raw.ring_kalimba; else -> 0
    }

    fun toneRes(k: String): Int = when (k) {
        "pop" -> R.raw.msg_pop; "droplet" -> R.raw.msg_droplet; "chime" -> R.raw.msg_chime
        "glass" -> R.raw.msg_glass; "bounce" -> R.raw.msg_bounce; else -> 0
    }

    fun uri(c: Context, res: Int): Uri = Uri.parse("android.resource://${c.packageName}/$res")

    // ------------------------------------------------------------ preview in Settings
    private var player: MediaPlayer? = null
    private var sys: Ringtone? = null

    fun previewRing(c: Context, k: String) {
        stop()
        val res = ringRes(k)
        if (res == 0) playSystem(c, RingtoneManager.TYPE_RINGTONE) else playRaw(c, res, AudioAttributes.USAGE_NOTIFICATION_RINGTONE, false)
    }

    fun previewTone(c: Context, k: String) {
        stop()
        when (k) {
            "silent" -> {}
            "default" -> playSystem(c, RingtoneManager.TYPE_NOTIFICATION)
            else -> playRaw(c, toneRes(k), AudioAttributes.USAGE_NOTIFICATION, false)
        }
    }

    private fun playSystem(c: Context, type: Int) {
        try { sys = RingtoneManager.getRingtone(c, RingtoneManager.getDefaultUri(type))?.apply { play() } } catch (_: Exception) {}
    }

    private fun playRaw(c: Context, res: Int, usage: Int, loop: Boolean): MediaPlayer? = try {
        MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(usage).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            setDataSource(c, uri(c, res))
            isLooping = loop
            setOnCompletionListener { if (!loop) { it.release(); if (player === it) player = null } }
            prepare()
            start()
        }.also { player = it }
    } catch (_: Exception) { null }

    fun stop() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        try { sys?.stop() } catch (_: Exception) {}
        sys = null
    }

    // ------------------------------------------------------------ incoming-call ringtone
    private var ringPlayer: MediaPlayer? = null
    private var ringSys: Ringtone? = null

    fun startRing(c: Context) {
        stopRing()
        val res = ringRes(Prefs.ring)
        if (res == 0) {
            try {
                ringSys = RingtoneManager.getRingtone(c, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))?.apply {
                    if (Build.VERSION.SDK_INT >= 28) isLooping = true
                    play()
                }
            } catch (_: Exception) {}
        } else {
            ringPlayer = try {
                MediaPlayer().apply {
                    setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    setDataSource(c, uri(c, res))
                    isLooping = true
                    prepare()
                    start()
                }
            } catch (_: Exception) { null }
        }
    }

    fun stopRing() {
        try { ringPlayer?.stop() } catch (_: Exception) {}
        try { ringPlayer?.release() } catch (_: Exception) {}
        ringPlayer = null
        try { ringSys?.stop() } catch (_: Exception) {}
        ringSys = null
    }

    // ------------------------------------------------------------ in-chat sounds
    private var pool: SoundPool? = null
    private var sendId = 0
    private var recvId = 0

    fun init(c: Context) {
        if (pool != null) return
        try {
            val p = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            ).build()
            sendId = p.load(c.applicationContext, R.raw.send_whoosh, 1)
            recvId = p.load(c.applicationContext, R.raw.msg_pop, 1)
            pool = p
        } catch (_: Exception) {}
    }

    fun sent() { if (Prefs.chatSounds) try { pool?.play(sendId, .5f, .5f, 1, 0, 1f) } catch (_: Exception) {} }
    fun received() { if (Prefs.chatSounds) try { pool?.play(recvId, .4f, .4f, 1, 0, 1f) } catch (_: Exception) {} }

    // ------------------------------------------------------------ message notification channel
    /** A channel's sound can't change after it is made, so each tone + vibrate choice gets its own channel. */
    fun msgChannel(c: Context): String {
        val id = "msg_" + Prefs.tone + (if (Prefs.vibrate) "_v" else "_n")
        if (Build.VERSION.SDK_INT < 26) return id
        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) == null) {
            nm.notificationChannels.filter { it.id.startsWith("msg_") || it.id == "messages" }.forEach {
                try { nm.deleteNotificationChannel(it.id) } catch (_: Exception) {}
            }
            val ch = NotificationChannel(id, t("messages_ch"), NotificationManager.IMPORTANCE_HIGH)
            val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            when (Prefs.tone) {
                "silent" -> ch.setSound(null, null)
                "default" -> ch.setSound(Settings.System.DEFAULT_NOTIFICATION_URI, attrs)
                else -> ch.setSound(uri(c, toneRes(Prefs.tone)), attrs)
            }
            ch.enableVibration(Prefs.vibrate)
            if (!Prefs.vibrate) ch.vibrationPattern = longArrayOf(0)
            nm.createNotificationChannel(ch)
        }
        return id
    }
}
