package com.mobiletips.golpo

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Rational
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ---------------------------------------------------------------- floating window (picture-in-picture)
object Pip {
    fun supported(a: Activity) = Build.VERSION.SDK_INT >= 26 &&
        a.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

    private fun params(auto: Boolean): PictureInPictureParams? {
        if (Build.VERSION.SDK_INT < 26) return null
        val b = PictureInPictureParams.Builder().setAspectRatio(Rational(9, 16))
        if (Build.VERSION.SDK_INT >= 31) b.setAutoEnterEnabled(auto).setSeamlessResizeEnabled(true)
        return b.build()
    }

    /** Android 12+: going Home while a call is on turns the screen into the small window by itself. */
    fun auto(a: Activity, on: Boolean) {
        if (!supported(a)) return
        try { params(on)?.let { a.setPictureInPictureParams(it) } } catch (_: Exception) {}
    }

    fun enter(a: Activity) {
        if (!supported(a)) return
        try { params(true)?.let { a.enterPictureInPictureMode(it) } } catch (_: Exception) {}
    }
}

/** Is any call going on right now (for the bar and the small window)? */
fun callLive(): Boolean {
    val p = CallManager.phase
    val g = GroupCall.phase
    return p == CallPhase.Outgoing || p == CallPhase.Connecting || p == CallPhase.Active || g == GPhase.Connecting || g == GPhase.Live
}

/** Back to the call screen. */
fun openCall(c: Context) {
    (c as? Activity)?.let { Pip.auto(it, false) }    // opening the call screen is not "leaving the app"
    val cls = if (GroupCall.busy) GroupCallActivity::class.java else CallActivity::class.java
    try {
        c.startActivity(Intent(c, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION))
    } catch (_: Exception) {}
}

/** Minimise: go to the app (chats) while the call keeps going. */
fun openApp(c: Context) {
    (c as? Activity)?.let { Pip.auto(it, false) }
    try {
        c.startActivity(Intent(c, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_NO_USER_ACTION))
    } catch (_: Exception) {}
}

fun callClock(start: Long, now: Long): String {
    if (start <= 0) return ""
    val s = ((now - start) / 1000).coerceAtLeast(0)
    return num(if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s / 60 % 60, s % 60) else "%02d:%02d".format(s / 60, s % 60))
}

private fun callName(): String = if (GroupCall.busy) GroupCall.title.ifBlank { t("group_call") } else CallManager.peerName.ifBlank { "Golpo Chat" }

// ---------------------------------------------------------------- the bar inside the app while a call is on
@Composable
fun InAppCallBar(onOpen: () -> Unit) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    val inf = rememberInfiniteTransition(label = "bar")
    val a by inf.animateFloat(0.45f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "dot")
    val group = GroupCall.busy
    val start = if (group) GroupCall.startedAt else CallManager.startedAt
    val status = when {
        group && GroupCall.phase == GPhase.Live -> callClock(start, now) + " · " + num("${GroupCall.people.size}") + " " + t("g_in_call")
        group -> t("connecting")
        CallManager.phase == CallPhase.Active -> callClock(start, now)
        CallManager.phase == CallPhase.Outgoing -> t("calling")
        else -> t("connecting")
    }
    val video = if (group) GroupCall.camOn else CallManager.video
    Row(
        Modifier.fillMaxWidth().press(RoundedCornerShape(0.dp), scaleTo = 0.99f) { onOpen() }
            .background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Color(0xFF16C79A), Color(0xFF1E9BF0))))
            .padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(9.dp).alpha(a).clip(CircleShape).background(Color.White))
        Spacer(Modifier.width(10.dp))
        Ic(if (video) "video" else "call", Color.White, 18.dp)
        Spacer(Modifier.width(8.dp))
        Text(callName(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.5.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
        Text("  ·  $status", color = Color.White.copy(alpha = .92f), fontSize = 13.5.sp, maxLines = 1, modifier = Modifier.weight(1f))
        Text(t("back_to_call"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = .22f)).padding(horizontal = 10.dp, vertical = 4.dp))
    }
}

// ---------------------------------------------------------------- small window content (for the chat app's own window)
@Composable
fun PipCallCard() {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    Box(Modifier.fillMaxSize().background(CallBg), contentAlignment = Alignment.Center) {
        if (GroupCall.busy) {
            GroupPipContent(now)
        } else {
            OnePipContent(now)
        }
    }
}

// ---------------------------------------------------------------- shared call-screen pieces
/** Round glass button for the top corners (minimise, add person). */
@Composable
fun GlassBtn(icon: String, size: Dp = 46.dp, onClick: () -> Unit) {
    Box(Modifier.size(size).press(CircleShape) { onClick() }.background(Color.White.copy(alpha = .14f))
        .border(1.dp, Color.White.copy(alpha = .22f), CircleShape), contentAlignment = Alignment.Center) {
        Ic(icon, Color.White, size * 0.5f)
    }
}

@Composable
fun CallTop(title: String, status: String, onMin: () -> Unit, onAdd: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        GlassBtn("minimize") { onMin() }
        Column(Modifier.weight(1f).padding(horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(status, color = Color.White.copy(alpha = .8f), fontSize = 13.5.sp, maxLines = 1, textAlign = TextAlign.Center)
        }
        if (onAdd != null) GlassBtn("person_add") { onAdd() } else Spacer(Modifier.size(46.dp))
    }
}

/** The six call buttons: Speaker · Video · Mute / More · Share screen · End. */
@Composable
fun CallPanel(speaker: Boolean, videoOn: Boolean, muted: Boolean, sharing: Boolean,
              onSpeaker: () -> Unit, onVideo: () -> Unit, onMute: () -> Unit, onMore: () -> Unit, onShare: () -> Unit, onEnd: () -> Unit) {
    Column(
        Modifier.padding(horizontal = 12.dp, vertical = 10.dp).fillMaxWidth().clip(RoundedCornerShape(30.dp))
            .background(Color(0xFF0B1B2C).copy(alpha = .78f)).border(1.dp, Color.White.copy(alpha = .10f), RoundedCornerShape(30.dp))
            .padding(vertical = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            CtlBtn(if (speaker) "volume" else "volume_off", t("speaker"), speaker, onSpeaker)
            CtlBtn(if (videoOn) "video" else "video_off", t("video"), videoOn, onVideo)
            CtlBtn(if (muted) "mic_off" else "mic", t("mute"), muted, onMute)
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            CtlBtn("more_h", t("more"), false, onMore)
            CtlBtn("screen_share", if (sharing) t("stop_share") else t("share_screen"), sharing, onShare)
            Column(Modifier.width(88.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.width(74.dp).height(60.dp).press(RoundedCornerShape(22.dp)) { onEnd() }.background(Red),
                    contentAlignment = Alignment.Center) { Ic("call_end", Color.White, 30.dp) }
                Spacer(Modifier.height(7.dp))
                Text(t("end"), color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun CtlBtn(icon: String, label: String, on: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(88.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(60.dp).press(CircleShape) { onClick() }
                .background(if (on) Brand else Color.White.copy(alpha = .10f))
                .border(1.dp, if (on) Color(0xFF7FD0FF) else Color.White.copy(alpha = .20f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Ic(icon, Color.White, 27.dp) }
        Spacer(Modifier.height(7.dp))
        Text(label, color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Accept / decline for an incoming call. */
@Composable
fun AnswerRow(video: Boolean, onDecline: () -> Unit, onAccept: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "ans")
    val k by inf.animateFloat(1f, 1.1f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "k")
    Row(Modifier.fillMaxWidth().padding(bottom = 46.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(72.dp).press(CircleShape) { onDecline() }.background(Red), contentAlignment = Alignment.Center) {
                Ic("call_end", Color.White, 32.dp)
            }
            Spacer(Modifier.height(8.dp)); Text(t("decline"), color = Color.White, fontSize = 13.sp)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(72.dp).graphicsLayer { scaleX = k; scaleY = k }.press(CircleShape) { onAccept() }.background(Green), contentAlignment = Alignment.Center) {
                Ic(if (video) "video" else "call", Color.White, 32.dp)
            }
            Spacer(Modifier.height(8.dp)); Text(t("accept"), color = Color.White, fontSize = 13.sp)
        }
    }
}
