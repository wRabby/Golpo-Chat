package com.mobiletips.golpo

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/** People I can add to a group: everyone I have a one-to-one chat with. */
private fun friendList(exclude: Collection<String> = emptyList()): List<User> {
    val me = Repo.uid
    return Repo.chats.filter { !it.group }.mapNotNull { Repo.user(it.other) }
        .filter { it.uid != me && it.uid !in exclude && it.name.isNotBlank() }
        .distinctBy { it.uid }.sortedBy { it.shown.lowercase() }
}

// ---------------------------------------------------------------- pick people (new group / add members)
@Composable
private fun PeoplePicker(
    title: String, exclude: Collection<String>, button: String, busy: Boolean,
    onBack: () -> Unit, onDone: (List<String>) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    val picked = remember { mutableStateListOf<String>() }
    val extra = remember { mutableStateListOf<User>() }      // found by number
    var finding by remember { mutableStateOf(false) }
    val all = (friendList(exclude) + extra).distinctBy { it.uid }
    val digits = q.filter { it.isDigit() }.removePrefix("880").removePrefix("0")
    val shown = all.filter { q.isBlank() || it.name.contains(q, true) || it.phone.contains(digits.ifEmpty { "~" }) }

    fun find() {
        if (!Regex("^1[3-9]\\d{8}$").matches(digits)) { toast(ctx, t("e_invalid_num")); return }
        val uid = "u880$digits"
        if (uid == Repo.uid) { toast(ctx, t("e_own_num")); return }
        finding = true
        scope.launch {
            try {
                val d = Repo.db.collection("users").document(uid).get().await()
                val u = if (d.exists()) d.toUser() else null
                if (u == null || u.name.isBlank()) toast(ctx, t("e_not_found"))
                else if (u.uid in exclude) toast(ctx, t("g_already"))
                else { if (extra.none { it.uid == u.uid }) extra.add(u); if (u.uid !in picked) picked.add(u.uid); q = "" }
            } catch (_: Exception) { toast(ctx, t("e_net")) }
            finding = false
        }
    }

    Column(Modifier.fillMaxSize().background(P.bg)) {
        TopBar(title, onBack)
        if (picked.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                picked.forEach { id ->
                    val u = Repo.user(id) ?: extra.firstOrNull { it.uid == id }
                    Column(Modifier.width(62.dp).clickable { picked.remove(id) }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Box {
                            Avatar(u?.shown ?: "?", u?.photo ?: "", id, 52.dp)
                            Box(Modifier.align(Alignment.BottomEnd).size(20.dp).clip(CircleShape).background(P.tx2), contentAlignment = Alignment.Center) {
                                Ic("close", Color.White, 14.dp)
                            }
                        }
                        Text(u?.shown ?: "", color = P.tx, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        SearchBox(q) { q = it }
        if (digits.length >= 10 && shown.isEmpty()) {
            Row(Modifier.fillMaxWidth().clickable(enabled = !finding) { find() }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(Grad), contentAlignment = Alignment.Center) {
                    if (finding) CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                    else Ic("search", Color.White, 22.dp)
                }
                Spacer(Modifier.width(13.dp))
                Text(t("find") + " +880 " + num(digits), color = Brand, fontWeight = FontWeight.Bold, fontSize = 15.5.sp)
            }
        }
        Text(t("my_friends"), color = Brand, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 4.dp))
        if (all.isEmpty()) Text(t("g_no_friends"), color = P.tx2, fontSize = 14.sp, modifier = Modifier.padding(16.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(shown, key = { it.uid }) { u ->
                val on = u.uid in picked
                Row(Modifier.fillMaxWidth().clickable { if (on) picked.remove(u.uid) else picked.add(u.uid) }.padding(horizontal = 16.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Avatar(u.shown, u.photo, u.uid, 46.dp)
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(u.shown, color = P.tx, fontWeight = FontWeight.Bold, fontSize = 15.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(u.about.ifBlank { num(u.phone) }, color = P.tx2, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Box(Modifier.size(24.dp).clip(CircleShape).background(if (on) Brand else Color.Transparent)
                        .border(2.dp, if (on) Brand else P.tx2, CircleShape), contentAlignment = Alignment.Center) {
                        if (on) Ic("check", Color.White, 16.dp)
                    }
                }
            }
        }
        Box(Modifier.padding(16.dp)) {
            GradButton(button + if (picked.isNotEmpty()) " (" + num("${picked.size}") + ")" else "", enabled = picked.isNotEmpty(), busy = busy) {
                onDone(picked.toList())
            }
        }
    }
}

// ---------------------------------------------------------------- new group: pick people, then name + photo
@Composable
fun NewGroupScreen(onBack: () -> Unit, opened: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var people by remember { mutableStateOf<List<String>?>(null) }
    var name by remember { mutableStateOf("") }
    var photo by remember { mutableStateOf("") }
    var uploading by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            uploading = true
            scope.launch {
                try { photo = Api.upload(Media.jpeg(ctx, uri, 640), "avatar") } catch (e: Exception) { toast(ctx, errText(e)) }
                uploading = false
            }
        }
    }
    val chosen = people
    if (chosen == null) {
        PeoplePicker(t("g_new_title"), emptyList(), t("next"), false, onBack) { people = it }
        return
    }
    Column(Modifier.fillMaxSize().background(P.bg)) {
        TopBar(t("g_new_title"), { people = null })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(110.dp).clip(CircleShape).background(P.bg2)
                .clickable { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                contentAlignment = Alignment.Center) {
                when {
                    uploading -> CircularProgressIndicator(color = Brand)
                    photo.isNotEmpty() -> Avatar(name.ifBlank { "?" }, photo, "new", 110.dp)
                    else -> Ic("camera", P.tx2, 40.dp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(t("tap_photo"), color = P.tx2, fontSize = 13.sp)
            Spacer(Modifier.height(20.dp))
            Field(name, { name = it }, t("g_name"), "group", maxLen = 40)
            Spacer(Modifier.height(18.dp))
            Text(t("g_members") + ": " + num("${chosen.size + 1}"), color = P.tx2, fontSize = 14.sp, modifier = Modifier.fillMaxWidth())
        }
        Box(Modifier.padding(16.dp)) {
            GradButton(t("g_create"), enabled = name.isNotBlank() && !uploading, busy = busy) {
                busy = true
                Repo.createGroup(name, photo, chosen) { id -> busy = false; opened(id) }
            }
        }
    }
}

// ---------------------------------------------------------------- add members to an existing group
@Composable
fun AddMembersScreen(gid: String, onBack: () -> Unit) {
    val g = Repo.chats.firstOrNull { it.id == gid }
    PeoplePicker(t("g_add"), g?.members ?: emptyList(), t("g_add"), false, onBack) { Repo.addMembers(gid, it); onBack() }
}

// ---------------------------------------------------------------- group info
@Composable
fun GroupInfoScreen(gid: String, onBack: () -> Unit, openChat: (String) -> Unit, addPeople: () -> Unit, left: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val g = Repo.chats.firstOrNull { it.id == gid }
    val me = Repo.uid ?: ""
    if (g == null) {
        Column(Modifier.fillMaxSize().background(P.bg)) { TopBar("", onBack); Text(t("g_gone"), color = P.tx2, modifier = Modifier.padding(24.dp)) }
        return
    }
    val admin = me in g.admins
    var ask by remember { mutableStateOf("") }
    var who by remember { mutableStateOf<String?>(null) }
    var editName by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf(g.name) }
    var uploading by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            uploading = true
            scope.launch {
                try { Repo.groupUpdate(gid, mapOf("photo" to Api.upload(Media.jpeg(ctx, uri, 640), "avatar"))) } catch (e: Exception) { toast(ctx, errText(e)) }
                uploading = false
            }
        }
    }
    val members = g.members.sortedWith(compareBy({ it != me }, { it !in g.admins }, { (Repo.user(it)?.shown ?: "").lowercase() }))

    Column(Modifier.fillMaxSize().background(P.bg2)) {
        TopBar(g.name, onBack)
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(118.dp).clickable(enabled = admin) { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                        Avatar(g.name.ifBlank { "?" }, g.photo, gid, 118.dp)
                        if (uploading) CircularProgressIndicator(color = Brand, modifier = Modifier.align(Alignment.Center))
                        if (admin) Box(Modifier.align(Alignment.BottomEnd).size(34.dp).clip(CircleShape).background(Brand), contentAlignment = Alignment.Center) {
                            Ic("camera", Color.White, 18.dp)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(g.name, color = P.tx, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        if (admin) Box(Modifier.padding(start = 6.dp).size(32.dp).clip(CircleShape).clickable { newName = g.name; editName = true },
                            contentAlignment = Alignment.Center) { Ic("edit", Brand, 18.dp) }
                    }
                    Text(t("group") + " · " + num("${g.members.size}") + " " + t("g_members"), color = P.tx2, fontSize = 14.sp)
                }
                ProCard {
                    val muted = Prefs.isMuted(gid)
                    ProRow("o_mute", t("mute_notif"), onClick = { Prefs.setMuted(gid, !muted) }) { ProSwitch(muted) { Prefs.setMuted(gid, it) } }
                    val fav = Repo.isFav(gid)
                    ProRow(if (fav) "star" else "o_star", t("add_fav"), tint = if (fav) Color(0xFFFFB300) else P.tx,
                        onClick = { Repo.setFlag("fav", gid, !fav) }) { ProSwitch(fav) { Repo.setFlag("fav", gid, it) } }
                }
                Text(num("${g.members.size}") + " " + t("g_members"), color = Brand, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    modifier = Modifier.padding(start = 22.dp, top = 12.dp, bottom = 4.dp))
            }
            item {
                ProCard {
                    if (admin) ProRow("group_add", t("g_add"), tint = Brand, onClick = addPeople)
                    members.forEach { id ->
                        val u = Repo.user(id)
                        Row(Modifier.fillMaxWidth().clickable { if (id != me) who = id }.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Avatar(u?.shown ?: "?", u?.photo ?: "", id, 44.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(if (id == me) t("you") else u?.shown ?: "…", color = P.tx, fontWeight = FontWeight.SemiBold, fontSize = 15.5.sp,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(u?.about?.ifBlank { null } ?: num(u?.phone ?: ""), color = P.tx2, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            if (id in g.admins) Text(t("g_admin"), color = Mint, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Mint.copy(alpha = .12f)).padding(horizontal = 8.dp, vertical = 3.dp))
                        }
                    }
                }
            }
            item {
                ProCard {
                    ProRow("o_delete", t("clear_chat"), tint = Red, onClick = { ask = "clear" })
                    ProRow("logout", t("g_leave"), tint = Red, onClick = { ask = "leave" })
                }
                Spacer(Modifier.height(30.dp))
            }
        }
    }

    // ---- tap on a member
    val w = who
    if (w != null) {
        val u = Repo.user(w)
        androidx.compose.ui.window.Dialog(onDismissRequest = { who = null }) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(P.card).padding(vertical = 10.dp)) {
                Text(u?.shown ?: "", color = P.tx, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 22.dp, vertical = 10.dp))
                MenuLine(t("message_btn")) { who = null; openChat(w) }
                if (admin) {
                    if (w in g.admins) MenuLine(t("g_unadmin")) { Repo.setAdmin(gid, w, false); who = null }
                    else MenuLine(t("g_make_admin")) { Repo.setAdmin(gid, w, true); who = null }
                    MenuLine(t("g_remove"), Red) { Repo.removeMember(gid, w); who = null }
                }
            }
        }
    }
    when (ask) {
        "clear" -> Confirm(t("clear_chat") + "?", t("clear_q"), t("clear"), danger = true, onCancel = { ask = "" }) { Repo.clearChat(gid); ask = "" }
        "leave" -> Confirm(t("g_leave") + "?", t("g_leave_q"), t("g_leave"), danger = true, onCancel = { ask = "" }) {
            Repo.leaveGroup(gid); ask = ""; left()
        }
    }
    if (editName) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { editName = false }) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(P.card).padding(20.dp)) {
                Text(t("g_name"), color = P.tx, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Field(newName, { newName = it }, t("g_name"), maxLen = 40)
                Spacer(Modifier.height(16.dp))
                GradButton(t("save"), enabled = newName.isNotBlank()) {
                    Repo.groupUpdate(gid, mapOf("name" to newName.trim().take(40))); editName = false
                }
            }
        }
    }
}

@Composable
private fun MenuLine(text: String, color: Color = P.tx, onClick: () -> Unit) {
    Text(text, color = color, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 22.dp, vertical = 14.dp))
}
