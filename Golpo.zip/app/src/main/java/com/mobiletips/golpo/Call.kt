package com.mobiletips.golpo

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import org.webrtc.audio.JavaAudioDeviceModule
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/*
 * Voice & video calls.
 * Signalling goes through Firestore:  calls/{id} {from, to, members, video, state, offer, answer, created, dur}
 *                                     calls/{id}/c/{auto} {from, c, m, i}   (ICE candidates)
 * The other phone is woken by a high-priority FCM message sent by the Golpo server (/api/call).
 * Media flows phone-to-phone with WebRTC; the TURN server on the VPS relays it when a direct path is impossible.
 */
enum class CallPhase { Idle, Outgoing, Incoming, Connecting, Active, Ended }

object CallManager {
    var phase by mutableStateOf(CallPhase.Idle)
    var peer by mutableStateOf("")
    var peerName by mutableStateOf("")
    var peerPhoto by mutableStateOf("")
    var video by mutableStateOf(false)
    var startedAt by mutableLongStateOf(0L)
    var muted by mutableStateOf(false)
    var speaker by mutableStateOf(false)
    var camOn by mutableStateOf(true)
    var front by mutableStateOf(true)
    var endReason by mutableStateOf("")
    var remoteVideo by mutableStateOf<VideoTrack?>(null)
    var localVideo by mutableStateOf<VideoTrack?>(null)
    var callId = ""
        private set
    var caller = false
        private set

    lateinit var app: Context
    val egl: EglBase by lazy { EglBase.create() }

    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var audioSource: AudioSource? = null
    private var audioTrack: AudioTrack? = null
    private var videoSource: VideoSource? = null
    private var capturer: CameraVideoCapturer? = null
    private var texHelper: SurfaceTextureHelper? = null
    private val regs = mutableListOf<ListenerRegistration>()
    private val pendingRemote = mutableListOf<IceCandidate>()
    private val pendingLocal = mutableListOf<IceCandidate>()
    private var remoteSet = false
    private var docReady = false
    private var answerApplied = false
    private var tone: ToneGenerator? = null
    private var timeoutJob: Job? = null
    private var dropJob: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private val seenCalls = HashSet<String>()

    private val db get() = FirebaseFirestore.getInstance()
    private fun ref() = db.collection("calls").document(callId)
    val busy get() = phase != CallPhase.Idle && phase != CallPhase.Ended

    private fun reset() {
        muted = false; front = true; endReason = ""; startedAt = 0L
        remoteSet = false; docReady = false; answerApplied = false
        pendingRemote.clear(); pendingLocal.clear()
        remoteVideo = null; localVideo = null
    }

    // ------------------------------------------------------------ outgoing
    fun startOutgoing(ctx: Context, other: String, isVideo: Boolean) {
        if (busy || GroupCall.busy) return
        app = ctx.applicationContext
        val me = Repo.uid ?: return
        reset()
        caller = true; peer = other; video = isVideo; speaker = isVideo; camOn = isVideo
        val u = Repo.user(other)
        peerName = u?.shown ?: ""; peerPhoto = u?.photo ?: ""
        callId = db.collection("calls").document().id
        phase = CallPhase.Outgoing
        CallService.start(app)
        audioOn()
        startRingback()
        scope.launch {
            try {
                setupPc(fetchIce())
                val offer = createSdp(true)
                setLocal(offer)
                if (phase != CallPhase.Outgoing) return@launch
                ref().set(mapOf(
                    "from" to me, "to" to other, "members" to listOf(me, other), "video" to isVideo,
                    "state" to "ringing", "created" to FieldValue.serverTimestamp(),
                    "offer" to mapOf("type" to "offer", "sdp" to offer.description),
                )).await()
                if (phase != CallPhase.Outgoing) { ref().update("state", "canceled"); return@launch }
                docReady = true
                pendingLocal.forEach { writeCand(it) }; pendingLocal.clear()
                listenDoc(); listenCands()
                try { Api.post("/api/call", JSONObject().put("call", callId).put("action", "ring"), auth = true) } catch (_: Exception) {}
                timeoutJob = scope.launch {
                    delay(45_000)
                    if (phase == CallPhase.Outgoing) { ref().update("state", "missed"); finish("noanswer") }
                }
            } catch (e: Exception) {
                finish("failed")
            }
        }
    }

    // ------------------------------------------------------------ incoming
    /** Called from FCM (any thread). */
    fun onIncoming(ctx: Context, id: String, from: String, name: String, photo: String, isVideo: Boolean) = main.post {
        app = ctx.applicationContext
        if (!seenCalls.add(id)) return@post          // already handled (push + live listener both deliver it)
        if (busy || GroupCall.busy) { db.collection("calls").document(id).update("state", "busy"); return@post }
        reset()
        callId = id; caller = false; peer = from; video = isVideo; speaker = isVideo; camOn = isVideo
        peerName = name.ifBlank { Repo.user(from)?.shown ?: "" }
        peerPhoto = photo
        docReady = true
        phase = CallPhase.Incoming
        CallService.start(app)
        startRinging()
        listenDoc()
        timeoutJob = scope.launch { delay(45_000); if (phase == CallPhase.Incoming) finish("missed") }
    }

    fun remoteCanceled(id: String) = main.post { if (id == callId && phase == CallPhase.Incoming) finish("missed") }

    fun accept() {
        if (phase != CallPhase.Incoming) return
        stopRinging()
        phase = CallPhase.Connecting
        CallService.start(app)
        audioOn()
        scope.launch {
            try {
                val d = ref().get().await()
                if (d.getString("state") != "ringing") { finish("ended"); return@launch }
                val offer = d.get("offer") as? Map<*, *> ?: throw IllegalStateException("no offer")
                setupPc(fetchIce())
                setRemote(SessionDescription(SessionDescription.Type.OFFER, offer["sdp"] as String))
                val ans = createSdp(false)
                setLocal(ans)
                ref().update(mapOf("answer" to mapOf("type" to "answer", "sdp" to ans.description), "state" to "accepted")).await()
                listenCands()
            } catch (e: Exception) {
                finish("failed")
            }
        }
    }

    fun decline() {
        if (phase != CallPhase.Incoming) return
        ref().update("state", "declined")
        finish("declined_me")
    }

    fun hangup() {
        when (phase) {
            CallPhase.Incoming -> { decline(); return }
            CallPhase.Outgoing -> {
                if (docReady) {
                    ref().update("state", "canceled")
                    scope.launch { try { Api.post("/api/call", JSONObject().put("call", callId).put("action", "end"), auth = true) } catch (_: Exception) {} }
                }
            }
            CallPhase.Connecting, CallPhase.Active -> {
                val upd = mutableMapOf<String, Any>("state" to "ended")
                if (startedAt > 0) upd["dur"] = ((System.currentTimeMillis() - startedAt) / 1000).toInt()
                ref().update(upd)
            }
            else -> {}
        }
        finish("ended")
    }

    private var handedOver = false

    /** ➕ during a one-to-one call: both of us move into a group call room. */
    fun handOver(ctx: Context, add: List<String>, video: Boolean = this.video) {
        if (phase != CallPhase.Active && phase != CallPhase.Connecting) return
        val p = peer
        val name = peerName
        handedOver = true
        finish("moved")
        handedOver = false
        val roomId = GroupCall.upgrade(ctx, p, add, video, if (add.isEmpty()) name else "")
        if (roomId.isNotEmpty()) ref().update(mapOf("room" to roomId, "rv" to video))
    }

    // ------------------------------------------------------------ controls
    fun toggleMute() { muted = !muted; audioTrack?.setEnabled(!muted) }
    fun toggleSpeaker() { speaker = !speaker; applySpeaker() }
    fun toggleCam() { camOn = !camOn; localVideo?.setEnabled(camOn) }
    fun flipCam() { capturer?.switchCamera(null); front = !front }

    // ------------------------------------------------------------ signalling
    private fun listenDoc() {
        regs += ref().addSnapshotListener { d, _ ->
            if (d == null || !d.exists()) return@addSnapshotListener
            val st = d.getString("state") ?: ""
            val moved = d.getString("room")
            if (moved != null && moved.isNotEmpty() && busy && !handedOver) {
                val v = d.getBoolean("rv") ?: video
                val name = peerName
                finish("moved")
                GroupCall.joinMoved(app, moved, v, name)
                return@addSnapshotListener
            }
            if (caller) {
                val a = d.get("answer") as? Map<*, *>
                if (!answerApplied && a != null && phase == CallPhase.Outgoing) {
                    answerApplied = true
                    stopRingback()
                    phase = CallPhase.Connecting
                    CallService.start(app)
                    scope.launch {
                        try { setRemote(SessionDescription(SessionDescription.Type.ANSWER, a["sdp"] as String)) } catch (_: Exception) { finish("failed") }
                    }
                }
                when (st) {
                    "declined" -> finish("declined")
                    "busy" -> finish("busy")
                    "ended" -> finish("ended")
                }
            } else {
                when (st) {
                    "canceled", "missed" -> finish("missed")
                    "ended" -> finish("ended")
                    "declined" -> finish("declined_me")
                    "accepted" -> if (phase == CallPhase.Incoming) finish("ended")   // answered on another device
                }
            }
        }
    }

    private fun listenCands() {
        val me = Repo.uid ?: ""
        regs += ref().collection("c").addSnapshotListener { s, _ ->
            if (s == null) return@addSnapshotListener
            for (ch in s.documentChanges) {
                if (ch.type != DocumentChange.Type.ADDED) continue
                val d = ch.document
                if (d.getString("from") == me) continue
                val sdp = d.getString("c") ?: continue
                val c = IceCandidate(d.getString("m") ?: "", (d.getLong("i") ?: 0L).toInt(), sdp)
                if (remoteSet) pc?.addIceCandidate(c) else pendingRemote.add(c)
            }
        }
    }

    private fun sendCand(c: IceCandidate) {
        if (!docReady) pendingLocal.add(c) else writeCand(c)
    }

    private fun writeCand(c: IceCandidate) {
        ref().collection("c").add(mapOf("from" to (Repo.uid ?: ""), "c" to c.sdp, "m" to (c.sdpMid ?: ""), "i" to c.sdpMLineIndex))
    }

    private suspend fun fetchIce(): List<PeerConnection.IceServer> {
        val list = mutableListOf(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
        try {
            val j = Api.post("/api/ice", JSONObject(), auth = true)
            val arr = j.optJSONArray("ice")
            if (arr != null) for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val u = o.getJSONArray("urls")
                val urls = (0 until u.length()).map { u.getString(it) }
                val b = PeerConnection.IceServer.builder(urls)
                if (o.has("username")) b.setUsername(o.getString("username")).setPassword(o.getString("credential"))
                list.add(b.createIceServer())
            }
        } catch (_: Exception) {
        }
        return list
    }

    // ------------------------------------------------------------ WebRTC
    private val observer = object : PeerConnection.Observer {
        override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
        override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {}
        override fun onIceConnectionReceivingChange(b: Boolean) {}
        override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
        override fun onIceCandidate(c: IceCandidate?) { if (c != null) main.post { sendCand(c) } }
        override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
        override fun onAddStream(s: MediaStream?) {}
        override fun onRemoveStream(s: MediaStream?) {}
        override fun onDataChannel(d: DataChannel?) {}
        override fun onRenegotiationNeeded() {}
        override fun onTrack(t: RtpTransceiver?) {
            val tr = t?.receiver?.track()
            if (tr is VideoTrack) main.post { remoteVideo = tr }
        }
        override fun onConnectionChange(s: PeerConnection.PeerConnectionState?) {
            main.post {
                when (s) {
                    PeerConnection.PeerConnectionState.CONNECTED -> {
                        dropJob?.cancel()
                        if (phase == CallPhase.Connecting || phase == CallPhase.Outgoing) {
                            phase = CallPhase.Active
                            startedAt = System.currentTimeMillis()
                            timeoutJob?.cancel()
                            stopRingback()
                            CallService.start(app)
                        }
                    }
                    PeerConnection.PeerConnectionState.FAILED -> hangupAs("failed")
                    PeerConnection.PeerConnectionState.DISCONNECTED -> {
                        dropJob?.cancel()
                        dropJob = scope.launch { delay(15_000); hangupAs("failed") }
                    }
                    else -> {}
                }
            }
        }
    }

    private fun hangupAs(reason: String) {
        if (!busy) return
        val upd = mutableMapOf<String, Any>("state" to "ended")
        if (startedAt > 0) upd["dur"] = ((System.currentTimeMillis() - startedAt) / 1000).toInt()
        ref().update(upd)
        finish(reason)
    }

    private fun setupPc(ice: List<PeerConnection.IceServer>) {
        if (factory == null) {
            PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(app).createInitializationOptions())
            factory = PeerConnectionFactory.builder()
                .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
                .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext))
                .setAudioDeviceModule(JavaAudioDeviceModule.builder(app)
                    .setUseHardwareAcousticEchoCanceler(true)
                    .setUseHardwareNoiseSuppressor(true)
                    .createAudioDeviceModule())
                .createPeerConnectionFactory()
        }
        val f = factory!!
        val cfg = PeerConnection.RTCConfiguration(ice).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }
        val p = f.createPeerConnection(cfg, observer) ?: throw IllegalStateException("peer connection")
        pc = p
        val aSrc = f.createAudioSource(MediaConstraints())
        val aTr = f.createAudioTrack("a0", aSrc)
        audioSource = aSrc; audioTrack = aTr
        p.addTrack(aTr, listOf("s0"))
        if (video) startCamera(f, p)
    }

    private fun startCamera(f: PeerConnectionFactory, p: PeerConnection) {
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { camOn = false; return }
        try {
            val en = Camera2Enumerator(app)
            val name = en.deviceNames.firstOrNull { en.isFrontFacing(it) } ?: en.deviceNames.firstOrNull() ?: return
            front = en.isFrontFacing(name)
            val cap = en.createCapturer(name, null)
            val helper = SurfaceTextureHelper.create("cam", egl.eglBaseContext)
            val src = f.createVideoSource(false)
            cap.initialize(helper, app, src.capturerObserver)
            cap.startCapture(640, 480, 24)
            val tr = f.createVideoTrack("v0", src)
            p.addTrack(tr, listOf("s0"))
            capturer = cap; texHelper = helper; videoSource = src
            localVideo = tr
        } catch (_: Exception) {
            camOn = false
        }
    }

    private fun constraints() = MediaConstraints().apply {
        mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
        mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", if (video) "true" else "false"))
    }

    private suspend fun createSdp(offer: Boolean): SessionDescription = suspendCoroutine { k ->
        val obs = object : SdpObserver {
            override fun onCreateSuccess(d: SessionDescription?) {
                if (d != null) k.resume(d) else k.resumeWithException(IllegalStateException("sdp"))
            }
            override fun onSetSuccess() {}
            override fun onCreateFailure(e: String?) { k.resumeWithException(IllegalStateException(e ?: "sdp")) }
            override fun onSetFailure(e: String?) {}
        }
        val p = pc
        if (p == null) k.resumeWithException(IllegalStateException("no pc"))
        else if (offer) p.createOffer(obs, constraints()) else p.createAnswer(obs, constraints())
    }

    private suspend fun setSdp(local: Boolean, d: SessionDescription): Unit = suspendCoroutine { k ->
        val obs = object : SdpObserver {
            override fun onCreateSuccess(d: SessionDescription?) {}
            override fun onSetSuccess() { k.resume(Unit) }
            override fun onCreateFailure(e: String?) {}
            override fun onSetFailure(e: String?) { k.resumeWithException(IllegalStateException(e ?: "set")) }
        }
        val p = pc
        if (p == null) k.resumeWithException(IllegalStateException("no pc"))
        else if (local) p.setLocalDescription(obs, d) else p.setRemoteDescription(obs, d)
    }

    private suspend fun setLocal(d: SessionDescription) = setSdp(true, d)

    private suspend fun setRemote(d: SessionDescription) {
        setSdp(false, d)
        remoteSet = true
        pendingRemote.forEach { pc?.addIceCandidate(it) }
        pendingRemote.clear()
    }

    // ------------------------------------------------------------ sound
    private fun am() = app.getSystemService(AudioManager::class.java)

    private fun audioOn() {
        try { am().mode = AudioManager.MODE_IN_COMMUNICATION } catch (_: Exception) {}
        applySpeaker()
    }

    private fun applySpeaker() {
        try {
            val a = am()
            if (Build.VERSION.SDK_INT >= 31) {
                val want = if (speaker) AudioDeviceInfo.TYPE_BUILTIN_SPEAKER else AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                val dev = a.availableCommunicationDevices.firstOrNull { it.type == want }
                if (dev != null) a.setCommunicationDevice(dev) else a.clearCommunicationDevice()
            } else {
                @Suppress("DEPRECATION")
                a.isSpeakerphoneOn = speaker
            }
        } catch (_: Exception) {
        }
    }

    private fun audioOff() {
        try {
            val a = am()
            if (Build.VERSION.SDK_INT >= 31) a.clearCommunicationDevice() else {
                @Suppress("DEPRECATION")
                a.isSpeakerphoneOn = false
            }
            a.mode = AudioManager.MODE_NORMAL
        } catch (_: Exception) {
        }
    }

    private fun startRinging() = Ringer.start(app)

    private fun stopRinging() = Ringer.stop(app)

    private fun startRingback() {
        try { tone = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 70).apply { startTone(ToneGenerator.TONE_SUP_RINGTONE) } } catch (_: Exception) {}
    }

    private fun stopRingback() {
        try { tone?.stopTone(); tone?.release() } catch (_: Exception) {}
        tone = null
    }

    // ------------------------------------------------------------ end
    fun finish(reason: String) {
        if (!busy) return
        val wasIncoming = phase == CallPhase.Incoming
        endReason = reason
        phase = CallPhase.Ended
        timeoutJob?.cancel(); dropJob?.cancel()
        stopRinging(); stopRingback()
        regs.forEach { it.remove() }; regs.clear()
        val oldPc = pc; val oldCap = capturer; val oldHelper = texHelper; val oldVSrc = videoSource
        val oldATr = audioTrack; val oldASrc = audioSource; val oldVTr = localVideo
        pc = null; capturer = null; texHelper = null; videoSource = null; audioTrack = null; audioSource = null
        localVideo = null; remoteVideo = null
        audioOff()
        // let the screen drop its video views before the tracks are freed
        scope.launch {
            delay(500)
            try { oldCap?.stopCapture() } catch (_: Exception) {}
            try { oldCap?.dispose() } catch (_: Exception) {}
            try { oldPc?.close() } catch (_: Exception) {}
            try { oldPc?.dispose() } catch (_: Exception) {}
            try { oldVTr?.dispose() } catch (_: Exception) {}
            try { oldVSrc?.dispose() } catch (_: Exception) {}
            try { oldHelper?.dispose() } catch (_: Exception) {}
            try { oldATr?.dispose() } catch (_: Exception) {}
            try { oldASrc?.dispose() } catch (_: Exception) {}
        }
        if (wasIncoming && reason == "missed") CallNotif.missed(app, peerName, video)
        CallService.stop(app)
        scope.launch { delay(1800); if (phase == CallPhase.Ended) phase = CallPhase.Idle }
    }
}

// ---------------------------------------------------------------- start a call from any screen
@Composable
fun rememberCaller(other: String): (Boolean) -> Unit {
    val ctx = LocalContext.current
    val wantVideo = remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val mic = r[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!mic) Toast.makeText(ctx, t("mic_need_call"), Toast.LENGTH_LONG).show()
        else placeCall(ctx, other, wantVideo.value)
    }
    return { v ->
        wantVideo.value = v
        val perms = if (v) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA) else arrayOf(Manifest.permission.RECORD_AUDIO)
        launcher.launch(perms)
    }
}

private fun placeCall(ctx: Context, other: String, video: Boolean) {
    if (CallManager.busy) {
        ctx.startActivity(Intent(ctx, CallActivity::class.java))
        return
    }
    CallManager.startOutgoing(ctx, other, video)
    ctx.startActivity(Intent(ctx, CallActivity::class.java))
}

// ---------------------------------------------------------------- foreground service (keeps the call alive)
class CallService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Prefs.init(this)
        val n = CallNotif.build(this)
        var type = 0
        if (Build.VERSION.SDK_INT >= 29) type = ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
        val ph = CallManager.phase
        val gp = GroupCall.phase
        val live = ph == CallPhase.Outgoing || ph == CallPhase.Connecting || ph == CallPhase.Active ||
            gp == GPhase.Connecting || gp == GPhase.Live
        if (Build.VERSION.SDK_INT >= 30 && live) {
            if (granted(Manifest.permission.RECORD_AUDIO)) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if ((CallManager.video || GroupCall.video) && granted(Manifest.permission.CAMERA)) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        }
        try {
            ServiceCompat.startForeground(this, CallNotif.ID, n, type)
        } catch (e: Exception) {
            try {
                ServiceCompat.startForeground(this, CallNotif.ID, n, if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL else 0)
            } catch (_: Exception) {
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    companion object {
        fun start(c: Context) {
            try { ContextCompat.startForegroundService(c, Intent(c, CallService::class.java)) } catch (_: Exception) {}
        }
        fun stop(c: Context) {
            try { c.stopService(Intent(c, CallService::class.java)) } catch (_: Exception) {}
            try { NotificationManagerCompat.from(c).cancel(CallNotif.ID) } catch (_: Exception) {}
        }
    }
}

/**
 * Incoming-call ringing.
 * Many phones (Xiaomi, Oppo, Vivo, Samsung with battery saver…) block an app from playing sound by itself
 * while it is in the background, so the ringtone rides on the ringing notification (it repeats until answered).
 * If notifications for calls are switched off, the app plays the ringtone itself as before.
 */
object Ringer {
    private var own = false
    private var vibrating = false

    private fun vibrator(c: Context): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(VibratorManager::class.java).defaultVibrator
        else c.getSystemService(Vibrator::class.java)
    } catch (_: Exception) { null }

    fun start(c: Context) {
        Prefs.init(c)
        stop(c)
        if (CallNotif.ringsBySystem(c)) {
            own = false
            CallNotif.postRinging(c)
        } else {
            own = true
            Sounds.startRing(c)
            if (Prefs.vibrate) try {
                val v = vibrator(c)
                if (v != null && Build.VERSION.SDK_INT >= 26) { v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 900, 1100), 0)); vibrating = true }
            } catch (_: Exception) {}
            CallNotif.postRinging(c)
        }
    }

    fun stop(c: Context) {
        Sounds.stopRing()
        if (vibrating) { try { vibrator(c)?.cancel() } catch (_: Exception) {}; vibrating = false }
        own = false
    }
}

/** Buttons inside the call notification. */
class CallAction : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (GroupCall.busy) {
            when (i.action) { "decline" -> GroupCall.decline(); "hangup" -> GroupCall.leave() }
            return
        }
        if (!CallManager.busy) { CallService.stop(c); return }
        when (i.action) {
            "decline" -> CallManager.decline()
            "hangup" -> CallManager.hangup()
        }
    }
}

object CallNotif {
    const val ID = 7701
    private const val RING = "calls_ring"
    private const val LIVE = "calls_live"
    private const val MISSED = "calls_missed"

    private fun channels(c: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = c.getSystemService(NotificationManager::class.java)
        ringChannel(c)
        if (nm.getNotificationChannel(LIVE) == null) {
            nm.createNotificationChannel(NotificationChannel(LIVE, "Ongoing calls", NotificationManager.IMPORTANCE_LOW))
        }
        if (nm.getNotificationChannel(MISSED) == null) {
            nm.createNotificationChannel(NotificationChannel(MISSED, "Missed calls", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    /** The ringing channel carries the chosen ringtone; a channel's sound can't change, so each choice gets its own. */
    fun ringChannel(c: Context): String {
        val id = "ring2_" + Prefs.ring + (if (Prefs.vibrate) "_v" else "_n")
        if (Build.VERSION.SDK_INT < 26) return id
        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) == null) {
            nm.notificationChannels.filter { (it.id.startsWith("ring2_") || it.id == RING) && it.id != id }.forEach {
                try { nm.deleteNotificationChannel(it.id) } catch (_: Exception) {}
            }
            val ch = NotificationChannel(id, t("in_calls_ch"), NotificationManager.IMPORTANCE_HIGH)
            val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val res = Sounds.ringRes(Prefs.ring)
            ch.setSound(if (res != 0) Sounds.uri(c, res) else Settings.System.DEFAULT_RINGTONE_URI, attrs)
            ch.enableVibration(Prefs.vibrate)
            ch.vibrationPattern = if (Prefs.vibrate) longArrayOf(0, 900, 1100) else longArrayOf(0)
            ch.lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            ch.setBypassDnd(false)
            nm.createNotificationChannel(ch)
        }
        return id
    }

    /** True when the phone itself will ring through the call notification. */
    fun ringsBySystem(c: Context): Boolean {
        if (Build.VERSION.SDK_INT < 26) return false
        return try {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (!nm.areNotificationsEnabled()) return false
            val ch = nm.getNotificationChannel(ringChannel(c)) ?: return false
            ch.importance >= NotificationManager.IMPORTANCE_DEFAULT && ch.sound != null
        } catch (_: Exception) { false }
    }

    /** Shows the ringing notification right away (also when the phone refuses to start the call service). */
    fun postRinging(c: Context) {
        try { NotificationManagerCompat.from(c).notify(ID, build(c)) } catch (_: SecurityException) {} catch (_: Exception) {}
    }

    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    fun build(c: Context): android.app.Notification {
        channels(c)
        if (GroupCall.busy) return buildGroup(c)
        val m = CallManager
        val person = Person.Builder().setName(m.peerName.ifBlank { "Golpo Chat" }).setImportant(true).build()
        val open = PendingIntent.getActivity(c, 11, Intent(c, CallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), FLAGS)
        if (m.phase == CallPhase.Incoming) {
            val answer = PendingIntent.getActivity(c, 12,
                Intent(c, CallActivity::class.java).setAction("answer").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), FLAGS)
            val decline = PendingIntent.getBroadcast(c, 13, Intent(c, CallAction::class.java).setAction("decline"), FLAGS)
            return insistent(NotificationCompat.Builder(c, ringChannel(c))
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(0xFF1E9BF0.toInt())
                .setContentTitle(m.peerName.ifBlank { "Golpo Chat" })
                .setContentText(t(if (m.video) "in_video" else "in_audio"))
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setFullScreenIntent(open, true)
                .setContentIntent(open)
                .setStyle(NotificationCompat.CallStyle.forIncomingCall(person, decline, answer)), c)
        }
        val hang = PendingIntent.getBroadcast(c, 14, Intent(c, CallAction::class.java).setAction("hangup"), FLAGS)
        val b = NotificationCompat.Builder(c, LIVE)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFF1E9BF0.toInt())
            .setContentTitle(m.peerName.ifBlank { "Golpo Chat" })
            .setContentText(t(when (m.phase) { CallPhase.Outgoing -> "calling"; CallPhase.Active -> if (m.video) "video_call" else "voice_call"; else -> "connecting" }))
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .setContentIntent(open)
            .setStyle(NotificationCompat.CallStyle.forOngoingCall(person, hang))
        if (m.phase == CallPhase.Active && m.startedAt > 0) b.setUsesChronometer(true).setWhen(m.startedAt)
        return b.build()
    }

    private fun buildGroup(c: Context): android.app.Notification {
        val g = GroupCall
        val name = g.title.ifBlank { t("group_call") }
        val person = Person.Builder().setName(name).setImportant(true).build()
        val open = PendingIntent.getActivity(c, 21, Intent(c, GroupCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), FLAGS)
        if (g.phase == GPhase.Ringing) {
            val answer = PendingIntent.getActivity(c, 22,
                Intent(c, GroupCallActivity::class.java).setAction("answer").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), FLAGS)
            val decline = PendingIntent.getBroadcast(c, 23, Intent(c, CallAction::class.java).setAction("decline"), FLAGS)
            return insistent(NotificationCompat.Builder(c, ringChannel(c))
                .setSmallIcon(R.drawable.ic_stat).setColor(0xFF1E9BF0.toInt())
                .setContentTitle(name)
                .setContentText((if (g.caller.isNotBlank()) g.caller + " · " else "") + t(if (g.video) "in_gvideo" else "in_gaudio"))
                .setCategory(NotificationCompat.CATEGORY_CALL).setPriority(NotificationCompat.PRIORITY_MAX)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setOnlyAlertOnce(true)
                .setOngoing(true).setFullScreenIntent(open, true).setContentIntent(open)
                .setStyle(NotificationCompat.CallStyle.forIncomingCall(person, decline, answer)), c)
        }
        val hang = PendingIntent.getBroadcast(c, 24, Intent(c, CallAction::class.java).setAction("hangup"), FLAGS)
        val b = NotificationCompat.Builder(c, LIVE)
            .setSmallIcon(R.drawable.ic_stat).setColor(0xFF1E9BF0.toInt())
            .setContentTitle(name)
            .setContentText(if (g.phase == GPhase.Live) t("group_call") else t("connecting"))
            .setCategory(NotificationCompat.CATEGORY_CALL).setOngoing(true).setContentIntent(open)
            .setStyle(NotificationCompat.CallStyle.forOngoingCall(person, hang))
        if (g.phase == GPhase.Live && g.startedAt > 0) b.setUsesChronometer(true).setWhen(g.startedAt)
        return b.build()
    }

    /** The ringtone repeats until the call is answered or ends (old phones: the sound is set on the notification). */
    private fun insistent(b: NotificationCompat.Builder, c: Context): android.app.Notification {
        if (Build.VERSION.SDK_INT < 26) {
            val res = Sounds.ringRes(Prefs.ring)
            b.setSound(if (res != 0) Sounds.uri(c, res) else Settings.System.DEFAULT_RINGTONE_URI, AudioManager.STREAM_RING)
            if (Prefs.vibrate) b.setVibrate(longArrayOf(0, 900, 1100))
        }
        val n = b.build()
        if (ringsBySystem(c) || Build.VERSION.SDK_INT < 26) n.flags = n.flags or android.app.Notification.FLAG_INSISTENT
        return n
    }

    fun missed(c: Context, name: String, video: Boolean) {
        channels(c)
        val open = PendingIntent.getActivity(c, 15, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), FLAGS)
        val n = NotificationCompat.Builder(c, MISSED)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFFE0344F.toInt())
            .setContentTitle(t("missed_call"))
            .setContentText(name.ifBlank { "Golpo Chat" } + " · " + t(if (video) "video_call" else "voice_call"))
            .setCategory(NotificationCompat.CATEGORY_MISSED_CALL)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try { NotificationManagerCompat.from(c).notify((System.currentTimeMillis() % 100000).toInt() + 9000, n) } catch (_: SecurityException) {}
    }
}
