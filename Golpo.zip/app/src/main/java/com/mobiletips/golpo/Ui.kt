package com.mobiletips.golpo

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ---------------------------------------------------------------- press animation (every button)
/**
 * A tap that shrinks the button a little while the finger is down and springs back
 * (with the ripple), so every press is clearly felt. Put it BEFORE background / border
 * so those shrink too:  Modifier.size(48.dp).press(CircleShape) { … }.background(Brand)
 */
fun Modifier.press(shape: Shape = RoundedCornerShape(14.dp), enabled: Boolean = true, scaleTo: Float = 0.92f,
                   onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val down by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (down && enabled) scaleTo else 1f, spring(dampingRatio = 0.5f, stiffness = 800f), label = "press")
    this.graphicsLayer { scaleX = s; scaleY = s }
        .clip(shape)
        .clickable(interactionSource = src, indication = LocalIndication.current, enabled = enabled, onClick = onClick)
}

/** Same feel for full-width list rows: a softer shrink. */
fun Modifier.pressRow(enabled: Boolean = true, onClick: () -> Unit): Modifier = press(RoundedCornerShape(0.dp), enabled, 0.985f, onClick)

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 58.dp).background(P.bg).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            Box(Modifier.size(44.dp).press(CircleShape) { onBack() }, contentAlignment = Alignment.Center) { Ic("back") }
        } else Spacer(Modifier.width(10.dp))
        Text(title, color = P.tx, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 6.dp))
        actions()
    }
}

@Composable
fun IconBtn(name: String, tint: Color = P.tx, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).press(CircleShape) { onClick() }, contentAlignment = Alignment.Center) { Ic(name, tint) }
}

/** imo-style round button: white, thin border, coloured icon. */
@Composable
fun RingBtn(name: String, tint: Color = Brand, size: androidx.compose.ui.unit.Dp = 44.dp, onClick: () -> Unit) {
    Box(Modifier.size(size).press(CircleShape) { onClick() }.background(P.card).border(1.dp, P.ln, CircleShape),
        contentAlignment = Alignment.Center) { Ic(name, tint, size * 0.5f) }
}

/** White button with a clear border (secondary action). */
@Composable
fun OutlineButton(text: String, icon: String? = null, color: Color = Brand, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(
        modifier.height(50.dp).press(RoundedCornerShape(14.dp)) { onClick() }.background(P.card)
            .border(1.5.dp, color.copy(alpha = .55f), RoundedCornerShape(14.dp)).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Ic(icon, color, 20.dp); Spacer(Modifier.width(8.dp)) }
        Text(text, color = color, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
    }
}

@Composable
fun Confirm(title: String, text: String, ok: String, cancel: String = t("cancel"), danger: Boolean = false,
            onCancel: () -> Unit, onOk: () -> Unit) {
    Dialog(onDismissRequest = onCancel) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(P.card).padding(22.dp)) {
            Text(title, color = P.tx, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            if (text.isNotEmpty()) {
                Spacer(Modifier.size(8.dp))
                Text(text, color = P.tx2, fontSize = 14.5.sp, lineHeight = 21.sp)
            }
            Spacer(Modifier.size(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Text(cancel, color = Brand, fontWeight = FontWeight.Bold,
                    modifier = Modifier.press(RoundedCornerShape(12.dp)) { onCancel() }.border(1.dp, P.ln, RoundedCornerShape(12.dp))
                        .padding(horizontal = 16.dp, vertical = 11.dp))
                Spacer(Modifier.width(10.dp))
                Text(ok, color = Color.White, fontWeight = FontWeight.Bold,
                    modifier = Modifier.press(RoundedCornerShape(12.dp)) { onOk() }.background(if (danger) Red else Brand)
                        .padding(horizontal = 18.dp, vertical = 12.dp))
            }
        }
    }
}

/** A simple sheet that slides up from the bottom (used for "More" menus). */
@Composable
fun BottomSheet(onDismiss: () -> Unit, dark: Boolean = false, content: @Composable () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDismiss() },
            contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier.fillMaxWidth().padding(10.dp).windowInsetsPadding(WindowInsets.safeDrawing)
                    .clip(RoundedCornerShape(26.dp)).background(if (dark) Color(0xFF16222E) else P.card)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                    .padding(vertical = 10.dp)
            ) {
                Box(Modifier.align(Alignment.CenterHorizontally).width(40.dp).height(4.dp).clip(RoundedCornerShape(2.dp))
                    .background((if (dark) Color.White else P.tx2).copy(alpha = .3f)))
                Spacer(Modifier.height(8.dp))
                content()
            }
        }
    }
}

@Composable
fun SheetRow(icon: String, text: String, dark: Boolean = false, color: Color? = null, onClick: () -> Unit) {
    val c = color ?: if (dark) Color.White else P.tx
    Row(Modifier.fillMaxWidth().pressRow { onClick() }.padding(horizontal = 22.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(if (dark) Color.White.copy(alpha = .1f) else P.pill), contentAlignment = Alignment.Center) {
            Ic(icon, if (dark) Color.White else (color ?: Brand), 21.dp)
        }
        Spacer(Modifier.width(16.dp))
        Text(text, color = c, fontSize = 16.sp, fontWeight = FontWeight.Medium)
    }
}

// ---------------------------------------------------------------- language
/** 🌐 → two clear buttons: English / বাংলা */
@Composable
fun LangDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(P.card).padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(56.dp).clip(CircleShape).background(P.pill), contentAlignment = Alignment.Center) { Ic("o_globe", Brand, 30.dp) }
            Spacer(Modifier.height(12.dp))
            Text("Language · ভাষা", color = P.tx, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(18.dp))
            listOf("en" to "English", "bn" to "বাংলা").forEach { (k, label) ->
                val on = Prefs.lang == k
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 5.dp).height(56.dp)
                        .press(RoundedCornerShape(16.dp)) { Prefs.setLang(k); onDismiss() }
                        .background(if (on) Brand else P.card)
                        .border(1.5.dp, if (on) Brand else P.ln, RoundedCornerShape(16.dp)).padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(label, color = if (on) Color.White else P.tx, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    if (on) Ic("check", Color.White, 22.dp)
                }
            }
        }
    }
}

/** Small 🌐 button for the screens before login. */
@Composable
fun GlobeBtn(modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Row(
        modifier.height(38.dp).press(RoundedCornerShape(19.dp)) { open = true }.background(P.card)
            .border(1.dp, P.ln, RoundedCornerShape(19.dp)).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ic("o_globe", Brand, 19.dp); Spacer(Modifier.width(6.dp))
        Text(if (Prefs.lang == "bn") "বাংলা" else "English", color = P.tx, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
    }
    if (open) LangDialog { open = false }
}

// ---------------------------------------------------------------- photos & videos
object Media {
    /** Decodes a picked photo the right way up, at most [maxSide] pixels. */
    suspend fun bitmap(c: Context, uri: Uri, maxSide: Int = 2048): Bitmap = withContext(Dispatchers.IO) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxSide || bounds.outHeight / (sample * 2) >= maxSide) sample *= 2
        var bmp = c.contentResolver.openInputStream(uri)!!.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw IllegalStateException("bad image")
        val rot = try {
            c.contentResolver.openInputStream(uri)!!.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            }
        } catch (_: Exception) { 0f }
        val scale = minOf(1f, maxSide.toFloat() / maxOf(bmp.width, bmp.height))
        if (rot != 0f || scale < 1f) {
            val m = Matrix().apply { postScale(scale, scale); postRotate(rot) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        bmp
    }

    fun toJpeg(bmp: Bitmap, q: Int = 82): ByteArray =
        ByteArrayOutputStream().use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, q, out); out.toByteArray() }

    suspend fun jpeg(c: Context, uri: Uri, maxSide: Int = 1280): ByteArray = withContext(Dispatchers.IO) { toJpeg(bitmap(c, uri, maxSide), 80) }

    /** A photo from the internet (for "edit my current photo"). */
    suspend fun bitmapFromUrl(url: String): Bitmap = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000; c.readTimeout = 30000
            c.inputStream.use { BitmapFactory.decodeStream(it) } ?: throw IllegalStateException("bad image")
        } finally { c.disconnect() }
    }

    fun size(c: Context, uri: Uri): Long = try {
        c.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) cur.getLong(0) else -1L
        } ?: -1L
    } catch (_: Exception) { -1L }

    /** Length (seconds) and a small first-frame picture of a video. */
    suspend fun videoInfo(c: Context, uri: Uri): Pair<Int, ByteArray?> = withContext(Dispatchers.IO) {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(c, uri)
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var frame = try { r.getFrameAtTime(500_000) } catch (_: Exception) { null }
            if (frame != null) {
                val sc = minOf(1f, 640f / maxOf(frame.width, frame.height))
                if (sc < 1f) frame = Bitmap.createScaledBitmap(frame, (frame.width * sc).roundToInt(), (frame.height * sc).roundToInt(), true)
            }
            ((ms + 500) / 1000).toInt() to frame?.let { toJpeg(it, 75) }
        } catch (_: Exception) {
            0 to null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }
}

// ---------------------------------------------------------------- save to phone / share to other apps
object Saver {
    private fun name(url: String, video: Boolean) = "Golpo_" + System.currentTimeMillis() + if (video) ".mp4" else ".jpg"

    fun download(c: Context, url: String, video: Boolean) {
        try {
            val dm = c.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val r = DownloadManager.Request(Uri.parse(url))
                .setTitle(name(url, video))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            val dir = if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
            if (Build.VERSION.SDK_INT >= 29) r.setDestinationInExternalPublicDir(dir, "Golpo/" + name(url, video))
            else r.setDestinationInExternalFilesDir(c, dir, name(url, video))
            dm.enqueue(r)
            toast(c, t("downloading"))
        } catch (_: Exception) {
            toast(c, t("e_download"))
        }
    }

    /** Downloads into the app cache, then opens the Android share sheet. */
    suspend fun share(c: Context, url: String, video: Boolean) {
        try {
            val f = withContext(Dispatchers.IO) {
                val dir = File(c.cacheDir, "share").apply { mkdirs() }
                dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 3600_000) it.delete() }
                val out = File(dir, name(url, video))
                val con = URL(url).openConnection() as HttpURLConnection
                try {
                    con.connectTimeout = 15000; con.readTimeout = 60000
                    con.inputStream.use { inp -> out.outputStream().use { inp.copyTo(it) } }
                } finally { con.disconnect() }
                out
            }
            val uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = if (video) "video/mp4" else "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            c.startActivity(Intent.createChooser(i, t("share")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            toast(c, t("e_download"))
        }
    }

    fun shareText(c: Context, text: String) {
        try {
            c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, t("share"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }
}

// ---------------------------------------------------------------- full-screen photo / video viewer (zoom, download, share)
@Composable
fun MediaViewer(url: String, video: Boolean, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (video) {
                VideoPlayer(url, Modifier.fillMaxSize().padding(top = 60.dp))
            } else {
                coil.compose.AsyncImage(
                    url, null, contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                        .pointerInput(Unit) {
                            detectTransformGestures { _, p, z, _ ->
                                zoom = (zoom * z).coerceIn(1f, 5f)
                                pan = if (zoom == 1f) Offset.Zero else pan + p
                            }
                        }
                        .graphicsLayer { scaleX = zoom; scaleY = zoom; translationX = pan.x; translationY = pan.y }
                )
            }
            Row(
                Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.safeDrawing)
                    .background(Color.Black.copy(alpha = .35f)).padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconBtn("close", Color.White) { onClose() }
                Spacer(Modifier.weight(1f))
                IconBtn("o_download", Color.White) { Saver.download(ctx, url, video) }
                IconBtn("share", Color.White) { scope.launch { Saver.share(ctx, url, video) } }
            }
        }
    }
}

/** Plays a video from a link with the phone's own player controls. */
@Composable
fun VideoPlayer(url: String, modifier: Modifier, autoPlay: Boolean = true, controls: Boolean = true, onDone: (() -> Unit)? = null,
                onReady: ((Int) -> Unit)? = null) {
    var loading by remember { mutableStateOf(true) }
    Box(modifier, contentAlignment = Alignment.Center) {
        androidx.compose.ui.viewinterop.AndroidView(
            factory = { c ->
                android.widget.VideoView(c).apply {
                    if (controls) setMediaController(android.widget.MediaController(c).also { it.setAnchorView(this) })
                    setOnPreparedListener { mp -> loading = false; onReady?.invoke(mp.duration); if (autoPlay) start() }
                    setOnCompletionListener { onDone?.invoke() }
                    setOnErrorListener { _, _, _ -> loading = false; true }
                    setVideoURI(Uri.parse(url))
                }
            },
            onRelease = { try { it.stopPlayback() } catch (_: Exception) {} },
            modifier = Modifier.fillMaxSize(),
        )
        if (loading) CircularProgressIndicator(color = Color.White)
    }
}

// ---------------------------------------------------------------- crop / zoom a photo (profile & group pictures)
/**
 * Pinch to zoom, drag to move, ⟳ to turn. The circle shows what will be kept.
 * Returns a square JPEG of [outSize] pixels.
 */
@Composable
fun CropDialog(source: Bitmap, outSize: Int = 640, onCancel: () -> Unit, onDone: (ByteArray) -> Unit) {
    var bmp by remember { mutableStateOf(source) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    var boxPx by remember { mutableFloatStateOf(1f) }
    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xFF0D141C)).windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn("close", Color.White) { onCancel() }
                Text(t("edit_photo"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconBtn("rotate", Color.White) {
                    val m = Matrix().apply { postRotate(90f) }
                    bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                    zoom = 1f; off = Offset.Zero
                }
            }
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                val density = LocalDensity.current
                val wPx = with(density) { maxWidth.toPx() }
                val hPx = with(density) { maxHeight.toPx() }
                val box = min(wPx, hPx) * 0.86f                 // the crop square on screen
                androidx.compose.runtime.SideEffect { boxPx = box }
                val b = bmp
                val base = max(box / b.width, box / b.height)    // picture covers the square at zoom 1
                fun clamp(o: Offset, z: Float): Offset {
                    val mx = (b.width * base * z - box) / 2f
                    val my = (b.height * base * z - box) / 2f
                    return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
                }
                val dispW = b.width * base * zoom
                val dispH = b.height * base * zoom
                val img = remember(b) { b.asImageBitmap() }
                Box(Modifier.fillMaxSize().pointerInput(b) {
                    detectTransformGestures { _, p, z, _ ->
                        val nz = (zoom * z).coerceIn(1f, 6f)
                        zoom = nz
                        off = clamp(off + p, nz)
                    }
                }) {
                    Image(img, null, contentScale = ContentScale.FillBounds,
                        modifier = Modifier.graphicsLayer {
                            translationX = (wPx - dispW) / 2f + off.x
                            translationY = (hPx - dispH) / 2f + off.y
                        }.wrapContentSize(Alignment.TopStart, unbounded = true)
                            .size(with(density) { dispW.toDp() }, with(density) { dispH.toDp() }))
                    Canvas(Modifier.fillMaxSize()) {
                        val circle = Path().apply {
                            addOval(androidx.compose.ui.geometry.Rect(Offset((wPx - box) / 2f, (hPx - box) / 2f), Size(box, box)))
                        }
                        clipPath(circle, ClipOp.Difference) { drawRect(Color.Black.copy(alpha = .6f)) }
                        drawPath(circle, Color.White, style = Stroke(width = 2.dp.toPx()))
                    }
                }
            }
            Text(t("crop_hint"), color = Color.White.copy(alpha = .7f), fontSize = 13.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(8.dp))
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f).height(52.dp).press(RoundedCornerShape(16.dp)) { onCancel() }
                    .border(1.5.dp, Color.White.copy(alpha = .5f), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Text(t("cancel"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Box(Modifier.weight(1f).height(52.dp).press(RoundedCornerShape(16.dp)) {
                    onDone(cropNow(bmp, boxPx, zoom, off, outSize))
                }.background(Brand), contentAlignment = Alignment.Center) {
                    Text(t("save"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

/** Which part of the original is inside the circle: one screen pixel = 1 / (base * zoom) picture pixels. */
private fun cropNow(b: Bitmap, box: Float, zoom: Float, off: Offset, outSize: Int): ByteArray {
    val base = max(box / b.width, box / b.height)
    val k = base * zoom
    val side = box / k
    val cx = b.width / 2f - off.x / k
    val cy = b.height / 2f - off.y / k
    val s = side.roundToInt().coerceIn(1, min(b.width, b.height))
    val x = (cx - side / 2f).roundToInt().coerceIn(0, b.width - s)
    val y = (cy - side / 2f).roundToInt().coerceIn(0, b.height - s)
    val part = Bitmap.createBitmap(b, x, y, s, s)
    val out = if (s > outSize) Bitmap.createScaledBitmap(part, outSize, outSize, true) else part
    return Media.toJpeg(out, 85)
}

// ---------------------------------------------------------------- voice message player (one at a time)
object Player {
    var playing by mutableStateOf("")
    var progress by mutableFloatStateOf(0f)
    private var mp: MediaPlayer? = null

    fun toggle(id: String, url: String) {
        if (playing == id) { stop(); return }
        stop()
        playing = id
        progress = 0f
        try {
            mp = MediaPlayer().apply {
                setDataSource(url)
                setOnPreparedListener { it.start() }
                setOnCompletionListener { stop() }
                setOnErrorListener { _, _, _ -> stop(); true }
                prepareAsync()
            }
        } catch (_: Exception) { stop() }
    }

    fun tick() {
        val p = mp ?: return
        try { if (p.isPlaying && p.duration > 0) progress = p.currentPosition.toFloat() / p.duration } catch (_: Exception) {}
    }

    fun stop() {
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        playing = ""
        progress = 0f
    }
}
