package com.mobiletips.golpo

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------- Settings tab (root, imo style: white cards, clear outline icons)
@Composable
fun SettingsTab(editProfile: () -> Unit, open: (String) -> Unit) {
    val ctx = LocalContext.current
    val me = Repo.me
    var askOut by remember { mutableStateOf(false) }
    var lang by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(P.bg2).verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(6.dp))
        ProCard {
            Row(Modifier.fillMaxWidth().pressRow { editProfile() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(me?.shown ?: "?", me?.photo ?: "", Repo.uid ?: "", 64.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(me?.shown ?: "", color = P.tx, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text(me?.about ?: "", color = P.tx2, fontSize = 13.sp, maxLines = 2)
                    Text("+88 " + num(me?.phone ?: ""), color = P.tx2, fontSize = 12.5.sp)
                }
                RingBtn("edit", Brand, 40.dp) { editProfile() }
            }
        }
        ProCard {
            ProRow("o_bell", t("s_notif"), onClick = { open("notif") }) { Chevron() }
            ProRow("o_call", t("call_setup"), onClick = { open("callsetup") }) { Chevron() }
            ProRow("o_chat", t("s_chats"), onClick = { open("chats") }) { Chevron() }
            ProRow("o_storage", t("s_storage"), onClick = { open("storage") }) { Chevron() }
            // the row says "Language" when the app is in Bangla, and "ভাষা" when it is in English
            ProRow("o_globe", if (Prefs.lang == "bn") "Language" else "ভাষা", onClick = { lang = true }) {
                Text(t("lang_now"), color = P.tx2, fontSize = 14.sp, modifier = Modifier.padding(end = 4.dp)); Chevron()
            }
        }
        ProCard {
            ProRow("o_shield", t("s_privacy"), onClick = { open("privacy") }) { Chevron() }
            ProRow("block", t("blocked_list"), onClick = { open("blocked") }) { Chevron() }
        }
        ProCard {
            ProRow("o_help", t("help"), onClick = { open("help") }) { Chevron() }
            ProRow("share", t("invite"), onClick = {
                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, t("invite_text"))
                }, t("invite")))
            }) { Chevron() }
            ProRow("o_info", t("about_app"), onClick = { open("help") }) {
                Text(BuildConfig.VERSION_NAME, color = P.tx2, fontSize = 14.sp, modifier = Modifier.padding(end = 4.dp)); Chevron()
            }
        }
        ProCard {
            ProRow("logout", t("logout"), tint = Red, onClick = { askOut = true })
            ProRow("o_delete", t("delete_acc"), tint = Red, onClick = { open("delete") }) { Chevron() }
        }
        Text("Golpo Chat ${BuildConfig.VERSION_NAME}\nfrom Mobile Tips", color = P.tx2, fontSize = 12.5.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(20.dp))
    }
    if (askOut) Confirm(t("logout") + "?", t("logout_q"), t("logout"), danger = true, onCancel = { askOut = false }) {
        askOut = false
        Repo.signOut()
    }
    if (lang) LangDialog { lang = false }
}

@Composable
private fun Chevron() = Ic("right", P.tx2, 22.dp)

@Composable
private fun SwitchRow(icon: String, color: Color, title: String, sub: String?, on: Boolean, set: (Boolean) -> Unit) {
    ProRow(icon, title, sub = sub, onClick = { set(!on) }) { ProSwitch(on) { set(it) } }
}

// ---------------------------------------------------------------- sub pages
@Composable
fun SettingsPage(name: String, onBack: () -> Unit, open: (String) -> Unit, openChat: (String) -> Unit) {
    val title = when (name) {
        "privacy" -> t("s_privacy"); "blocked" -> t("blocked_list"); "notif" -> t("s_notif")
        "tone" -> t("msg_tone"); "ring" -> t("ringtone"); "chats" -> t("s_chats")
        "seen" -> t("p_seen"); "pphoto" -> t("p_photo"); "storage" -> t("s_storage"); "delete" -> t("delete_acc")
        "callsetup" -> t("call_setup"); else -> t("help")
    }
    Column(Modifier.fillMaxSize().background(P.bg2)) {
        TopBar(title, onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            when (name) {
                "privacy" -> PrivacyPage(open)
                "blocked" -> BlockedPage(openChat)
                "notif" -> NotifPage(open)
                "tone" -> TonePage(ring = false)
                "ring" -> TonePage(ring = true)
                "chats" -> ChatsPage()
                "seen" -> WhoPage("seen")
                "pphoto" -> WhoPage("pphoto")
                "storage" -> StoragePage()
                "delete" -> DeletePage()
                "callsetup" -> CallSetupPage()
                else -> HelpPage()
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}

@Composable
private fun PrivacyPage(open: (String) -> Unit) {
    val n = Repo.me?.blocked?.size ?: 0
    val me = Repo.me
    Card {
        ProRow("eye", t("p_seen"), sub = whoName(me?.seen ?: "all"), onClick = { open("seen") }) { Chevron() }
        ProRow("o_person", t("p_photo"), sub = whoName(me?.pphoto ?: "all"), onClick = { open("pphoto") }) { Chevron() }
        SwitchRow("check2", Mint, t("p_receipts"), t("p_receipts_s"), me?.receipts != false) { Repo.setPriv("receipts", it) }
    }
    Card {
        ProRow("block", t("blocked_list"), sub = if (n > 0) num("$n") else t("no_blocked"), onClick = { open("blocked") }) { Chevron() }
    }
}

@Composable
private fun BlockedPage(openChat: (String) -> Unit) {
    val list = Repo.me?.blocked ?: emptyList()
    var ask by remember { mutableStateOf("") }
    if (list.isEmpty()) {
        Text(t("no_blocked"), color = P.tx2, modifier = Modifier.fillMaxWidth().padding(30.dp), textAlign = TextAlign.Center)
    }
    Card {
        list.forEach { id ->
            val u = Repo.user(id)
            Row(Modifier.fillMaxWidth().clickable { openChat(id) }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(u?.shown ?: "?", u?.photo ?: "", id, 46.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(u?.shown ?: "…", color = P.tx, fontWeight = FontWeight.Bold, fontSize = 15.5.sp)
                    Text("+88 " + num(u?.phone ?: ""), color = P.tx2, fontSize = 13.sp)
                }
                Text(t("unblock"), color = Brand, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { ask = id }.padding(10.dp))
            }
        }
    }
    if (ask.isNotEmpty()) {
        val nm = Repo.user(ask)?.shown ?: ""
        Confirm(t("unblock") + " $nm?", t("unblock_q"), t("unblock"), onCancel = { ask = "" }) { Repo.block(ask, false); ask = "" }
    }
}

@Composable
private fun NotifPage(open: (String) -> Unit) {
    Card {
        SwitchRow("bell", Color(0xFFFF9F43), t("msg_notif"), null, Prefs.notifOn) { Prefs.put("notifOn", it) }
        SwitchRow("eye", Color(0xFF3BA4FF), t("show_preview"), null, Prefs.preview) { Prefs.put("preview", it) }
    }
    Card {
        ProRow("music", t("msg_tone"), sub = Sounds.toneName(Prefs.tone), onClick = { open("tone") }) { Chevron() }
        ProRow("o_call", t("ringtone"), sub = Sounds.ringName(Prefs.ring), onClick = { open("ring") }) { Chevron() }
        SwitchRow("vibration", Color(0xFF8E7CF0), t("vibrate"), null, Prefs.vibrate) { Prefs.put("vibrate", it) }
    }
    Card {
        SwitchRow("volume", Mint, t("chat_sounds"), t("chat_sounds_s"), Prefs.chatSounds) { Prefs.put("chatSounds", it) }
    }
    Card {
        ProRow("o_call", t("call_setup"), sub = t("call_setup_s"), onClick = { open("callsetup") }) { Chevron() }
    }
}

@Composable
private fun TonePage(ring: Boolean) {
    val ctx = LocalContext.current
    DisposableEffect(Unit) { onDispose { Sounds.stop() } }
    val keys = if (ring) Sounds.rings else Sounds.tones
    val cur = if (ring) Prefs.ring else Prefs.tone
    Card {
        keys.forEach { k ->
            val sel = k == cur
            Row(
                Modifier.fillMaxWidth().clickable {
                    Prefs.put(if (ring) "ring" else "tone", k)
                    if (ring) Sounds.previewRing(ctx, k) else Sounds.previewTone(ctx, k)
                }.padding(horizontal = 18.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(22.dp).clip(CircleShape).border(2.dp, if (sel) Brand else P.tx2, CircleShape),
                    contentAlignment = Alignment.Center
                ) { if (sel) Box(Modifier.size(12.dp).clip(CircleShape).background(Brand)) }
                Spacer(Modifier.width(16.dp))
                Text(if (ring) Sounds.ringName(k) else Sounds.toneName(k), color = P.tx, fontSize = 16.sp,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.weight(1f))
                if (k != "silent") Ic("play", P.tx2, 20.dp)
            }
        }
    }
}

@Composable
private fun ChatsPage() {
    var askClear by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val wallPick = rememberWallPicker("all")
    Card {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ic("font", Brand, 22.dp); Spacer(Modifier.width(10.dp))
                Text(t("font_size"), color = P.tx, fontWeight = FontWeight.SemiBold, fontSize = 15.5.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("s", "m", "l").forEach { f ->
                    val on = Prefs.font == f
                    Text(t("f_$f"), color = if (on) Color.White else P.tx, fontWeight = FontWeight.SemiBold,
                        fontSize = when (f) { "s" -> 13.sp; "l" -> 17.sp; else -> 15.sp },
                        modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) Brand else P.bg2)
                            .clickable { Prefs.put("font", f) }.padding(horizontal = 16.dp, vertical = 8.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(wallColor()).padding(12.dp)) {
                Text("Golpo Chat 👋", color = P.tx, fontSize = (15.5f * Prefs.fontScale).sp,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(P.inB).padding(horizontal = 12.dp, vertical = 8.dp))
            }
        }
    }
    Card {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ic("wallpaper", Brand, 22.dp); Spacer(Modifier.width(10.dp))
                Text(t("wallpaper"), color = P.tx, fontWeight = FontWeight.SemiBold, fontSize = 15.5.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                WALLS_LIGHT.indices.forEach { i ->
                    val on = Prefs.wall == i && Prefs.wallImg("all").isEmpty()
                    Box(
                        Modifier.size(42.dp).press(CircleShape) { Prefs.put("wall", i); Prefs.setWallImg("all", "") }.background(wallColor(i))
                            .border(if (on) 3.dp else 1.dp, if (on) Brand else P.ln, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { if (on) Ic("check", Brand, 20.dp) }
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlineButton(if (Prefs.wallImg("all").isNotEmpty()) t("wall_photo_on") else t("wall_photo"), "o_image", modifier = Modifier.fillMaxWidth()) { wallPick() }
        }
    }
    Card {
        SwitchRow("moon", Color(0xFF1D1640), t("dark"), null, Prefs.dark) { Prefs.setDarkMode(it) }
        SwitchRow("enter", Color(0xFF3BA4FF), t("enter_sends"), null, Prefs.enterSends) { Prefs.put("enterSends", it) }
    }
    Card {
        ProRow("o_delete", t("clear_all"), tint = Red, onClick = { askClear = true })
    }
    if (askClear) Confirm(t("clear_all") + "?", t("clear_all_q"), t("clear"), danger = true, onCancel = { askClear = false }) {
        Repo.clearAll(); askClear = false
    }
}

@Composable
private fun HelpPage() {
    val ctx = LocalContext.current
    var openQ by remember { mutableStateOf(-1) }
    Text(t("help_center"), color = Brand, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 4.dp))
    Card {
        (1..4).forEach { i ->
            Column(Modifier.fillMaxWidth().clickable { openQ = if (openQ == i) -1 else i }.padding(horizontal = 16.dp, vertical = 13.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t("q$i"), color = P.tx, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Ic(if (openQ == i) "down" else "right", P.tx2, 20.dp)
                }
                if (openQ == i) {
                    Spacer(Modifier.height(6.dp))
                    Text(t("a$i"), color = P.tx2, fontSize = 14.sp, lineHeight = 20.sp)
                }
            }
        }
    }
    Card {
        ProRow("mail", t("contact_us"), sub = "mdrasel666699990@gmail.com", onClick = {
            try {
                ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:mdrasel666699990@gmail.com")).apply {
                    putExtra(Intent.EXTRA_SUBJECT, "Golpo Chat ${BuildConfig.VERSION_NAME}")
                })
            } catch (_: Exception) {}
        })
        ProRow("o_info", t("app_info"), sub = "Golpo Chat ${BuildConfig.VERSION_NAME} · Mobile Tips", onClick = {})
    }
}

private fun whoName(k: String) = when (k) { "friends" -> t("who_friends"); "none" -> t("who_none"); else -> t("who_all") }

@Composable
private fun WhoPage(field: String) {
    val cur = (if (field == "seen") Repo.me?.seen else Repo.me?.pphoto) ?: "all"
    Card {
        listOf("all", "friends", "none").forEach { k ->
            Row(Modifier.fillMaxWidth().clickable { Repo.setPriv(field, k) }.padding(horizontal = 18.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Radio(cur == k); Spacer(Modifier.width(16.dp)); Text(whoName(k), color = P.tx, fontSize = 16.sp)
            }
        }
    }
    Text(t(if (field == "seen") "p_seen_note" else "p_photo_note"), color = P.tx2, fontSize = 13.sp, lineHeight = 19.sp,
        modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
}

private fun dirSize(f: java.io.File): Long = if (f.isDirectory) (f.listFiles()?.sumOf { dirSize(it) } ?: 0L) else f.length()

@Composable
private fun StoragePage() {
    val ctx = LocalContext.current
    var size by remember { mutableStateOf(dirSize(ctx.cacheDir)) }
    var ask by remember { mutableStateOf(false) }
    Card {
        ProRow("o_delete", t("clear_cache"), sub = num("%.1f MB".format(size / 1048576.0)), onClick = { ask = true })
    }
    Text(t("clear_cache_s"), color = P.tx2, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
    if (ask) Confirm(t("clear_cache") + "?", t("clear_cache_s"), t("clear"), onCancel = { ask = false }) {
        try { ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() } } catch (_: Exception) {}
        size = dirSize(ctx.cacheDir); ask = false
    }
}

@Composable
private fun DeletePage() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var ask by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    Column(Modifier.padding(20.dp)) {
        Text(t("delete_t"), color = Red, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(t("delete_s"), color = P.tx, fontSize = 14.5.sp, lineHeight = 21.sp)
        Spacer(Modifier.height(24.dp))
        Box(
            Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(14.dp)).background(Red).clickable(enabled = !busy) { ask = true },
            contentAlignment = Alignment.Center
        ) { Text(if (busy) "…" else t("delete_acc"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
    }
    if (ask) Confirm(t("delete_acc") + "?", t("delete_q"), t("delete_acc"), danger = true, onCancel = { ask = false }) {
        ask = false; busy = true
        scope.launch {
            try {
                Api.post("/api/account/delete", org.json.JSONObject(), auth = true)
                Repo.wipeLocal()
            } catch (e: Exception) {
                toast(ctx, errText(e)); busy = false
            }
        }
    }
}
