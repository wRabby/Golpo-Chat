package com.mobiletips.golpo

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------- Settings tab (root)
@Composable
fun SettingsTab(editProfile: () -> Unit, open: (String) -> Unit) {
    val ctx = LocalContext.current
    val me = Repo.me
    var askOut by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Card {
            Row(Modifier.fillMaxWidth().clickable { editProfile() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(me?.shown ?: "?", me?.photo ?: "", Repo.uid ?: "", 64.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(me?.shown ?: "", color = P.tx, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text(me?.about ?: "", color = P.tx2, fontSize = 13.sp, maxLines = 2)
                    Text("+88 " + num(me?.phone ?: ""), color = P.tx2, fontSize = 12.5.sp)
                }
                Ic("edit", Brand)
            }
        }
        Card {
            SetRow("lock", Color(0xFF3BA4FF), t("s_privacy"), t("s_privacy_s"), onClick = { open("privacy") }) { Chevron() }
            SetRow("bell", Color(0xFFFF9F43), t("s_notif"), t("s_notif_s"), onClick = { open("notif") }) { Chevron() }
            SetRow("chat", Brand, t("s_chats"), t("s_chats_s"), onClick = { open("chats") }) { Chevron() }
        }
        Card {
            SetRow("lang", Color(0xFFB455F5), t("lang"), t("lang_now"), onClick = { Prefs.toggleLang() }) { LangBall() }
        }
        Card {
            SetRow("help", Green, t("help"), t("s_help_s"), onClick = { open("help") }) { Chevron() }
            SetRow("share", Color(0xFFFF4D79), t("invite"), null, onClick = {
                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, t("invite_text"))
                }, t("invite")))
            })
        }
        Card {
            SetRow("logout", Red, t("logout"), null, red = true, onClick = { askOut = true })
        }
        Text("Golpo Chat ${BuildConfig.VERSION_NAME}\nfrom Mobile Tips", color = P.tx2, fontSize = 12.5.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(20.dp))
    }
    if (askOut) Confirm(t("logout") + "?", t("logout_q"), t("logout"), danger = true, onCancel = { askOut = false }) {
        askOut = false
        Repo.signOut()
    }
}

@Composable
private fun Chevron() = Ic("right", P.tx2, 22.dp)

@Composable
private fun SwitchRow(icon: String, color: Color, title: String, sub: String?, on: Boolean, set: (Boolean) -> Unit) {
    SetRow(icon, color, title, sub, onClick = { set(!on) }) {
        Switch(on, { set(it) }, colors = SwitchDefaults.colors(checkedTrackColor = Brand))
    }
}

// ---------------------------------------------------------------- sub pages
@Composable
fun SettingsPage(name: String, onBack: () -> Unit, open: (String) -> Unit, openChat: (String) -> Unit) {
    val title = when (name) {
        "privacy" -> t("s_privacy"); "blocked" -> t("blocked_list"); "notif" -> t("s_notif")
        "tone" -> t("msg_tone"); "ring" -> t("ringtone"); "chats" -> t("s_chats"); else -> t("help")
    }
    Column(Modifier.fillMaxSize().background(P.bg)) {
        TopBar(title, onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            when (name) {
                "privacy" -> PrivacyPage(open)
                "blocked" -> BlockedPage(openChat)
                "notif" -> NotifPage(open)
                "tone" -> TonePage(ring = false)
                "ring" -> TonePage(ring = true)
                "chats" -> ChatsPage()
                else -> HelpPage()
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}

@Composable
private fun PrivacyPage(open: (String) -> Unit) {
    val n = Repo.me?.blocked?.size ?: 0
    Card {
        SetRow("block", Red, t("blocked_list"), if (n > 0) num("$n") else t("no_blocked"), onClick = { open("blocked") }) { Chevron() }
    }
}

@Composable
private fun BlockedPage(openChat: (String) -> Unit) {
    val list = Repo.me?.blocked ?: emptyList()
    var ask by remember { mutableStateOf("") }
    if (list.isEmpty()) {
        Text(t("no_blocked"), color = P.tx2, modifier = Modifier.fillMaxWidth().padding(30.dp), textAlign = TextAlign.Center)
    }
    Card {
        list.forEach { id ->
            val u = Repo.user(id)
            Row(Modifier.fillMaxWidth().clickable { openChat(id) }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(u?.shown ?: "?", u?.photo ?: "", id, 46.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(u?.shown ?: "…", color = P.tx, fontWeight = FontWeight.Bold, fontSize = 15.5.sp)
                    Text("+88 " + num(u?.phone ?: ""), color = P.tx2, fontSize = 13.sp)
                }
                Text(t("unblock"), color = Brand, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { ask = id }.padding(10.dp))
            }
        }
    }
    if (ask.isNotEmpty()) {
        val nm = Repo.user(ask)?.shown ?: ""
        Confirm(t("unblock") + " $nm?", t("unblock_q"), t("unblock"), onCancel = { ask = "" }) { Repo.block(ask, false); ask = "" }
    }
}

@Composable
private fun NotifPage(open: (String) -> Unit) {
    Card {
        SwitchRow("bell", Color(0xFFFF9F43), t("msg_notif"), null, Prefs.notifOn) { Prefs.put("notifOn", it) }
        SwitchRow("eye", Color(0xFF3BA4FF), t("show_preview"), null, Prefs.preview) { Prefs.put("preview", it) }
    }
    Card {
        SetRow("music", Brand, t("msg_tone"), Sounds.toneName(Prefs.tone), onClick = { open("tone") }) { Chevron() }
        SetRow("call", Green, t("ringtone"), Sounds.ringName(Prefs.ring), onClick = { open("ring") }) { Chevron() }
        SwitchRow("vibration", Color(0xFF8E7CF0), t("vibrate"), null, Prefs.vibrate) { Prefs.put("vibrate", it) }
    }
    Card {
        SwitchRow("volume", Mint, t("chat_sounds"), t("chat_sounds_s"), Prefs.chatSounds) { Prefs.put("chatSounds", it) }
    }
}

@Composable
private fun TonePage(ring: Boolean) {
    val ctx = LocalContext.current
    DisposableEffect(Unit) { onDispose { Sounds.stop() } }
    val keys = if (ring) Sounds.rings else Sounds.tones
    val cur = if (ring) Prefs.ring else Prefs.tone
    Card {
        keys.forEach { k ->
            val sel = k == cur
            Row(
                Modifier.fillMaxWidth().clickable {
                    Prefs.put(if (ring) "ring" else "tone", k)
                    if (ring) Sounds.previewRing(ctx, k) else Sounds.previewTone(ctx, k)
                }.padding(horizontal = 18.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(22.dp).clip(CircleShape).border(2.dp, if (sel) Brand else P.tx2, CircleShape),
                    contentAlignment = Alignment.Center
                ) { if (sel) Box(Modifier.size(12.dp).clip(CircleShape).background(Brand)) }
                Spacer(Modifier.width(16.dp))
                Text(if (ring) Sounds.ringName(k) else Sounds.toneName(k), color = P.tx, fontSize = 16.sp,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.weight(1f))
                if (k != "silent") Ic("play", P.tx2, 20.dp)
            }
        }
    }
}

@Composable
private fun ChatsPage() {
    var askClear by remember { mutableStateOf(false) }
    Card {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ic("font", Brand, 22.dp); Spacer(Modifier.width(10.dp))
                Text(t("font_size"), color = P.tx, fontWeight = FontWeight.SemiBold, fontSize = 15.5.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("s", "m", "l").forEach { f ->
                    val on = Prefs.font == f
                    Text(t("f_$f"), color = if (on) Color.White else P.tx, fontWeight = FontWeight.SemiBold,
                        fontSize = when (f) { "s" -> 13.sp; "l" -> 17.sp; else -> 15.sp },
                        modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) Brand else P.bg2)
                            .clickable { Prefs.put("font", f) }.padding(horizontal = 16.dp, vertical = 8.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(wallColor()).padding(12.dp)) {
                Text("Golpo Chat 👋", color = P.tx, fontSize = (15.5f * Prefs.fontScale).sp,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(P.inB).padding(horizontal = 12.dp, vertical = 8.dp))
            }
        }
    }
    Card {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ic("wallpaper", Brand, 22.dp); Spacer(Modifier.width(10.dp))
                Text(t("wallpaper"), color = P.tx, fontWeight = FontWeight.SemiBold, fontSize = 15.5.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                WALLS_LIGHT.indices.forEach { i ->
                    val on = Prefs.wall == i
                    Box(
                        Modifier.size(42.dp).clip(CircleShape).background(wallColor(i))
                            .border(if (on) 3.dp else 1.dp, if (on) Brand else P.ln, CircleShape)
                            .clickable { Prefs.put("wall", i) },
                        contentAlignment = Alignment.Center
                    ) { if (on) Ic("check", Brand, 20.dp) }
                }
            }
        }
    }
    Card {
        SwitchRow("moon", Color(0xFF1D1640), t("dark"), null, Prefs.dark) { Prefs.setDarkMode(it) }
        SwitchRow("enter", Color(0xFF3BA4FF), t("enter_sends"), null, Prefs.enterSends) { Prefs.put("enterSends", it) }
    }
    Card {
        SetRow("del", Red, t("clear_all"), null, red = true, onClick = { askClear = true })
    }
    if (askClear) Confirm(t("clear_all") + "?", t("clear_all_q"), t("clear"), danger = true, onCancel = { askClear = false }) {
        Repo.clearAll(); askClear = false
    }
}

@Composable
private fun HelpPage() {
    val ctx = LocalContext.current
    var openQ by remember { mutableStateOf(-1) }
    Text(t("help_center"), color = Brand, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 4.dp))
    Card {
        (1..4).forEach { i ->
            Column(Modifier.fillMaxWidth().clickable { openQ = if (openQ == i) -1 else i }.padding(horizontal = 16.dp, vertical = 13.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t("q$i"), color = P.tx, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Ic(if (openQ == i) "down" else "right", P.tx2, 20.dp)
                }
                if (openQ == i) {
                    Spacer(Modifier.height(6.dp))
                    Text(t("a$i"), color = P.tx2, fontSize = 14.sp, lineHeight = 20.sp)
                }
            }
        }
    }
    Card {
        SetRow("mail", Green, t("contact_us"), "mdrasel666699990@gmail.com", onClick = {
            try {
                ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:mdrasel666699990@gmail.com")).apply {
                    putExtra(Intent.EXTRA_SUBJECT, "Golpo Chat ${BuildConfig.VERSION_NAME}")
                })
            } catch (_: Exception) {}
        })
        SetRow("info", Brand, t("app_info"), "Golpo Chat ${BuildConfig.VERSION_NAME} · Mobile Tips", onClick = {})
    }
}
