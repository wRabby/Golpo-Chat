package com.mobiletips.golpo

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import com.google.firebase.firestore.DocumentChange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Query
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

private sealed interface Item {
    data class Day(val label: String) : Item
    data class M(val m: Msg) : Item
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(other: String, onBack: () -> Unit, onProfile: () -> Unit, groupId: String? = null) {
    val ctx = LocalContext.current
    val call = rememberCaller(other)
    val gcall = rememberGroupCaller(groupId ?: "")
    val join = rememberJoiner()
    // a call still going on with this group / this person: "Call in progress · Join"
    val live = Repo.joinable().firstOrNull { c ->
        if (groupId != null) c.room == groupId else c.group.isEmpty() && (other in c.joined || c.by == other)
    }
    val scope = rememberCoroutineScope()
    val me = Repo.uid ?: return
    val isGroup = groupId != null
    val chatId = remember(other, groupId) { groupId ?: Repo.ensureChat(other) }
    val msgs = remember { mutableStateListOf<Msg>() }
    val u = Repo.user(other)
    var text by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf<Msg?>(null) }
    var menu by remember { mutableStateOf<Msg?>(null) }
    var viewMedia by remember { mutableStateOf<Msg?>(null) }
    var uploading by remember { mutableIntStateOf(0) }
    var upPct by remember { mutableStateOf(0f) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var lastTyping by remember { mutableLongStateOf(0L) }
    var more by remember { mutableStateOf(false) }
    var ask by remember { mutableStateOf("") }
    val iBlocked = !isGroup && Repo.isBlockedByMe(other)
    val blockedMe = !isGroup && Repo.blocksMe(other)
    val list = rememberLazyListState()

    DisposableEffect(chatId) {
        Repo.openChat = chatId
        Notif.clear(ctx, chatId)
        var first = true
        val reg = Repo.db.collection("chats").document(chatId).collection("messages")
            .orderBy("at", Query.Direction.ASCENDING).limitToLast(300)
            .addSnapshotListener(MetadataChanges.INCLUDE) { s, _ ->
                if (s == null) return@addSnapshotListener
                if (!first && !s.metadata.isFromCache && s.documentChanges.any {
                        it.type == DocumentChange.Type.ADDED && it.document.getString("from") != me && !it.document.metadata.hasPendingWrites()
                    }) Sounds.received()
                if (!s.metadata.isFromCache) first = false
                msgs.clear()
                msgs.addAll(s.documents.map { it.toMsg() })
            }
        onDispose { reg.remove(); Repo.openChat = null; Player.stop() }
    }
    val chat = Repo.chats.firstOrNull { it.id == chatId }
    LaunchedEffect(msgs.size, Repo.foreground, chat?.unread) {
        if (Repo.foreground) Repo.markRead(chatId, msgs.toList(), chat?.unread ?: 0)
        if (list.firstVisibleItemIndex < 3) list.scrollToItem(0)
    }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    LaunchedEffect(Player.playing) { while (Player.playing.isNotEmpty()) { Player.tick(); delay(200) } }

    // ---- photo or video
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null && blockedMe) toast(ctx, t("cant_send"))
        else if (uri != null) {
            val isVideo = (ctx.contentResolver.getType(uri) ?: "").startsWith("video")
            val size = if (isVideo) Media.size(ctx, uri) else 0L
            if (isVideo && size > 60L * 1024 * 1024) { toast(ctx, t("video_too_big")); return@rememberLauncherForActivityResult }
            uploading++
            upPct = 0f
            val r = reply; reply = null
            scope.launch {
                try {
                    if (isVideo) {
                        val (sec, thumbBytes) = Media.videoInfo(ctx, uri)
                        val thumb = if (thumbBytes != null) Api.upload(thumbBytes, "thumb") else ""
                        val url = Api.uploadFile(ctx, uri, "video", size) { upPct = it }
                        Repo.send(chatId, other, "video", url = url, dur = sec, reply = r?.let { replyOf(it, me) }, thumb = thumb)
                    } else {
                        val url = Api.upload(Media.jpeg(ctx, uri), "img")
                        Repo.send(chatId, other, "img", url = url, reply = r?.let { replyOf(it, me) })
                    }
                } catch (e: Exception) { toast(ctx, t("e_send")) }
                uploading--
            }
        }
    }

    // ---- voice
    val rec = remember { Recorder(ctx) }
    var recording by remember { mutableStateOf(false) }
    var recSec by remember { mutableIntStateOf(0) }
    LaunchedEffect(recording) { recSec = 0; while (recording) { delay(1000); recSec++ } }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) recording = rec.start() else toast(ctx, t("mic_need"))
    }
    fun startRec() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) recording = rec.start()
        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }
    fun sendRec() {
        recording = false
        val f = rec.stop() ?: return
        if (blockedMe) { f.delete(); toast(ctx, t("cant_send")); return }
        val dur = recSec.coerceAtLeast(1)
        uploading++
        val r = reply; reply = null
        scope.launch {
            try {
                val url = Api.upload(f.readBytes(), "voice")
                Repo.send(chatId, other, "voice", url = url, dur = dur, reply = r?.let { replyOf(it, me) })
            } catch (e: Exception) { toast(ctx, t("e_send")) }
            f.delete()
            uploading--
        }
    }

    val otherTyping = chat != null && now - chat.otherTyping in 0..6000
    val sub = when {
        isGroup && otherTyping -> (Repo.user(chat?.typingWho ?: "")?.shown ?: "") + " " + t("typing")
        isGroup -> num("${chat?.members?.size ?: 0}") + " " + t("g_members")
        otherTyping -> t("typing")
        Repo.hidesFromMe(u) -> ""
        u?.online == true -> t("online")
        else -> lastSeenText(u?.lastSeen ?: 0)
    }

    val clearedAt = chat?.cleared ?: 0L
    val rows = remember(msgs.toList(), Prefs.lang, clearedAt) {
        val out = ArrayList<Item>()
        var lastDay = ""
        msgs.filter { it.at > clearedAt }.forEach { m ->
            val d = dayLabel(m.at)
            if (d != lastDay) { out.add(Item.Day(d)); lastDay = d }
            out.add(Item.M(m))
        }
        out
    }

    val cw = Prefs.chatWall(chatId)
    val wallImg = Prefs.wallImg(chatId).ifEmpty { if (cw == -1) Prefs.wallImg("all") else "" }
    Box(Modifier.fillMaxSize().background(wallColor(if (cw == -1) Prefs.wall else cw))) {
    if (wallImg.isNotEmpty()) AsyncImage(File(wallImg), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
    Column(Modifier.fillMaxSize()) {
        // ---- header
        Row(Modifier.fillMaxWidth().background(P.bg).padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn("back") { onBack() }
            Row(Modifier.weight(1f).clickable { onProfile() }, verticalAlignment = Alignment.CenterVertically) {
                if (isGroup) Avatar(chat?.name ?: "?", chat?.photo ?: "", chatId, 40.dp)
                else Avatar(u?.shown ?: "?", u?.photo ?: "", other, 40.dp, online = u?.online == true && !Repo.hidesFromMe(u))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(if (isGroup) chat?.name ?: "…" else u?.shown ?: "…", color = P.tx, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (sub.isNotEmpty()) Text(sub, color = if (otherTyping || u?.online == true) Mint else P.tx2, fontSize = 12.5.sp,
                        fontWeight = if (otherTyping || u?.online == true) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
            if (isGroup) {
                IconBtn("video", Brand) { gcall(true) }
                IconBtn("call", Brand) { gcall(false) }
            } else {
                IconBtn("video", Brand) { if (iBlocked || blockedMe || Repo.cantCall(other)) toast(ctx, t("cant_call")) else call(true) }
                IconBtn("call", Brand) { if (iBlocked || blockedMe || Repo.cantCall(other)) toast(ctx, t("cant_call")) else call(false) }
            }
            Box {
                IconBtn("more", P.tx) { more = true }
                DropdownMenu(expanded = more, onDismissRequest = { more = false }, modifier = Modifier.background(P.card)) {
                    DropdownMenuItem(text = { Text(if (isGroup) t("g_info") else t("view_contact"), color = P.tx) }, onClick = { more = false; onProfile() })
                    DropdownMenuItem(text = { Text(t("clear_chat"), color = P.tx) }, onClick = { more = false; ask = "clear" })
                    if (!isGroup) DropdownMenuItem(text = { Text(if (iBlocked) t("unblock") else t("block"), color = Red) },
                        onClick = { more = false; ask = if (iBlocked) "unblock" else "block" })
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(P.ln))
        if (live != null) Box(Modifier.background(P.bg)) { LiveCallCard(live) { join(live) } }

        // ---- messages (newest at the bottom)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, reverseLayout = true) {
            if (otherTyping) item("typing") {
                Box(Modifier.padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(P.inB).padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Text("•••", color = P.tx2, fontWeight = FontWeight.Bold)
                }
            }
            if (uploading > 0) item("up") {
                Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), contentAlignment = Alignment.CenterEnd) {
                    Row(Modifier.clip(RoundedCornerShape(16.dp)).background(P.outB).padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(color = Brand, strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(t("sending") + if (upPct > 0f) " " + num("${(upPct * 100).toInt()}") + "%" else "", color = P.tx2, fontSize = 13.sp)
                    }
                }
            }
            items(rows.asReversed(), key = { if (it is Item.M) it.m.id else "d" + (it as Item.Day).label }) { row ->
                when (row) {
                    is Item.Day -> Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                        Text(row.label, color = P.tx2, fontSize = 12.sp,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(P.card).padding(horizontal = 12.dp, vertical = 4.dp))
                    }
                    is Item.M -> Bubble(row.m, row.m.from == me, onLong = { if (!row.m.del) menu = row.m }, onImage = { viewMedia = row.m },
                        sender = if (isGroup && row.m.from != me) Repo.user(row.m.from)?.shown ?: "…" else null)
                }
            }
        }

        // ---- reply preview
        val r = reply
        if (r != null) {
            Row(
                Modifier.padding(horizontal = 8.dp).fillMaxWidth().clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)).background(P.card),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.width(4.dp).height(48.dp).background(Brand))
                Column(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Text(if (r.from == me) t("you") else u?.shown ?: "", color = Brand, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(previewOf(r.kind, r.text), color = P.tx2, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconBtn("close", P.tx2) { reply = null }
            }
        }

        // ---- input bar
        fun sendText() {
            if (text.isBlank()) return
            if (blockedMe) { toast(ctx, t("cant_send")); return }
            val rr = reply
            Repo.send(chatId, other, "t", text = text.trim(), reply = rr?.let { replyOf(it, me) })
            text = ""; reply = null
        }
        if (chat != null && chat.group && !Repo.canWrite(chat)) {
            Row(Modifier.fillMaxWidth().background(P.bg).padding(16.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Ic("lock", P.tx2, 18.dp); Spacer(Modifier.width(8.dp))
                Text(t("only_admins_send"), color = P.tx2, fontSize = 14.sp)
            }
        } else if (iBlocked) {
            Column(Modifier.fillMaxWidth().background(P.bg).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(t("you_blocked"), color = P.tx2, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                Text(t("unblock"), color = Color.White, fontWeight = FontWeight.Bold,
                    modifier = Modifier.press(RoundedCornerShape(20.dp)) { ask = "unblock" }.background(Brand).padding(horizontal = 22.dp, vertical = 9.dp))
            }
        } else Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
            if (recording) {
                IconBtn("del", Red) { recording = false; rec.stop()?.delete() }
                Row(
                    Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(24.dp)).background(P.card).padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(Red))
                    Spacer(Modifier.width(10.dp))
                    Text(num("%d:%02d".format(recSec / 60, recSec % 60)), color = P.tx, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(10.dp))
                    Text(t("recording"), color = P.tx2, fontSize = 13.sp)
                }
                Spacer(Modifier.width(6.dp))
                SendBtn("send") { sendRec() }
            } else {
                Row(
                    Modifier.weight(1f).heightIn(min = 48.dp).clip(RoundedCornerShape(24.dp)).background(P.card).padding(start = 16.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.weight(1f).padding(vertical = 12.dp)) {
                        if (text.isEmpty()) Text(t("type_msg"), color = P.tx2, fontSize = 16.sp)
                        BasicTextField(
                            text, { v ->
                                text = v
                                val n = System.currentTimeMillis()
                                if (v.isNotEmpty() && n - lastTyping > 3000) { lastTyping = n; Repo.typing(chatId) }
                            },
                            textStyle = TextStyle(color = P.tx, fontSize = (16f * Prefs.fontScale).sp), maxLines = 5,
                            keyboardOptions = KeyboardOptions(imeAction = if (Prefs.enterSends) ImeAction.Send else ImeAction.Default),
                            keyboardActions = KeyboardActions(onSend = { sendText() }),
                            cursorBrush = SolidColor(Brand), modifier = Modifier.fillMaxWidth()
                        )
                    }
                    IconBtn("image", P.tx2) { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }
                }
                Spacer(Modifier.width(6.dp))
                if (text.isBlank()) SendBtn("mic") { startRec() }
                else SendBtn("send") { sendText() }
            }
        }
    }
    }

    val nm = u?.shown ?: ""
    when (ask) {
        "block" -> Confirm(t("block") + " $nm?", t("block_q"), t("block"), danger = true, onCancel = { ask = "" }) { Repo.block(other, true); ask = "" }
        "unblock" -> Confirm(t("unblock") + " $nm?", t("unblock_q"), t("unblock"), onCancel = { ask = "" }) { Repo.block(other, false); ask = "" }
        "clear" -> Confirm(t("clear_chat") + "?", t("clear_q"), t("clear"), danger = true, onCancel = { ask = "" }) { Repo.clearChat(chatId); ask = "" }
    }

    // ---- long-press menu
    val m = menu
    if (m != null) {
        Dialog(onDismissRequest = { menu = null }) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    Modifier.clip(RoundedCornerShape(30.dp)).background(P.card).padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf("❤️", "😂", "😮", "😢", "🙏", "👍").forEach { e ->
                        Text(e, fontSize = 28.sp, modifier = Modifier.clip(CircleShape)
                            .background(if (m.react[me] == e) P.pill else Color.Transparent)
                            .clickable { Repo.react(chatId, m.id, if (m.react[me] == e) null else e); menu = null }.padding(4.dp))
                    }
                }
                Spacer(Modifier.height(10.dp))
                Column(Modifier.widthIn(min = 230.dp).clip(RoundedCornerShape(18.dp)).background(P.card)) {
                    MenuRow("reply", t("reply")) { reply = m; menu = null }
                    if (m.kind == "t") MenuRow("copy", t("copy")) {
                        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("msg", m.text))
                        if (Build.VERSION.SDK_INT < 33) toast(ctx, t("copied"))
                        menu = null
                    }
                    if ((m.kind == "img" || m.kind == "video") && m.url.isNotEmpty()) {
                        MenuRow("o_download", t("download")) { Saver.download(ctx, m.url, m.kind == "video"); menu = null }
                        MenuRow("share", t("share")) { val mm = m; menu = null; scope.launch { Saver.share(ctx, mm.url, mm.kind == "video") } }
                    }
                    if (m.from == me) MenuRow("del", t("del_all"), Red) {
                        Repo.deleteForAll(chatId, m, msgs.lastOrNull()?.id == m.id); menu = null
                    }
                }
            }
        }
    }
    viewMedia?.let { vm -> MediaViewer(vm.url, vm.kind == "video") { viewMedia = null } }
}

private fun replyOf(m: Msg, me: String): Pair<String, String> =
    (if (m.from == me) t("you") else Repo.user(m.from)?.shown ?: "") to previewOf(m.kind, m.text).take(120)

@Composable
private fun SendBtn(icon: String, onClick: () -> Unit) {
    Box(Modifier.size(48.dp).press(CircleShape, scaleTo = 0.86f) { onClick() }.background(Grad), contentAlignment = Alignment.Center) {
        Ic(icon, Color.White, 22.dp)
    }
}

@Composable
private fun MenuRow(icon: String, title: String, color: Color = P.tx, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().pressRow { onClick() }.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Ic(icon, color, 22.dp); Spacer(Modifier.width(14.dp)); Text(title, color = color, fontSize = 15.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Bubble(m: Msg, mine: Boolean, onLong: () -> Unit, onImage: (String) -> Unit, sender: String? = null) {
    val shape = if (mine) RoundedCornerShape(16.dp, 4.dp, 16.dp, 16.dp) else RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp)
    val media = m.kind == "img" || m.kind == "video"
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp),
        horizontalAlignment = if (mine) Alignment.End else Alignment.Start
    ) {
        Column(
            Modifier.widthIn(max = 300.dp).clip(shape).background(if (mine) P.outB else P.inB)
                .combinedClickable(onClick = { if ((m.kind == "img" || m.kind == "video") && !m.del) onImage(m.url) }, onLongClick = onLong)
                .padding(horizontal = if (media && !m.del) 4.dp else 10.dp, vertical = if (media && !m.del) 4.dp else 7.dp)
        ) {
            if (sender != null) Text(sender, color = nameColor(m.from), fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.padding(start = if (media) 6.dp else 0.dp, bottom = 2.dp))
            if (m.replyText.isNotEmpty() && !m.del) {
                Row(Modifier.padding(bottom = 4.dp).clip(RoundedCornerShape(8.dp)).background(Brand.copy(alpha = .09f))) {
                    Box(Modifier.width(3.dp).height(40.dp).background(Brand))
                    Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                        Text(m.replyName, color = Brand, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                        Text(m.replyText, color = P.tx2, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            when {
                m.del -> Text(if (mine) t("deleted_me") else t("deleted"), color = P.tx2, fontStyle = FontStyle.Italic, fontSize = 14.5.sp)
                m.kind == "img" -> AsyncImage(
                    m.url, null, contentScale = ContentScale.Crop,
                    modifier = Modifier.width(240.dp).height(240.dp).clip(RoundedCornerShape(12.dp)).background(P.bg2)
                )
                m.kind == "video" -> Box(Modifier.width(240.dp).height(240.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF0D141C))) {
                    if (m.thumb.isNotEmpty()) AsyncImage(m.thumb, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    Box(Modifier.align(Alignment.Center).size(56.dp).clip(CircleShape).background(Color.Black.copy(alpha = .5f)),
                        contentAlignment = Alignment.Center) { Ic("play", Color.White, 34.dp) }
                    if (m.dur > 0) Text(num("%d:%02d".format(m.dur / 60, m.dur % 60)), color = Color.White, fontSize = 12.sp,
                        modifier = Modifier.align(Alignment.BottomStart).padding(8.dp).clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = .5f)).padding(horizontal = 6.dp, vertical = 2.dp))
                }
                m.kind == "voice" -> VoiceRow(m)
                else -> Text(m.text, color = P.tx, fontSize = (15.5f * Prefs.fontScale).sp, lineHeight = (21f * Prefs.fontScale).sp)
            }
            Row(
                Modifier.align(Alignment.End).padding(top = 2.dp, end = if (media) 6.dp else 0.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(clock(m.at), color = P.tx2, fontSize = 11.sp)
                if (mine && !m.del) { Spacer(Modifier.width(3.dp)); Tick(if (Repo.me?.receipts == false) minOf(m.st, 2) else m.st, m.pending, 15) }
            }
        }
        if (m.react.isNotEmpty() && !m.del) {
            Text(m.react.values.distinct().joinToString("") + if (m.react.size > 1) " " + num("${m.react.size}") else "",
                fontSize = 13.sp, color = P.tx,
                modifier = Modifier.padding(horizontal = 8.dp).clip(RoundedCornerShape(12.dp)).background(P.card).padding(horizontal = 6.dp, vertical = 1.dp))
        }
    }
}

@Composable
private fun VoiceRow(m: Msg) {
    val playing = Player.playing == m.id
    Row(Modifier.width(230.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).press(CircleShape) { Player.toggle(m.id, m.url) }.background(Brand), contentAlignment = Alignment.Center) {
            Ic(if (playing) "pause" else "play", Color.White, 22.dp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(P.tx2.copy(alpha = .3f))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(if (playing) Player.progress.coerceIn(0f, 1f) else 0f).background(Brand))
            }
            Spacer(Modifier.height(6.dp))
            Text(num("%d:%02d".format(m.dur / 60, m.dur % 60)), color = P.tx2, fontSize = 11.5.sp)
        }
    }
}

// ---------------------------------------------------------------- voice recorder
class Recorder(private val ctx: Context) {
    private var r: MediaRecorder? = null
    private var file: File? = null

    fun start(): Boolean = try {
        val f = File(ctx.cacheDir, "rec_${System.currentTimeMillis()}.m4a")
        val mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
        mr.setAudioSource(MediaRecorder.AudioSource.MIC)
        mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        mr.setAudioEncodingBitRate(48000)
        mr.setAudioSamplingRate(44100)
        mr.setOutputFile(f.absolutePath)
        mr.prepare()
        mr.start()
        r = mr; file = f
        true
    } catch (_: Exception) {
        false
    }

    /** Returns the recording, or null if it was too short / failed. */
    fun stop(): File? {
        val mr = r ?: return null
        r = null
        val ok = try { mr.stop(); true } catch (_: Exception) { false }
        try { mr.release() } catch (_: Exception) {}
        val f = file
        return if (ok && f != null && f.length() > 1000) f else { f?.delete(); null }
    }
}

private val NAME_COLORS = listOf(Color(0xFF1E88E5), Color(0xFF13B58A), Color(0xFFFF6B3D), Color(0xFF0082E6), Color(0xFFD63E8F), Color(0xFFB8860B))
private fun nameColor(uid: String) = NAME_COLORS[(uid.hashCode() and 0x7fffffff) % NAME_COLORS.size]
