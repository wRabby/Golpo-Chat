package com.mobiletips.golpo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.phone.SmsRetriever
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.common.api.Status
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONObject

// ---------------------------------------------------------------- logo + splash
@Composable
fun Logo(size: androidx.compose.ui.unit.Dp, color: Color = Color.White, bars: Color = Color(0xFF7B5BFA)) {
    Canvas(Modifier.size(size)) {
        val s = this.size.width / 64f
        val p = Path().apply {
            moveTo(32 * s, 6 * s)
            cubicTo(17 * s, 6 * s, 5 * s, 16.6f * s, 5 * s, 29.7f * s)
            cubicTo(5 * s, 37.1f * s, 8.8f * s, 43.7f * s, 14.8f * s, 48.1f * s)
            lineTo(12 * s, 58 * s)
            lineTo(23.2f * s, 51.9f * s)
            cubicTo(26 * s, 52.7f * s, 29 * s, 53.1f * s, 32 * s, 53.1f * s)
            cubicTo(47 * s, 53.1f * s, 59 * s, 42.5f * s, 59 * s, 29.4f * s)
            cubicTo(59 * s, 16.3f * s, 47 * s, 6 * s, 32 * s, 6 * s)
            close()
        }
        drawPath(p, color)
        listOf(19f to 12f, 26f to 22f, 33f to 16f, 40f to 8f).forEach { (x, h) ->
            drawRoundRect(bars, Offset(x * s, (30 - h / 2) * s), Size(4 * s, h * s), CornerRadius(2 * s))
        }
    }
}

@Composable
fun Splash() {
    val inf = rememberInfiniteTransition(label = "s")
    val k by inf.animateFloat(0.92f, 1.06f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "k")
    Box(Modifier.fillMaxSize().background(Grad)) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.scale(k).size(120.dp).clip(RoundedCornerShape(38.dp)).background(Color.White.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                Logo(72.dp)
            }
            Spacer(Modifier.height(20.dp))
            Text("Golpo Chat", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
            Text(t("tag"), color = Color.White.copy(alpha = .85f), fontSize = 15.sp)
        }
        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("from", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
            Text("Mobile Tips", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ---------------------------------------------------------------- shared bits
@Composable
fun LangBall(modifier: Modifier = Modifier) {
    Box(
        modifier.size(36.dp).clip(CircleShape).background(Grad).clickable { Prefs.toggleLang() },
        contentAlignment = Alignment.Center
    ) {
        Text(if (Prefs.lang == "en") "অ" else "A", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
    }
}

@Composable
fun GradButton(text: String, enabled: Boolean = true, busy: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(16.dp))
            .background(if (enabled) Grad else androidx.compose.ui.graphics.SolidColor(P.ln))
            .clickable(enabled = enabled && !busy) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (busy) CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp, modifier = Modifier.size(24.dp))
        else Text(text, color = if (enabled) Color.White else P.tx2, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, hint: String, iconName: String? = null, keyboard: KeyboardType = KeyboardType.Text,
          prefix: String? = null, maxLen: Int = 60, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(P.bg2).padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (iconName != null) { Ic(iconName, P.tx2, 22.dp); Spacer(Modifier.width(10.dp)) }
        if (prefix != null) {
            Text(prefix, color = P.tx2, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.width(10.dp)); Box(Modifier.width(1.dp).height(22.dp).background(P.ln)); Spacer(Modifier.width(10.dp))
        }
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text(hint, color = P.tx2, fontSize = 17.sp)
            BasicTextField(
                value, { onChange(it.take(maxLen)) }, singleLine = true,
                textStyle = TextStyle(color = P.tx, fontSize = 17.sp),
                keyboardOptions = KeyboardOptions(keyboardType = keyboard),
                cursorBrush = androidx.compose.ui.graphics.SolidColor(Brand),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

fun errText(e: Exception): String = when ((e as? ApiError)?.code) {
    "wrong_code" -> t("e_wrong_code"); "expired" -> t("e_expired"); "too_many" -> t("e_too_many")
    "wait" -> t("e_wait"); "limit" -> t("e_limit"); "bad_number" -> t("e_bad_number")
    "server_not_ready" -> t("e_server"); "net" -> t("e_net")
    else -> t("e_login")
}

// ---------------------------------------------------------------- welcome
@Composable
fun Welcome(onStart: () -> Unit) {
    Column(Modifier.fillMaxSize().background(P.bg)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.End) { LangBall() }
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(150.dp).clip(RoundedCornerShape(46.dp)).background(Grad), contentAlignment = Alignment.Center) { Logo(92.dp) }
            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf("call" to Green, "video" to Blue, "mic" to Color(0xFFFF8FA3)).forEach { (n, c) ->
                    Box(Modifier.size(48.dp).clip(CircleShape).background(c), contentAlignment = Alignment.Center) { Ic(n, Color.White, 22.dp) }
                }
            }
            Spacer(Modifier.height(26.dp))
            Text(t("welcome_t"), color = P.tx, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Text(t("welcome_s"), color = P.tx2, fontSize = 15.sp, textAlign = TextAlign.Center, lineHeight = 22.sp)
        }
        Column(Modifier.padding(24.dp)) {
            Text(t("agree"), color = P.tx2, fontSize = 12.5.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(14.dp))
            GradButton(t("start"), onClick = onStart)
        }
    }
}

// ---------------------------------------------------------------- phone number
@Composable
fun PhoneScreen(onBack: () -> Unit, onSent: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var digits by remember { mutableStateOf("") }
    var ask by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val phone = "0" + digits
    val valid = Regex("^1[3-9]\\d{8}$").matches(digits)

    Column(Modifier.fillMaxSize().background(P.bg)) {
        TopBar("", onBack) { LangBall(Modifier.padding(end = 8.dp)) }
        Column(Modifier.weight(1f).padding(horizontal = 24.dp).verticalScroll(rememberScrollState())) {
            Text(t("phone_t"), color = P.tx, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(t("phone_s"), color = P.tx2, fontSize = 15.sp, lineHeight = 21.sp)
            Spacer(Modifier.height(24.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(P.bg2).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🇧🇩", fontSize = 22.sp); Spacer(Modifier.width(10.dp))
                Text(t("bd"), color = P.tx, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Field(digits, { v -> digits = v.filter { it.isDigit() }.removePrefix("0").removePrefix("880").take(10); error = "" },
                "1XXX-XXXXXX", keyboard = KeyboardType.Phone, prefix = "+880", maxLen = 14)
            if (error.isNotEmpty()) { Spacer(Modifier.height(10.dp)); Text(error, color = Red, fontSize = 14.sp) }
        }
        Box(Modifier.padding(24.dp)) { GradButton(t("next"), enabled = valid, busy = busy) { ask = true } }
    }
    if (ask) {
        Confirm(
            title = "+880 ${digits.take(4)}-${digits.drop(4)}", text = t("confirm_num"), ok = t("yes"), cancel = t("edit"),
            onCancel = { ask = false }
        ) {
            ask = false; busy = true
            scope.launch {
                try {
                    Api.post("/api/otp/send", JSONObject().put("phone", phone).put("hash", appHash(ctx)))
                    onSent(phone)
                } catch (e: Exception) {
                    error = errText(e)
                }
                busy = false
            }
        }
    }
}

// ---------------------------------------------------------------- code
@Composable
fun OtpScreen(phone: String, onBack: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var wait by remember { mutableIntStateOf(60) }
    val focus = remember { FocusRequester() }

    fun verify(c: String) {
        if (busy) return
        busy = true; error = ""
        scope.launch {
            try {
                val j = Api.post("/api/otp/verify", JSONObject().put("phone", phone).put("code", c))
                Repo.auth.signInWithCustomToken(j.getString("token")).await()
                Prefs.sp.edit().putString("phone", phone).apply()
                onDone()
            } catch (e: Exception) {
                error = errText(e); code = ""
            }
            busy = false
        }
    }

    // reads the SMS by itself (Google SMS Retriever: no SMS permission)
    DisposableEffect(Unit) {
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i?.action != SmsRetriever.SMS_RETRIEVED_ACTION) return
                val ex = i.extras ?: return
                @Suppress("DEPRECATION")
                val st = ex.get(SmsRetriever.EXTRA_STATUS) as? Status ?: return
                if (st.statusCode != CommonStatusCodes.SUCCESS) return
                val msg = ex.getString(SmsRetriever.EXTRA_SMS_MESSAGE) ?: return
                val found = Regex("\\b(\\d{6})\\b").find(msg)?.groupValues?.get(1) ?: return
                code = found
                verify(found)
            }
        }
        try {
            SmsRetriever.getClient(ctx).startSmsRetriever()
            ContextCompat.registerReceiver(ctx, rx, IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION),
                SmsRetriever.SEND_PERMISSION, null, ContextCompat.RECEIVER_EXPORTED)
        } catch (_: Exception) {
        }
        onDispose { try { ctx.unregisterReceiver(rx) } catch (_: Exception) {} }
    }
    LaunchedEffect(wait) { if (wait > 0) { delay(1000); wait-- } }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Exception) {} }

    Column(Modifier.fillMaxSize().background(P.bg)) {
        TopBar("", onBack) { LangBall(Modifier.padding(end = 8.dp)) }
        Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(76.dp).clip(RoundedCornerShape(24.dp)).background(P.pill), contentAlignment = Alignment.Center) { Ic("lock", Brand, 38.dp) }
            Spacer(Modifier.height(18.dp))
            Text(t("otp_t"), color = P.tx, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(t("otp_sent"), color = P.tx2, fontSize = 15.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("+88 $phone", color = P.tx, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.width(8.dp))
                Text(t("wrong_num"), color = Brand, fontSize = 14.sp, modifier = Modifier.clickable { onBack() })
            }
            Spacer(Modifier.height(26.dp))
            BasicTextField(
                code, { v -> val d = v.filter { it.isDigit() }.take(6); code = d; error = ""; if (d.length == 6) verify(d) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.focusRequester(focus),
                decorationBox = { inner ->
                    Box {
                        Box(Modifier.size(1.dp)) { inner() }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            repeat(6) { i ->
                                val ch = code.getOrNull(i)?.toString() ?: ""
                                Box(
                                    Modifier.width(46.dp).height(56.dp).clip(RoundedCornerShape(14.dp))
                                        .background(if (ch.isNotEmpty()) P.pill else P.bg2)
                                        .border(2.dp, if (i == code.length) Brand else Color.Transparent, RoundedCornerShape(14.dp)),
                                    contentAlignment = Alignment.Center
                                ) { Text(num(ch), color = Brand, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold) }
                            }
                        }
                    }
                }
            )
            Spacer(Modifier.height(18.dp))
            when {
                busy -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(color = Brand, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp)); Text(t("verifying"), color = P.tx2)
                }
                error.isNotEmpty() -> Text(error, color = Red, fontSize = 14.sp, textAlign = TextAlign.Center)
                else -> Text(t("waiting"), color = P.tx2, fontSize = 14.sp, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(22.dp))
            if (wait > 0) Text("${t("resend_in")} ${num("0:" + wait.toString().padStart(2, '0'))}", color = P.tx2, fontSize = 14.sp)
            else Text(t("resend"), color = Brand, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                scope.launch {
                    try {
                        Api.post("/api/otp/send", JSONObject().put("phone", phone).put("hash", appHash(ctx)))
                        SmsRetriever.getClient(ctx).startSmsRetriever()
                        wait = 60; error = ""
                    } catch (e: Exception) { error = errText(e) }
                }
            })
        }
    }
}

// ---------------------------------------------------------------- profile (first time and edit)
@Composable
fun ProfileScreen(first: Boolean, onBack: (() -> Unit)?, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me = Repo.me
    var name by remember { mutableStateOf(me?.name ?: "") }
    var about by remember { mutableStateOf(me?.about?.ifBlank { null } ?: t("about_def")) }
    var photo by remember { mutableStateOf(me?.photo ?: "") }
    var busy by remember { mutableStateOf(false) }
    var uploading by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            uploading = true
            scope.launch {
                try {
                    val bytes = Media.jpeg(ctx, uri, 640)
                    photo = Api.upload(bytes, "avatar")
                } catch (e: Exception) { toast(ctx, t("e_send")) }
                uploading = false
            }
        }
    }
    val phone = Prefs.sp.getString("phone", "") ?: me?.phone ?: ""

    Column(Modifier.fillMaxSize().background(P.bg)) {
        if (onBack != null) TopBar(t("profile"), onBack)
        else Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.End) { LangBall() }
        Column(
            Modifier.weight(1f).padding(horizontal = 24.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (first) {
                Text(t("prof_t"), color = P.tx, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(6.dp))
                Text(t("prof_s"), color = P.tx2, fontSize = 14.sp)
            }
            Spacer(Modifier.height(24.dp))
            Box(Modifier.size(124.dp).clickable { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                Avatar(name.ifBlank { "?" }, photo, Repo.uid ?: "", 120.dp)
                Box(
                    Modifier.align(Alignment.BottomEnd).size(40.dp).clip(CircleShape).background(P.bg).padding(3.dp).clip(CircleShape).background(Mint),
                    contentAlignment = Alignment.Center
                ) {
                    if (uploading) CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                    else Ic("camera", Color.White, 20.dp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(t("tap_photo"), color = P.tx2, fontSize = 12.5.sp)
            Spacer(Modifier.height(20.dp))
            Field(name, { name = it }, t("your_name"), "person", maxLen = 30)
            Spacer(Modifier.height(12.dp))
            Field(about, { about = it }, t("about"), "emoji", maxLen = 80)
            if (!first && phone.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(P.bg2).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Ic("call", P.tx2, 22.dp); Spacer(Modifier.width(10.dp)); Text("+88 $phone", color = P.tx2, fontSize = 17.sp)
                }
            }
        }
        Box(Modifier.padding(24.dp)) {
            GradButton(if (first) t("next") else t("save"), enabled = name.isNotBlank() && !uploading, busy = busy) {
                busy = true
                Repo.saveProfile(name, about, photo, phone)
                onDone()
            }
        }
    }
}
