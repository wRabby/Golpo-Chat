package com.mobiletips.golpo

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

// ---------------------------------------------------------------- the other person's profile (imo style)
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ContactScreen(uid: String, openChat: (String) -> Unit, openPage: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val u = Repo.user(uid)
    val me = Repo.uid ?: ""
    val chatId = Repo.chatId(me, uid)
    val call = rememberCaller(uid)
    val blocked = Repo.isBlockedByMe(uid)
    val name = u?.shown ?: ""
    var ask by remember { mutableStateOf("") }
    var bigPhoto by remember { mutableStateOf(false) }
    var photos by remember { mutableIntStateOf(-1) }
    LaunchedEffect(chatId) {
        photos = try {
            Repo.db.collection("chats").document(chatId).collection("messages").whereEqualTo("kind", "img").get().await()
                .documents.count { it.getBoolean("del") != true }
        } catch (_: Exception) { 0 }
    }
    val hidden = Repo.hidesFromMe(u)
    val status = when {
        hidden -> ""
        u?.online == true -> t("online")
        else -> lastSeenText(u?.lastSeen ?: 0)
    }
    fun tryCall(video: Boolean) {
        when {
            blocked -> ask = "unblock"
            Repo.blocksMe(uid) || Repo.cantCall(uid) -> toast(ctx, t("cant_call"))
            else -> call(video)
        }
    }

    Box(Modifier.fillMaxSize().background(P.bg2)) {
        Column(Modifier.fillMaxSize()) {
            TopBar(name, onBack)
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                // ---- header
                Column(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(118.dp).clip(CircleShape).border(3.dp, Brush.linearGradient(listOf(Brand, Mint)), CircleShape).padding(4.dp)) {
                        Avatar(name.ifBlank { "?" }, u?.photo ?: "", uid, 110.dp, online = u?.online == true && !hidden,
                            onClick = { if (!u?.photo.isNullOrEmpty()) bigPhoto = true })
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(name, color = P.tx, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(2.dp))
                    Text("+88 " + num(u?.phone ?: ""), color = P.tx2, fontSize = 15.sp,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).combinedClickable(onClick = {}, onLongClick = {
                            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("phone", u?.phone ?: ""))
                            toast(ctx, t("copied"))
                        }).padding(horizontal = 6.dp, vertical = 2.dp))
                    if (status.isNotEmpty()) Text(status, color = if (u?.online == true) Mint else P.tx2, fontSize = 13.sp,
                        fontWeight = if (u?.online == true) FontWeight.SemiBold else FontWeight.Normal)
                    if (!u?.about.isNullOrBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(u?.about ?: "", color = P.tx, fontSize = 14.5.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 30.dp))
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                        RoundAction("o_call", t("voice_call")) { tryCall(false) }
                        RoundAction("o_video", t("video_call")) { tryCall(true) }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                ProCard {
                    ProRow("o_image", t("shared_photos"), onClick = { openPage("media") }) {
                        if (photos > 0) Text(num("$photos"), color = P.tx2, fontSize = 15.sp, modifier = Modifier.padding(end = 4.dp))
                        Ic("right", P.tx2, 22.dp)
                    }
                    ProRow("o_palette", t("chat_wall"), onClick = { openPage("wall") }) { Ic("right", P.tx2, 22.dp) }
                    ProRow("o_shortcut", t("shortcut"), sub = t("shortcut_s"), onClick = { addShortcut(ctx, chatId, name) }) { Ic("right", P.tx2, 22.dp) }
                    val fav = Repo.isFav(uid)
                    ProRow(if (fav) "star" else "o_star", t("add_fav"), sub = t("add_fav_s"), tint = if (fav) Color(0xFFFFB300) else P.tx,
                        onClick = { Repo.setFlag("fav", uid, !fav) }) { ProSwitch(fav) { Repo.setFlag("fav", uid, it) } }
                }
                ProCard {
                    val muted = Prefs.isMuted(uid)
                    ProRow("o_mute", t("mute_notif"), onClick = { Prefs.setMuted(uid, !muted) }) { ProSwitch(muted) { Prefs.setMuted(uid, it) } }
                    ProRow("o_call", t("call_privacy"), sub = if (Repo.noCallFrom(uid)) t("calls_blocked") else t("calls_allowed"),
                        onClick = { openPage("callpriv") }) { Ic("right", P.tx2, 22.dp) }
                    val inv = Repo.invisibleTo(uid)
                    ProRow("o_eye_off", t("invisible"), sub = t("invisible_s"), onClick = { Repo.setFlag("invisible", uid, !inv) }) {
                        ProSwitch(inv) { Repo.setFlag("invisible", uid, it) }
                    }
                }
                ProCard {
                    ProRow("o_person", t("source"), sub = t("source_s"), onClick = {})
                }
                ProCard {
                    ProRow("o_delete", t("clear_chat"), tint = Red, onClick = { ask = "clear" })
                    ProRow("block", (if (blocked) t("unblock") else t("block")) + " " + name, tint = Red,
                        onClick = { ask = if (blocked) "unblock" else "block" })
                    ProRow("o_flag", t("report") + " " + name, tint = Red, onClick = { ask = "report" })
                }
                Spacer(Modifier.height(110.dp))
            }
        }

        // ---- big Message button (stays at the bottom)
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(P.bg2.copy(alpha = 0f), P.bg2, P.bg2)))
                .padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 14.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().height(56.dp).press(RoundedCornerShape(16.dp)) { openChat(uid) }.background(Grad),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
            ) {
                Ic("o_chat", Color.White, 24.dp)
                Spacer(Modifier.width(10.dp))
                Text(t("message_btn"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    when (ask) {
        "block" -> Confirm(t("block") + " $name?", t("block_q"), t("block"), danger = true, onCancel = { ask = "" }) { Repo.block(uid, true); ask = "" }
        "unblock" -> Confirm(t("unblock") + " $name?", t("unblock_q"), t("unblock"), onCancel = { ask = "" }) { Repo.block(uid, false); ask = "" }
        "clear" -> Confirm(t("clear_chat") + "?", t("clear_q"), t("clear"), danger = true, onCancel = { ask = "" }) { Repo.clearChat(chatId); ask = "" }
        "report" -> ReportDialog(onCancel = { ask = "" }) { reason -> Repo.report(uid, reason); toast(ctx, t("reported")); ask = "" }
    }
    if (bigPhoto) {
        Dialog(onDismissRequest = { bigPhoto = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Box(Modifier.fillMaxSize().background(Color.Black).clickable { bigPhoto = false }, contentAlignment = Alignment.Center) {
                AsyncImage(u?.photo ?: "", null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                Box(Modifier.align(Alignment.TopStart).padding(12.dp)) { IconBtn("close", Color.White) { bigPhoto = false } }
            }
        }
    }
}

private fun addShortcut(ctx: Context, chatId: String, name: String) {
    try {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) { toast(ctx, t("shortcut_fail")); return }
        val intent = Intent(ctx, MainActivity::class.java).setAction(Intent.ACTION_VIEW).putExtra("chat", chatId)
        val info = ShortcutInfoCompat.Builder(ctx, "chat_$chatId")
            .setShortLabel(name.ifBlank { "Golpo Chat" }.take(20))
            .setIcon(IconCompat.createWithResource(ctx, R.mipmap.ic_launcher))
            .setIntent(intent)
            .build()
        ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
    } catch (_: Exception) {
        toast(ctx, t("shortcut_fail"))
    }
}

// ---------------------------------------------------------------- building blocks (clean, imo-like)
@Composable
fun ProCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.padding(horizontal = 14.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(P.card)
        .border(1.dp, P.ln, RoundedCornerShape(20.dp)), content = content)
}

@Composable
fun ProRow(icon: String, title: String, sub: String? = null, tint: Color = P.tx, onClick: () -> Unit, end: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().pressRow { onClick() }.padding(horizontal = 18.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
        Ic(icon, if (tint == P.tx) P.tx.copy(alpha = .85f) else tint, 25.dp)
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = if (tint == Red) Red else P.tx, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, color = P.tx2, fontSize = 13.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) { end() }
    }
}

@Composable
fun ProSwitch(on: Boolean, set: (Boolean) -> Unit) {
    Switch(on, set, colors = SwitchDefaults.colors(
        checkedTrackColor = Brand, checkedThumbColor = Color.White,
        uncheckedTrackColor = P.card, uncheckedThumbColor = P.tx2, uncheckedBorderColor = P.tx2,
    ))
}

@Composable
private fun RoundAction(icon: String, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(58.dp).press(CircleShape) { onClick() }.background(P.card).border(1.dp, P.ln, CircleShape),
            contentAlignment = Alignment.Center) { Ic(icon, Brand, 26.dp) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = P.tx, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun ReportDialog(onCancel: () -> Unit, onSend: (String) -> Unit) {
    var pick by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onCancel) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(P.card).padding(vertical = 18.dp)) {
            Text(t("report_t"), color = P.tx, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 22.dp))
            Spacer(Modifier.height(8.dp))
            listOf("r_spam", "r_harass", "r_fake", "r_bad", "r_other").forEach { k ->
                Row(Modifier.fillMaxWidth().clickable { pick = k }.padding(horizontal = 22.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Radio(pick == k)
                    Spacer(Modifier.width(14.dp))
                    Text(t(k), color = P.tx, fontSize = 15.5.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.End) {
                Text(t("cancel"), color = Brand, fontWeight = FontWeight.Bold, modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { onCancel() }.padding(12.dp))
                Spacer(Modifier.width(6.dp))
                Text(t("send"), color = Color.White, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(if (pick.isEmpty()) P.ln else Red)
                        .clickable(enabled = pick.isNotEmpty()) { onSend(t(pick)) }.padding(horizontal = 16.dp, vertical = 12.dp))
            }
        }
    }
}

@Composable
fun Radio(on: Boolean) {
    Box(Modifier.size(22.dp).clip(CircleShape).border(2.dp, if (on) Brand else P.tx2, CircleShape), contentAlignment = Alignment.Center) {
        if (on) Box(Modifier.size(12.dp).clip(CircleShape).background(Brand))
    }
}

// ---------------------------------------------------------------- profile sub pages
@Composable
fun ContactSubPage(uid: String, page: String, onBack: () -> Unit) {
    val title = when (page) { "media" -> t("shared_photos"); "wall" -> t("chat_wall"); else -> t("call_privacy") }
    val chatId = if (uid.startsWith("g_")) uid else Repo.chatId(Repo.uid ?: "", uid)
    Column(Modifier.fillMaxSize().background(P.bg2)) {
        TopBar(title, onBack)
        when (page) {
            "media" -> MediaGrid(chatId)
            "wall" -> WallPage(chatId)
            else -> CallPrivacyPage(uid)
        }
    }
}

@Composable
private fun MediaGrid(chatId: String) {
    val media = remember { mutableStateListOf<Msg>() }
    var loaded by remember { mutableStateOf(false) }
    var view by remember { mutableStateOf<Msg?>(null) }
    LaunchedEffect(chatId) {
        try {
            val c = Repo.db.collection("chats").document(chatId).collection("messages")
            val docs = c.whereEqualTo("kind", "img").get().await().documents + c.whereEqualTo("kind", "video").get().await().documents
            val list = docs.filter { it.getBoolean("del") != true }.map { it.toMsg() }.sortedByDescending { it.at }.filter { it.url.isNotEmpty() }
            media.clear(); media.addAll(list)
        } catch (_: Exception) {}
        loaded = true
    }
    if (loaded && media.isEmpty()) {
        Text(t("no_photos"), color = P.tx2, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(40.dp))
    }
    LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize().padding(2.dp)) {
        items(media, key = { it.id }) { m ->
            Box(Modifier.padding(2.dp).aspectRatio(1f).press(RoundedCornerShape(6.dp), scaleTo = 0.95f) { view = m }.background(P.bg)) {
                AsyncImage(if (m.kind == "video") m.thumb else m.url, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                if (m.kind == "video") Box(Modifier.align(Alignment.Center).size(34.dp).clip(CircleShape).background(Color.Black.copy(alpha = .5f)),
                    contentAlignment = Alignment.Center) { Ic("play", Color.White, 22.dp) }
            }
        }
    }
    view?.let { m -> MediaViewer(m.url, m.kind == "video") { view = null } }
}

/** Pick a gallery photo as chat background ("all" = every chat). */
@Composable
fun rememberWallPicker(key: String): () -> Unit {
    val ctx = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val pick = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            try {
                val bytes = Media.jpeg(ctx, uri, 1600)
                val f = java.io.File(ctx.filesDir, "wall_" + key.hashCode() + "_" + System.currentTimeMillis() + ".jpg")
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { f.writeBytes(bytes) }
                val old = Prefs.wallImg(key)
                Prefs.setWallImg(key, f.absolutePath)
                if (old.isNotEmpty()) try { java.io.File(old).delete() } catch (_: Exception) {}
            } catch (_: Exception) { toast(ctx, t("e_send")) }
        }
    }
    return { pick.launch(androidx.activity.result.PickVisualMediaRequest(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly)) }
}

@Composable
private fun WallPage(chatId: String) {
    val cur = Prefs.chatWall(chatId)
    val img = Prefs.wallImg(chatId)
    val pick = rememberWallPicker(chatId)
    Column(Modifier.verticalScroll(rememberScrollState())) {
        ProCard {
            Row(Modifier.fillMaxWidth().pressRow { Prefs.setChatWall(chatId, -1); Prefs.setWallImg(chatId, "") }.padding(horizontal = 18.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Radio(cur == -1 && img.isEmpty()); Spacer(Modifier.width(14.dp)); Text(t("wall_default"), color = P.tx, fontSize = 16.sp)
            }
            Row(Modifier.fillMaxWidth().pressRow { pick() }.padding(horizontal = 18.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Radio(img.isNotEmpty()); Spacer(Modifier.width(14.dp))
                Text(t("wall_photo"), color = P.tx, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Ic("o_image", Brand, 22.dp)
            }
        }
        ProCard {
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                WALLS_LIGHT.indices.forEach { i ->
                    val on = cur == i && img.isEmpty()
                    Box(
                        Modifier.weight(1f).aspectRatio(0.6f).press(RoundedCornerShape(12.dp)) { Prefs.setChatWall(chatId, i); Prefs.setWallImg(chatId, "") }
                            .background(wallColor(i))
                            .border(if (on) 3.dp else 1.dp, if (on) Brand else P.ln, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) { if (on) Ic("check", Brand, 22.dp) }
                }
            }
        }
        Box(Modifier.padding(16.dp).fillMaxWidth().height(170.dp).clip(RoundedCornerShape(18.dp))
            .background(wallColor(if (cur == -1) Prefs.wall else cur))) {
            if (img.isNotEmpty()) AsyncImage(java.io.File(img), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Hi! 👋", color = P.tx, fontSize = 15.sp,
                    modifier = Modifier.clip(RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp)).background(P.inB).padding(horizontal = 12.dp, vertical = 8.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                    Text("Golpo Chat 😊", color = P.tx, fontSize = 15.sp,
                        modifier = Modifier.clip(RoundedCornerShape(16.dp, 4.dp, 16.dp, 16.dp)).background(P.outB).padding(horizontal = 12.dp, vertical = 8.dp))
                }
            }
        }
    }
}

@Composable
private fun CallPrivacyPage(uid: String) {
    val off = Repo.noCallFrom(uid)
    ProCard {
        Row(Modifier.fillMaxWidth().clickable { Repo.setFlag("noCall", uid, false) }.padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Radio(!off); Spacer(Modifier.width(14.dp)); Text(t("allow_calls"), color = P.tx, fontSize = 16.sp)
        }
        Row(Modifier.fillMaxWidth().clickable { Repo.setFlag("noCall", uid, true) }.padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Radio(off); Spacer(Modifier.width(14.dp)); Text(t("no_calls_from"), color = P.tx, fontSize = 16.sp)
        }
    }
}
