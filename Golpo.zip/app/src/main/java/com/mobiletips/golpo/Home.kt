package com.mobiletips.golpo

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun Home(tab: String, onTab: (String) -> Unit, openChat: (String) -> Unit, newChat: () -> Unit, editProfile: () -> Unit) {
    Column(Modifier.fillMaxSize().background(P.bg)) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(start = 18.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (tab == "chats") {
                Text("Golpo", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Brand)
                Text(" Chat", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Mint, modifier = Modifier.weight(1f))
            } else {
                Text(t(tab), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = P.tx, modifier = Modifier.weight(1f))
            }
            LangBall(Modifier.padding(end = 6.dp))
        }
        Box(Modifier.weight(1f)) {
            when (tab) {
                "chats" -> ChatList(openChat)
                "calls" -> CallsTab()
                else -> SettingsTab(editProfile)
            }
            if (tab == "chats") Fab("add", Modifier.align(Alignment.BottomEnd)) { newChat() }
        }
        BottomNav(tab, onTab)
    }
}

@Composable
fun Fab(icon: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.padding(18.dp).size(58.dp).shadow(10.dp, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp))
            .background(Grad).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Ic(icon, Color.White, 28.dp) }
}

@Composable
fun BottomNav(tab: String, onTab: (String) -> Unit) {
    val unread = Repo.chats.count { it.unread > 0 }
    Column {
        Box(Modifier.fillMaxWidth().height(1.dp).background(P.ln))
        Row(Modifier.fillMaxWidth().background(P.bg).padding(vertical = 6.dp)) {
            listOf("chats" to "chat", "calls" to "call", "settings" to "gear").forEach { (k, ic) ->
                val on = tab == k
                Column(
                    Modifier.weight(1f).clickable { onTab(k) }.padding(vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.width(62.dp).height(32.dp).clip(RoundedCornerShape(16.dp)).background(if (on) P.pill else Color.Transparent),
                            contentAlignment = Alignment.Center
                        ) { Ic(ic, if (on) Brand else P.tx2) }
                        if (k == "chats" && unread > 0) {
                            Box(
                                Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-6).dp).size(20.dp).clip(CircleShape).background(Mint),
                                contentAlignment = Alignment.Center
                            ) { Text(num("$unread"), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                    Text(t(k), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (on) P.tx else P.tx2)
                }
            }
        }
    }
}

@Composable
fun SearchBox(q: String, onQ: (String) -> Unit) {
    Row(
        Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(P.bg2)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ic("search", P.tx2, 20.dp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (q.isEmpty()) Text(t("search"), color = P.tx2, fontSize = 15.sp)
            BasicTextField(q, onQ, singleLine = true, textStyle = TextStyle(color = P.tx, fontSize = 15.sp),
                cursorBrush = SolidColor(Brand), modifier = Modifier.fillMaxWidth())
        }
        if (q.isNotEmpty()) Box(Modifier.clickable { onQ("") }) { Ic("close", P.tx2, 18.dp) }
    }
}

@Composable
fun Tick(st: Int, pending: Boolean, size: Int = 17) {
    when {
        pending -> Ic("clock", P.tx2, size.dp)
        st >= 3 -> Ic("check2", Blue, size.dp)
        st == 2 -> Ic("check2", P.tx2, size.dp)
        else -> Ic("check", P.tx2, size.dp)
    }
}

// ---------------------------------------------------------------- chat list
@Composable
fun ChatList(openChat: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(2000); now = System.currentTimeMillis() } }
    val me = Repo.uid ?: ""
    val list = Repo.chats.filter { c ->
        val u = Repo.user(c.other)
        (filter == "all" || c.unread > 0) &&
            (q.isBlank() || (u?.name ?: "").contains(q, true) || (u?.phone ?: "").contains(q) || c.lastText.contains(q, true))
    }
    Column(Modifier.fillMaxSize()) {
        SearchBox(q) { q = it }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("all", "unread").forEach { f ->
                val n = if (f == "unread") Repo.chats.count { it.unread > 0 } else 0
                Text(t(f) + if (n > 0) " " + num("$n") else "", color = if (filter == f) Color.White else P.tx2, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                    modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (filter == f) Brand else P.bg2).clickable { filter = f }
                        .padding(horizontal = 14.dp, vertical = 7.dp))
            }
        }
        if (list.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(top = 70.dp, start = 40.dp, end = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(90.dp).clip(CircleShape).background(P.bg2), contentAlignment = Alignment.Center) { Ic("chat", Brand, 42.dp) }
                Spacer(Modifier.height(14.dp))
                Text(t("no_chats"), color = P.tx2, textAlign = TextAlign.Center)
            }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(list, key = { it.id }) { c ->
                val u = Repo.user(c.other)
                val typing = now - c.otherTyping in 0..6000
                Row(
                    Modifier.fillMaxWidth().clickable { openChat(c.other) }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(u?.shown ?: "?", u?.photo ?: "", c.other, 54.dp, online = u?.online == true)
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(u?.shown ?: "…", color = P.tx, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Text(shortTime(c.updated), color = if (c.unread > 0) Mint else P.tx2, fontSize = 12.sp,
                                fontWeight = if (c.unread > 0) FontWeight.Bold else FontWeight.Normal)
                        }
                        Spacer(Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (typing) {
                                Text(t("typing"), color = Mint, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            } else {
                                if (c.lastFrom == me && c.lastKind != "del") { LastTick(c); Spacer(Modifier.width(3.dp)) }
                                Text(previewOf(c.lastKind, c.lastText), color = P.tx2, fontSize = 14.sp, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            }
                            if (c.unread > 0) {
                                Box(
                                    Modifier.padding(start = 6.dp).heightIn(min = 21.dp).widthIn(min = 21.dp).clip(CircleShape).background(Mint).padding(horizontal = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) { Text(num("${c.unread}"), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

/** On the list the exact tick of the last message is not stored, so it shows a plain sent tick. */
@Composable
private fun LastTick(c: Chat) = Ic("check2", P.tx2, 16.dp)

// ---------------------------------------------------------------- new chat
@Composable
fun NewChat(onBack: () -> Unit, open: (String) -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val me = Repo.uid
    val people = Repo.users.values.filter { it.uid != me && it.name.isNotBlank() }
        .filter { q.isBlank() || it.name.contains(q, true) || it.phone.contains(q.filter { ch -> ch.isDigit() }.ifEmpty { "~" }) }
        .sortedBy { it.name.lowercase() }
    Column(Modifier.fillMaxSize().background(P.bg)) {
        TopBar(t("new_chat"), onBack)
        SearchBox(q) { q = it }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Row(
                    Modifier.fillMaxWidth().clickable {
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, t("invite_text"))
                        }, t("invite")))
                    }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp).clip(CircleShape).background(Grad), contentAlignment = Alignment.Center) { Ic("share", Color.White, 22.dp) }
                    Spacer(Modifier.width(13.dp))
                    Text(t("invite"), color = P.tx, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Text(t("on_golpo") + " · " + num("${people.size}"), color = Brand, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 6.dp))
                if (people.isEmpty()) Text(t("nobody"), color = P.tx2, modifier = Modifier.padding(16.dp))
            }
            items(people, key = { it.uid }) { u ->
                Row(
                    Modifier.fillMaxWidth().clickable { open(u.uid) }.padding(horizontal = 16.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(u.shown, u.photo, u.uid, 48.dp, online = u.online)
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(u.shown, color = P.tx, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(u.about.ifBlank { u.phone }, color = P.tx2, fontSize = 13.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- calls (next update)
@Composable
fun CallsTab() {
    Column(Modifier.fillMaxSize().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(70.dp).clip(CircleShape).background(Green), contentAlignment = Alignment.Center) { Ic("call", Color.White, 32.dp) }
            Box(Modifier.size(70.dp).clip(CircleShape).background(Blue), contentAlignment = Alignment.Center) { Ic("video", Color.White, 32.dp) }
        }
        Spacer(Modifier.height(22.dp))
        Text(t("calls_t"), color = P.tx, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(t("calls_s"), color = P.tx2, textAlign = TextAlign.Center)
    }
}

// ---------------------------------------------------------------- settings
@Composable
fun SettingsTab(editProfile: () -> Unit) {
    val ctx = LocalContext.current
    val me = Repo.me
    var askOut by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Card {
            Row(Modifier.fillMaxWidth().clickable { editProfile() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(me?.shown ?: "?", me?.photo ?: "", Repo.uid ?: "", 64.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(me?.shown ?: "", color = P.tx, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text(me?.about ?: "", color = P.tx2, fontSize = 13.sp, maxLines = 2)
                }
                Ic("edit", Brand)
            }
        }
        Card {
            SetRow("lang", Color(0xFFB455F5), t("lang"), t("lang_now"), onClick = { Prefs.toggleLang() }) { LangBall() }
            SetRow("moon", Color(0xFF1D1640), t("dark"), null, onClick = { Prefs.setDarkMode(!Prefs.dark) }) {
                Switch(Prefs.dark, { Prefs.setDarkMode(it) }, colors = SwitchDefaults.colors(checkedTrackColor = Brand))
            }
        }
        Card {
            SetRow("help", Green, t("help"), "Mobile Tips", onClick = {
                ctx.startActivity(Intent(Intent.ACTION_SENDTO, android.net.Uri.parse("mailto:mdrasel666699990@gmail.com")).apply {
                    putExtra(Intent.EXTRA_SUBJECT, "Golpo Chat")
                })
            })
            SetRow("share", Color(0xFFFF4D79), t("invite"), null, onClick = {
                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, t("invite_text"))
                }, t("invite")))
            })
            SetRow("logout", Red, t("logout"), null, red = true, onClick = { askOut = true })
        }
        Text("from\nMobile Tips · Golpo Chat ${BuildConfig.VERSION_NAME}", color = P.tx2, fontSize = 12.5.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(20.dp))
    }
    if (askOut) Confirm(t("logout") + "?", t("logout_q"), t("logout"), danger = true, onCancel = { askOut = false }) {
        askOut = false
        Repo.signOut()
    }
}

@Composable
fun Card(content: @Composable () -> Unit) {
    Column(Modifier.padding(horizontal = 14.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(P.card)
        .then(Modifier.background(P.bg2.copy(alpha = if (Prefs.dark) 0f else .35f)))) { content() }
}

@Composable
fun SetRow(icon: String, color: Color, title: String, sub: String?, red: Boolean = false, onClick: () -> Unit,
           end: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(color), contentAlignment = Alignment.Center) { Ic(icon, Color.White, 22.dp) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = if (red) Red else P.tx, fontWeight = FontWeight.SemiBold, fontSize = 15.5.sp)
            if (sub != null) Text(sub, color = P.tx2, fontSize = 13.sp)
        }
        end()
    }
}

