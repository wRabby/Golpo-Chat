package com.mobiletips.golpo

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.KeyboardType
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun Home(tab: String, onTab: (String) -> Unit, openChat: (String) -> Unit, newChat: () -> Unit, editProfile: () -> Unit,
         openPage: (String) -> Unit, openStory: (String) -> Unit = {}, newStory: () -> Unit = {}) {
    Column(Modifier.fillMaxSize().background(P.bg)) {
        Row(Modifier.fillMaxWidth().height(62.dp).padding(start = 18.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (tab == "chats") {
                Text("Golpo", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Brand)
                Text(" Chat", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = BrandDark, modifier = Modifier.weight(1f))
                RingBtn("o_camera", Brand, 42.dp) { newStory() }
                Spacer(Modifier.width(10.dp))
                RingBtn("gear", P.tx, 42.dp) { onTab("settings") }
            } else {
                Text(t(tab), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = P.tx, modifier = Modifier.weight(1f))
            }
        }
        Box(Modifier.weight(1f)) {
            when (tab) {
                "chats" -> ChatList(openChat, openStory, newStory, openPage)
                "calls" -> CallsTab()
                else -> SettingsTab(editProfile, openPage)
            }
            if (tab == "chats") Fab("person_add", Modifier.align(Alignment.BottomEnd)) { newChat() }
        }
        BottomNav(tab, onTab)
    }
}

@Composable
fun Fab(icon: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.padding(18.dp).size(58.dp).shadow(10.dp, RoundedCornerShape(18.dp))
            .press(RoundedCornerShape(18.dp), scaleTo = 0.88f) { onClick() }.background(Grad),
        contentAlignment = Alignment.Center
    ) { Ic(icon, Color.White, 28.dp) }
}

@Composable
fun BottomNav(tab: String, onTab: (String) -> Unit) {
    val unread = Repo.chats.count { it.unread > 0 }
    Column {
        Box(Modifier.fillMaxWidth().height(1.dp).background(P.ln))
        Row(Modifier.fillMaxWidth().background(P.bg).padding(vertical = 6.dp)) {
            listOf("chats" to "chat", "calls" to "call", "settings" to "gear").forEach { (k, ic) ->
                val on = tab == k
                Column(
                    Modifier.weight(1f).press(RoundedCornerShape(16.dp), scaleTo = 0.9f) { onTab(k) }.padding(vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.width(62.dp).height(32.dp).clip(RoundedCornerShape(16.dp)).background(if (on) P.pill else Color.Transparent),
                            contentAlignment = Alignment.Center
                        ) { Ic(ic, if (on) Brand else P.tx2) }
                        if (k == "chats" && unread > 0) {
                            Box(
                                Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-6).dp).size(20.dp).clip(CircleShape).background(Red),
                                contentAlignment = Alignment.Center
                            ) { Text(num("$unread"), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                    Text(t(k), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (on) P.tx else P.tx2)
                }
            }
        }
    }
}

@Composable
fun SearchBox(q: String, onQ: (String) -> Unit) {
    Row(
        Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(P.bg2)
            .border(1.dp, P.ln, RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ic("search", P.tx2, 20.dp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (q.isEmpty()) Text(t("search"), color = P.tx2, fontSize = 15.sp)
            BasicTextField(q, onQ, singleLine = true, textStyle = TextStyle(color = P.tx, fontSize = 15.sp),
                cursorBrush = SolidColor(Brand), modifier = Modifier.fillMaxWidth())
        }
        if (q.isNotEmpty()) Box(Modifier.clickable { onQ("") }) { Ic("close", P.tx2, 18.dp) }
    }
}

@Composable
fun Tick(st: Int, pending: Boolean, size: Int = 17) {
    when {
        pending -> Ic("clock", P.tx2, size.dp)
        st >= 3 -> Ic("check2", Blue, size.dp)
        st == 2 -> Ic("check2", P.tx2, size.dp)
        else -> Ic("check", P.tx2, size.dp)
    }
}

// ---------------------------------------------------------------- chat list
@Composable
fun ChatList(openChat: (String) -> Unit, openStory: (String) -> Unit = {}, newStory: () -> Unit = {}, openPage: (String) -> Unit = {}) {
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(2000); now = System.currentTimeMillis() } }
    val me = Repo.uid ?: ""
    val list = Repo.chats.filter { c ->
        val u = Repo.user(c.other)
        (filter == "all" || c.unread > 0) &&
            (q.isBlank() || (u?.name ?: "").contains(q, true) || (u?.phone ?: "").contains(q) || c.lastText.contains(q, true) ||
                (c.group && c.name.contains(q, true)))
    }.sortedByDescending { Repo.isFav(if (it.group) it.id else it.other) }
    val ctx = LocalContext.current
    var notifOff by remember { mutableStateOf(false) }
    var ringIssue by remember { mutableStateOf(false) }
    LaunchedEffect(Repo.foreground) {
        notifOff = !NotificationManagerCompat.from(ctx).areNotificationsEnabled()
        ringIssue = !notifOff && !Prefs.sp.getBoolean("ring_setup_seen", false) && CallSetup.problems(ctx) > 0
    }
    val join = rememberJoiner()
    Column(Modifier.fillMaxSize()) {
        if (notifOff) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFFFFF3CD))
                    .clickable {
                        try {
                            ctx.startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName))
                        } catch (_: Exception) {}
                    }.padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Ic("bell", Color(0xFF8A6D00), 20.dp); Spacer(Modifier.width(10.dp))
                Text(t("notif_off"), color = Color(0xFF5C4800), fontSize = 13.5.sp, modifier = Modifier.weight(1f))
                Text(t("turn_on"), color = Brand, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
        if (ringIssue) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().press(RoundedCornerShape(14.dp), scaleTo = 0.98f) {
                    Prefs.sp.edit().putBoolean("ring_setup_seen", true).apply(); ringIssue = false; openPage("callsetup")
                }.background(P.pill).border(1.dp, Brand.copy(alpha = .3f), RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Ic("o_call", Brand, 20.dp); Spacer(Modifier.width(10.dp))
                Text(t("ring_banner"), color = P.tx, fontSize = 13.5.sp, modifier = Modifier.weight(1f))
                Text(t("fix"), color = Brand, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.width(6.dp))
                Box(Modifier.size(26.dp).press(CircleShape) { Prefs.sp.edit().putBoolean("ring_setup_seen", true).apply(); ringIssue = false },
                    contentAlignment = Alignment.Center) { Ic("close", P.tx2, 16.dp) }
            }
        }
        SearchBox(q) { q = it }
        LazyColumn(Modifier.fillMaxSize()) {
            item("head") {
              Column(Modifier.fillMaxWidth()) {
                    if (q.isBlank()) StoryBar(openStory, newStory)
                    Repo.joinable().forEach { c -> LiveCallCard(c) { join(c) } }
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("all", "unread").forEach { f ->
                            val n = if (f == "unread") Repo.chats.count { it.unread > 0 } else 0
                            val on = filter == f
                            Text(t(f) + if (n > 0) " " + num("$n") else "", color = if (on) Color.White else P.tx, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                                modifier = Modifier.press(RoundedCornerShape(20.dp)) { filter = f }.background(if (on) Brand else P.card)
                                    .border(1.dp, if (on) Brand else P.ln, RoundedCornerShape(20.dp))
                                    .padding(horizontal = 16.dp, vertical = 7.dp))
                        }
                    }
                    if (list.isEmpty()) {
                        Column(Modifier.fillMaxWidth().padding(top = 70.dp, start = 40.dp, end = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(90.dp).clip(CircleShape).background(P.bg2), contentAlignment = Alignment.Center) { Ic("chat", Brand, 42.dp) }
                            Spacer(Modifier.height(14.dp))
                            Text(t("no_chats"), color = P.tx2, textAlign = TextAlign.Center)
                        }
                    }
            
              }
            }
            items(list, key = { it.id }) { c ->
                val u = Repo.user(c.other)
                val typing = now - c.otherTyping in 0..6000
                Row(
                    Modifier.fillMaxWidth().pressRow { openChat(if (c.group) c.id else c.other) }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (c.group) GroupAvatar(c.name, c.photo, c.id, 54.dp)
                    else Avatar(u?.shown ?: "?", u?.photo ?: "", c.other, 54.dp, online = u?.online == true && !Repo.hidesFromMe(u))
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (Repo.isFav(if (c.group) c.id else c.other)) { Ic("star", Color(0xFFFFB300), 16.dp); Spacer(Modifier.width(4.dp)) }
                            Text(if (c.group) c.name else u?.shown ?: "…", color = P.tx, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Text(shortTime(c.updated), color = if (c.unread > 0) Brand else P.tx2, fontSize = 12.sp,
                                fontWeight = if (c.unread > 0) FontWeight.Bold else FontWeight.Normal)
                        }
                        Spacer(Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (typing) {
                                Text((if (c.group) (Repo.user(c.typingWho)?.shown ?: "") + " " else "") + t("typing"), color = Mint, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            } else {
                                if (c.lastFrom == me && c.lastKind != "del") { LastTick(c); Spacer(Modifier.width(3.dp)) }
                                val pre = if (c.group && c.lastFrom != me && c.lastKind != "sys" && c.lastFrom.isNotEmpty()) (Repo.user(c.lastFrom)?.shown ?: "") + ": " else ""
                                Text(if (c.cleared >= c.updated && c.cleared > 0) "" else pre + previewOf(c.lastKind, c.lastText), color = P.tx2, fontSize = 14.sp, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            }
                            if (c.unread > 0) {
                                Box(
                                    Modifier.padding(start = 6.dp).heightIn(min = 21.dp).widthIn(min = 21.dp).clip(CircleShape).background(Brand).padding(horizontal = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) { Text(num("${c.unread}"), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

/** On the list the exact tick of the last message is not stored, so it shows a plain sent tick. */
@Composable
private fun LastTick(c: Chat) = Ic("check2", P.tx2, 16.dp)

// ---------------------------------------------------------------- new chat / add friend
@Composable
fun NewChat(onBack: () -> Unit, newGroup: () -> Unit = {}, open: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me = Repo.uid
    var adding by remember { mutableStateOf(true) }
    var digits by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var found by remember { mutableStateOf<User?>(null) }
    // people I already chat with
    val friends = Repo.chats.mapNotNull { Repo.user(it.other) }.filter { it.uid != me }.distinctBy { it.uid }
        .sortedBy { it.shown.lowercase() }

    fun invite(phone: String?) {
        val i = if (phone != null) Intent(Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:$phone")).apply {
            putExtra("sms_body", t("invite_text"))
        } else Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, t("invite_text"))
        }, t("invite"))
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    fun search() {
        error = ""; found = null
        if (!Regex("^1[3-9]\\d{8}$").matches(digits)) { error = t("e_invalid_num"); return }
        val uid = "u880$digits"
        if (uid == me) { error = t("e_own_num"); return }
        busy = true
        scope.launch {
            try {
                val d = Repo.db.collection("users").document(uid).get().await()
                val u = if (d.exists()) d.toUser() else null
                if (u == null || u.name.isBlank()) error = t("e_not_found") else found = u
            } catch (e: Exception) {
                error = t("e_net")
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().background(P.bg)) {
        TopBar(t("new_chat"), onBack)
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                // ---- Add friend
                Row(
                    Modifier.fillMaxWidth().clickable { adding = !adding }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp).clip(CircleShape).background(Grad), contentAlignment = Alignment.Center) { Ic("person_add", Color.White, 24.dp) }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t("add_friend"), color = P.tx, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(t("add_friend_s"), color = P.tx2, fontSize = 13.sp)
                    }
                }
                if (adding) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                        Field(digits, { v ->
                            digits = v.filter { it.isDigit() }.removePrefix("880").removePrefix("0").take(10)
                            error = ""; found = null
                        }, "1XXX-XXXXXX", keyboard = KeyboardType.Phone, prefix = "+880", maxLen = 16)
                        Spacer(Modifier.height(10.dp))
                        GradButton(t("find"), enabled = digits.isNotEmpty(), busy = busy) { search() }
                        if (error.isNotEmpty()) {
                            Spacer(Modifier.height(12.dp))
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Red.copy(alpha = .10f)).padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(error, color = Red, fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp, modifier = Modifier.weight(1f))
                                if (error == t("e_not_found")) {
                                    Text(t("invite_btn"), color = Brand, fontWeight = FontWeight.Bold, fontSize = 14.5.sp,
                                        modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { invite("0$digits") }.padding(8.dp))
                                }
                            }
                        }
                        found?.let { u ->
                            Spacer(Modifier.height(12.dp))
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(P.bg2).clickable { open(u.uid) }.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Avatar(u.shown, u.photo, u.uid, 52.dp, online = u.online)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(u.shown, color = P.tx, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(num(u.phone), color = P.tx2, fontSize = 13.sp)
                                }
                                Text(t("message_btn"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Grad).padding(horizontal = 14.dp, vertical = 9.dp))
                            }
                        }
                    }
                }
                // ---- New group
                Row(
                    Modifier.fillMaxWidth().clickable { newGroup() }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp).clip(CircleShape).background(Grad), contentAlignment = Alignment.Center) { Ic("group", Color.White, 24.dp) }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t("g_new_title"), color = P.tx, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(t("g_new_s"), color = P.tx2, fontSize = 13.sp)
                    }
                }
                // ---- Invite
                Row(
                    Modifier.fillMaxWidth().clickable { invite(null) }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp).clip(CircleShape).background(P.bg2), contentAlignment = Alignment.Center) { Ic("share", Brand, 22.dp) }
                    Spacer(Modifier.width(13.dp))
                    Text(t("invite"), color = P.tx, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                if (friends.isNotEmpty()) {
                    Text(t("my_friends") + " · " + num("${friends.size}"), color = Brand, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                        modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 6.dp))
                }
            }
            items(friends, key = { it.uid }) { u ->
                Row(
                    Modifier.fillMaxWidth().clickable { open(u.uid) }.padding(horizontal = 16.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(u.shown, u.photo, u.uid, 48.dp, online = u.online)
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(u.shown, color = P.tx, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(u.about.ifBlank { num(u.phone) }, color = P.tx2, fontSize = 13.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            item { Spacer(Modifier.height(30.dp)) }
        }
    }
}

// ---------------------------------------------------------------- calls history
private data class CallLog(val id: String, val other: String, val out: Boolean, val video: Boolean, val state: String, val at: Long, val dur: Int)

@Composable
fun CallsTab() {
    val me = Repo.uid ?: ""
    val logs = remember { mutableStateListOf<CallLog>() }
    DisposableEffect(me) {
        val reg = Repo.db.collection("calls").whereArrayContains("members", me).addSnapshotListener { s, _ ->
            if (s == null) return@addSnapshotListener
            val list = s.documents.mapNotNull { d ->
                val from = d.getString("from") ?: return@mapNotNull null
                val to = d.getString("to") ?: return@mapNotNull null
                CallLog(d.id, if (from == me) to else from, from == me, d.getBoolean("video") ?: false, d.getString("state") ?: "",
                    d.getTimestamp("created", com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L,
                    (d.getLong("dur") ?: 0L).toInt())
            }.sortedByDescending { it.at }.take(150)
            logs.clear(); logs.addAll(list)
        }
        onDispose { reg.remove() }
    }
    if (logs.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(70.dp).clip(CircleShape).background(Green), contentAlignment = Alignment.Center) { Ic("call", Color.White, 32.dp) }
                Box(Modifier.size(70.dp).clip(CircleShape).background(Blue), contentAlignment = Alignment.Center) { Ic("video", Color.White, 32.dp) }
            }
            Spacer(Modifier.height(22.dp))
            Text(t("no_calls"), color = P.tx2, textAlign = TextAlign.Center)
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(logs, key = { it.id }) { c -> CallRow(c) }
        item { Spacer(Modifier.height(30.dp)) }
    }
}

@Composable
private fun CallRow(c: CallLog) {
    val u = Repo.user(c.other)
    val call = rememberCaller(c.other)
    val missed = !c.out && c.dur == 0 && c.state != "declined" && c.state != "ended" && c.state != "accepted"
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(u?.shown ?: "?", u?.photo ?: "", c.other, 50.dp)
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(u?.shown ?: "…", color = if (missed) Red else P.tx, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ic(if (c.out) "call_made" else if (missed) "call_missed" else "call_received", if (missed) Red else Green, 16.dp)
                Spacer(Modifier.width(4.dp))
                val d = if (c.dur > 0) " · " + num("%02d:%02d".format(c.dur / 60, c.dur % 60)) else ""
                Text(shortTime(c.at) + d, color = P.tx2, fontSize = 13.sp)
            }
        }
        RingBtn(if (c.video) "video" else "call", Brand, 44.dp) { call(c.video) }
    }
}

@Composable
fun Card(content: @Composable () -> Unit) {
    Column(Modifier.padding(horizontal = 14.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(P.card)
        .border(1.dp, P.ln, RoundedCornerShape(20.dp))) { content() }
}

@Composable
fun SetRow(icon: String, color: Color, title: String, sub: String?, red: Boolean = false, onClick: () -> Unit,
           end: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().pressRow { onClick() }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(color), contentAlignment = Alignment.Center) { Ic(icon, Color.White, 22.dp) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = if (red) Red else P.tx, fontWeight = FontWeight.SemiBold, fontSize = 15.5.sp)
            if (sub != null) Text(sub, color = P.tx2, fontSize = 13.sp)
        }
        end()
    }
}


@Composable
fun GroupAvatar(name: String, photo: String, seed: String, size: androidx.compose.ui.unit.Dp) {
    Box(Modifier.size(size)) {
        Avatar(name.ifBlank { "?" }, photo, seed, size)
        Box(
            Modifier.align(Alignment.BottomEnd).size(size * 0.36f).clip(CircleShape).background(P.bg).padding(2.dp).clip(CircleShape).background(Brand),
            contentAlignment = Alignment.Center
        ) { Ic("group", Color.White, size * 0.22f) }
    }
}
