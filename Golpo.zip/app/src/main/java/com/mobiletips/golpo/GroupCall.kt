package com.mobiletips.golpo

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import io.livekit.android.LiveKit
import io.livekit.android.RoomOptions
import io.livekit.android.events.RoomEvent
import io.livekit.android.events.collect
import io.livekit.android.renderer.TextureViewRenderer
import io.livekit.android.room.Room
import io.livekit.android.room.participant.Participant
import io.livekit.android.room.track.CameraPosition
import io.livekit.android.room.track.LocalVideoTrack
import io.livekit.android.room.track.Track
import io.livekit.android.room.track.VideoTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import livekit.org.webrtc.RendererCommon
import org.json.JSONObject

/*
 * Group calls (3 – 200 people) through the LiveKit meeting server on the VPS.
 * Firestore gcalls/{room}: {room, group, by, title, photo, video, members, ringing, joined, state, created, ringAt}
 *   room = group id ("g_…") for a group's call, or "r_…" for a one-to-one call that grew into a group call.
 */
enum class GPhase { Idle, Ringing, Connecting, Live, Ended }

data class GPerson(
    val id: String, val name: String, val photo: String, val video: VideoTrack?,
    val speaking: Boolean, val micOn: Boolean, val local: Boolean,
)

object GroupCall {
    var phase by mutableStateOf(GPhase.Idle)
    var room by mutableStateOf("")
    var title by mutableStateOf("")
    var photo by mutableStateOf("")
    var caller by mutableStateOf("")
    var video by mutableStateOf(false)
    var muted by mutableStateOf(false)
    var camOn by mutableStateOf(false)
    var speaker by mutableStateOf(true)
    var front by mutableStateOf(true)
    var startedAt by mutableLongStateOf(0L)
    val people = mutableStateListOf<GPerson>()

    lateinit var app: Context
    private var lk: Room? = null
    private val jobs = mutableListOf<Job>()
    private var docReg: ListenerRegistration? = null
    private var timeout: Job? = null
    private val rang = HashMap<String, Long>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private val db get() = FirebaseFirestore.getInstance()
    private fun ref() = db.collection("gcalls").document(room)

    val busy get() = phase != GPhase.Idle && phase != GPhase.Ended

    private fun reset() {
        muted = false; front = true; startedAt = 0L; people.clear(); caller = ""
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(app, p) == PackageManager.PERMISSION_GRANTED

    private fun openScreen() {
        try { app.startActivity(Intent(app, GroupCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------ start / join a group's call
    fun startGroup(ctx: Context, gid: String, isVideo: Boolean) {
        app = ctx.applicationContext
        if (busy) { if (room == gid) openScreen(); return }
        if (CallManager.busy) { toast(ctx, t("c_busy")); return }
        val g = Repo.chats.firstOrNull { it.id == gid } ?: return
        val me = Repo.uid ?: return
        reset()
        room = gid; title = g.name; photo = g.photo; video = isVideo; speaker = true
        phase = GPhase.Connecting
        CallService.start(app)
        openScreen()
        scope.launch {
            try {
                val d = ref().get().await()
                val joined = (d.get("joined") as? List<*>)?.size ?: 0
                val running = d.exists() && d.getString("state") == "live" && joined > 0
                if (running) {
                    video = d.getBoolean("video") ?: isVideo
                    ref().update("members", FieldValue.arrayUnion(*g.members.toTypedArray())).await()
                } else {
                    val others = g.members.filter { it != me }
                    ref().set(mapOf(
                        "room" to gid, "group" to gid, "by" to me, "title" to g.name, "photo" to g.photo, "video" to isVideo,
                        "members" to g.members, "ringing" to others, "joined" to emptyList<String>(), "state" to "live",
                        "created" to FieldValue.serverTimestamp(), "ringAt" to System.currentTimeMillis(),
                    )).await()
                    ring(others)
                }
                connect()
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    /** A one-to-one call grows into a group call: me + peer + the people I picked. Returns the new room id. */
    fun upgrade(ctx: Context, peer: String, add: List<String>, isVideo: Boolean): String {
        app = ctx.applicationContext
        val me = Repo.uid ?: return ""
        reset()
        room = "r_" + db.collection("gcalls").document().id
        title = t("group_call"); photo = ""; video = isVideo; speaker = isVideo
        phase = GPhase.Connecting
        val id = room
        scope.launch {
            try {
                ref().set(mapOf(
                    "room" to id, "group" to "", "by" to me, "title" to "", "photo" to "", "video" to isVideo,
                    "members" to (listOf(me, peer) + add).distinct(), "ringing" to add, "joined" to emptyList<String>(),
                    "state" to "live", "created" to FieldValue.serverTimestamp(), "ringAt" to System.currentTimeMillis(),
                )).await()
                ring(add)
                connect()
            } catch (e: Exception) {
                fail(e)
            }
        }
        CallService.start(app)
        openScreen()
        return id
    }

    /** The other person of a one-to-one call was moved into a group call. */
    fun joinMoved(ctx: Context, roomId: String, isVideo: Boolean) {
        app = ctx.applicationContext
        if (busy) return
        reset()
        room = roomId; title = t("group_call"); photo = ""; video = isVideo; speaker = isVideo
        phase = GPhase.Connecting
        CallService.start(app)
        openScreen()
        scope.launch { try { connect() } catch (e: Exception) { fail(e) } }
    }

    fun invite(add: List<String>) {
        if (add.isEmpty() || room.isEmpty()) return
        scope.launch {
            try {
                ref().update(mapOf(
                    "members" to FieldValue.arrayUnion(*add.toTypedArray()),
                    "ringing" to FieldValue.arrayUnion(*add.toTypedArray()),
                    "ringAt" to System.currentTimeMillis(),
                )).await()
                ring(add)
            } catch (_: Exception) {}
        }
    }

    private suspend fun ring(to: List<String>) {
        if (to.isEmpty()) return
        try { Api.post("/api/gcall/ring", JSONObject().put("room", room).put("to", org.json.JSONArray(to)), auth = true) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------ incoming
    fun onIncoming(ctx: Context, roomId: String, title0: String, photo0: String, by: String, isVideo: Boolean) = main.post {
        app = ctx.applicationContext
        val now = System.currentTimeMillis()
        if ((rang[roomId] ?: 0L) > now - 60_000) return@post
        rang[roomId] = now
        if (busy || CallManager.busy) return@post
        reset()
        room = roomId; title = title0.ifBlank { by }; photo = photo0; caller = by; video = isVideo; speaker = isVideo
        phase = GPhase.Ringing
        Prefs.init(app)
        Sounds.startRing(app)
        CallService.start(app)
        docReg = ref().addSnapshotListener { d, _ ->
            if (d == null) return@addSnapshotListener
            val me = Repo.uid ?: ""
            val stillRinging = (d.get("ringing") as? List<*>)?.contains(me) == true
            if (phase == GPhase.Ringing && (d.getString("state") != "live" || !stillRinging)) finish()
        }
        timeout = scope.launch { delay(45_000); if (phase == GPhase.Ringing) decline() }
    }

    fun accept() {
        if (phase != GPhase.Ringing) return
        Sounds.stopRing()
        timeout?.cancel()
        docReg?.remove(); docReg = null
        phase = GPhase.Connecting
        CallService.start(app)
        scope.launch { try { connect() } catch (e: Exception) { fail(e) } }
    }

    fun decline() {
        if (phase != GPhase.Ringing) return
        val me = Repo.uid ?: ""
        ref().update("ringing", FieldValue.arrayRemove(me))
        finish()
    }

    // ------------------------------------------------------------ media
    private suspend fun connect() {
        val me = Repo.uid ?: throw IllegalStateException("login")
        val j = Api.post("/api/lk/join", JSONObject().put("room", room), auth = true)
        val r = LiveKit.create(app, RoomOptions(adaptiveStream = true, dynacast = true))
        lk = r
        jobs += scope.launch {
            r.events.collect { e ->
                refresh()
                if (e is RoomEvent.Disconnected && (phase == GPhase.Live || phase == GPhase.Connecting)) leave()
            }
        }
        r.connect(j.getString("url"), j.getString("token"))
        r.localParticipant.setMicrophoneEnabled(!muted)
        if (video && granted(Manifest.permission.CAMERA)) {
            r.localParticipant.setCameraEnabled(true); camOn = true
        } else camOn = false
        phase = GPhase.Live
        startedAt = System.currentTimeMillis()
        CallService.start(app)
        applySpeaker()
        ref().update(mapOf("joined" to FieldValue.arrayUnion(me), "ringing" to FieldValue.arrayRemove(me)))
        jobs += scope.launch { while (true) { refresh(); delay(700) } }
    }

    private fun person(p: Participant, local: Boolean): GPerson {
        val id = p.identity?.value ?: ""
        val u = Repo.user(id)
        val pub = p.getTrackPublication(Track.Source.CAMERA)
        val track = if (pub != null && !pub.muted) pub.track as? VideoTrack else null
        return GPerson(id, if (local) t("you") else (u?.shown ?: p.name ?: "…"), u?.photo ?: "", track,
            p.isSpeaking, p.isMicrophoneEnabled, local)
    }

    private fun refresh() {
        val r = lk ?: return
        val list = ArrayList<GPerson>()
        try {
            list.add(person(r.localParticipant, true))
            r.remoteParticipants.values.forEach { list.add(person(it, false)) }
        } catch (_: Exception) {}
        // speakers first, then the rest
        val sorted = list.sortedWith(compareBy({ !it.local && !it.speaking }, { it.local }))
        if (sorted != people.toList()) { people.clear(); people.addAll(sorted) }
    }

    fun renderer(v: TextureViewRenderer) { lk?.initVideoRenderer(v) }

    fun toggleMute() {
        muted = !muted
        scope.launch { try { lk?.localParticipant?.setMicrophoneEnabled(!muted) } catch (_: Exception) {} }
    }

    fun toggleCam() {
        if (!granted(Manifest.permission.CAMERA)) { toast(app, t("cam_need")); return }
        camOn = !camOn
        scope.launch { try { lk?.localParticipant?.setCameraEnabled(camOn) } catch (_: Exception) {} }
    }

    fun flip() {
        val tr = lk?.localParticipant?.getTrackPublication(Track.Source.CAMERA)?.track as? LocalVideoTrack ?: return
        front = !front
        try { tr.switchCamera(position = if (front) CameraPosition.FRONT else CameraPosition.BACK) } catch (_: Exception) {}
    }

    fun toggleSpeaker() { speaker = !speaker; applySpeaker() }

    private fun applySpeaker() {
        try {
            val a = app.getSystemService(AudioManager::class.java)
            if (Build.VERSION.SDK_INT >= 31) {
                val want = if (speaker) AudioDeviceInfo.TYPE_BUILTIN_SPEAKER else AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                a.availableCommunicationDevices.firstOrNull { it.type == want }?.let { a.setCommunicationDevice(it) }
            } else {
                @Suppress("DEPRECATION")
                a.isSpeakerphoneOn = speaker
            }
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------ end
    fun leave() {
        if (!busy) return
        if (phase == GPhase.Ringing) { decline(); return }
        val me = Repo.uid ?: ""
        val id = room
        if (id.isNotEmpty()) {
            val r = db.collection("gcalls").document(id)
            r.update("joined", FieldValue.arrayRemove(me)).addOnCompleteListener {
                r.get().addOnSuccessListener { d ->
                    if ((d.get("joined") as? List<*>).isNullOrEmpty()) r.update(mapOf("state" to "ended", "ringing" to emptyList<String>()))
                }
            }
        }
        finish()
    }

    private fun fail(e: Exception) {
        try { toast(app, if (e is ApiError) errText(e) else t("c_failed")) } catch (_: Exception) {}
        finish()
    }

    private fun finish() {
        if (!busy) return
        Sounds.stopRing()
        timeout?.cancel()
        docReg?.remove(); docReg = null
        val old = lk
        lk = null
        jobs.forEach { it.cancel() }; jobs.clear()
        people.clear()
        phase = GPhase.Ended
        scope.launch {
            delay(300)
            try { old?.disconnect() } catch (_: Exception) {}
            try { old?.release() } catch (_: Exception) {}
        }
        try {
            val a = app.getSystemService(AudioManager::class.java)
            if (Build.VERSION.SDK_INT >= 31) a.clearCommunicationDevice()
            a.mode = AudioManager.MODE_NORMAL
        } catch (_: Exception) {}
        CallService.stop(app)
        scope.launch { delay(1500); if (phase == GPhase.Ended) phase = GPhase.Idle }
    }
}

// ---------------------------------------------------------------- start a group's call (asks for the microphone first)
@Composable
fun rememberGroupCaller(gid: String): (Boolean) -> Unit {
    val ctx = LocalContext.current
    val wantVideo = remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val mic = r[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!mic) Toast.makeText(ctx, t("mic_need_call"), Toast.LENGTH_LONG).show()
        else GroupCall.startGroup(ctx, gid, wantVideo.value)
    }
    return { v ->
        wantVideo.value = v
        launcher.launch(if (v) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA) else arrayOf(Manifest.permission.RECORD_AUDIO))
    }
}

// ---------------------------------------------------------------- pick friends to add to a call
@Composable
fun AddToCallDialog(exclude: Collection<String>, onCancel: () -> Unit, onAdd: (List<String>) -> Unit) {
    val me = Repo.uid
    val friends = Repo.chats.filter { !it.group }.mapNotNull { Repo.user(it.other) }
        .filter { it.uid != me && it.uid !in exclude && it.name.isNotBlank() }.distinctBy { it.uid }.sortedBy { it.shown.lowercase() }
    val picked = remember { mutableStateListOf<String>() }
    Dialog(onDismissRequest = onCancel) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(P.card).padding(vertical = 14.dp)) {
            Text(t("add_to_call"), color = P.tx, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            if (friends.isEmpty()) Text(t("g_no_friends"), color = P.tx2, fontSize = 14.sp, modifier = Modifier.padding(20.dp))
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 380.dp)) {
                items(friends, key = { it.uid }) { u ->
                    val on = u.uid in picked
                    Row(Modifier.fillMaxWidth().clickable { if (on) picked.remove(u.uid) else picked.add(u.uid) }.padding(horizontal = 18.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Avatar(u.shown, u.photo, u.uid, 42.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(u.shown, color = P.tx, fontSize = 15.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Box(Modifier.size(24.dp).clip(CircleShape).background(if (on) Brand else Color.Transparent)
                            .border(2.dp, if (on) Brand else P.tx2, CircleShape), contentAlignment = Alignment.Center) {
                            if (on) Ic("check", Color.White, 16.dp)
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), horizontalArrangement = Arrangement.End) {
                Text(t("cancel"), color = Brand, fontWeight = FontWeight.Bold, modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { onCancel() }.padding(12.dp))
                Spacer(Modifier.width(6.dp))
                Text(t("add_call_btn") + if (picked.isNotEmpty()) " (" + num("${picked.size}") + ")" else "", color = Color.White, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(if (picked.isEmpty()) P.ln else Brand)
                        .clickable(enabled = picked.isNotEmpty()) { onAdd(picked.toList()) }.padding(horizontal = 16.dp, vertical = 12.dp))
            }
        }
    }
}

// ---------------------------------------------------------------- the group call screen
class GroupCallActivity : ComponentActivity() {
    private val answerNow = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()
        answerNow.value = intent?.action == "answer"
        if (!GroupCall.busy) { finish(); return }
        setContent { GroupCallUi(answerNow) { finish() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == "answer") answerNow.value = true
    }
}

@Composable
private fun GroupCallUi(answerNow: MutableState<Boolean>, close: () -> Unit) {
    val ctx = LocalContext.current
    val g = GroupCall
    val ph = g.phase
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var adding by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    LaunchedEffect(ph) {
        if (ph == GPhase.Idle) close()
        if (ph == GPhase.Ended) { delay(1200); close() }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val mic = r[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (mic) g.accept() else Toast.makeText(ctx, t("mic_need_call"), Toast.LENGTH_LONG).show()
    }
    fun accept() = perm.launch(if (g.video) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA) else arrayOf(Manifest.permission.RECORD_AUDIO))
    LaunchedEffect(answerNow.value) { if (answerNow.value && g.phase == GPhase.Ringing) { answerNow.value = false; accept() } }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1D1640), Color(0xFF2B1F6B), Color(0xFF0F3B3A))))) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            // ---- top
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp)) {
                Text(g.title.ifBlank { t("group_call") }, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val st = when (ph) {
                    GPhase.Ringing -> (if (g.caller.isNotBlank()) g.caller + " · " else "") + t(if (g.video) "in_gvideo" else "in_gaudio")
                    GPhase.Connecting -> t("connecting")
                    GPhase.Live -> {
                        val s = ((now - g.startedAt) / 1000).coerceAtLeast(0)
                        num("%02d:%02d".format(s / 60, s % 60)) + " · " + num("${g.people.size}") + " " + t("g_in_call")
                    }
                    GPhase.Ended -> t("c_ended")
                    GPhase.Idle -> ""
                }
                Text(st, color = Color.White.copy(alpha = .8f), fontSize = 14.sp)
            }
            // ---- people
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (ph == GPhase.Ringing || g.people.isEmpty()) {
                    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        GroupAvatar(g.title.ifBlank { "?" }, g.photo, g.room, 130.dp)
                    }
                } else {
                    BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
                        val n = g.people.size
                        val cols = when { n <= 1 -> 1; n <= 4 -> 2; else -> 3 }
                        val rows = (n + cols - 1) / cols
                        val tileH = if (n <= 6) (maxHeight / rows) - 8.dp else 170.dp
                        LazyVerticalGrid(GridCells.Fixed(if (n == 2) 1 else cols), Modifier.fillMaxSize()) {
                            itemsIndexed(g.people, key = { _, p -> p.id }) { i, p ->
                                val h = if (n == 2) (maxHeight / 2) - 8.dp else tileH
                                Tile(p, i < 12, Modifier.padding(4.dp).fillMaxWidth().height(h))
                            }
                        }
                    }
                }
            }
            // ---- buttons
            if (ph == GPhase.Ringing) {
                Row(Modifier.fillMaxWidth().padding(vertical = 34.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    CallRound("call_end", Red, t("decline")) { g.decline() }
                    CallRound(if (g.video) "video" else "call", Green, t("accept")) { accept() }
                }
            } else if (ph != GPhase.Ended) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    SmallToggle(if (g.muted) "mic_off" else "mic", g.muted) { g.toggleMute() }
                    SmallToggle("volume", g.speaker) { g.toggleSpeaker() }
                    SmallToggle(if (g.camOn) "video" else "video_off", !g.camOn) { g.toggleCam() }
                    if (g.camOn) SmallToggle("flip", false) { g.flip() }
                    SmallToggle("person_add", false) { adding = true }
                    Box(Modifier.size(56.dp).clip(CircleShape).background(Red).clickable { g.leave() }, contentAlignment = Alignment.Center) {
                        Ic("call_end", Color.White, 26.dp)
                    }
                }
            }
        }
    }
    if (adding) AddToCallDialog(g.people.map { it.id }, onCancel = { adding = false }) { list -> g.invite(list); adding = false; toast(ctx, t("calling")) }
}

@Composable
private fun Tile(p: GPerson, allowVideo: Boolean, modifier: Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xFF15122A))
            .border(if (p.speaking) 3.dp else 1.dp, if (p.speaking) Mint else Color.White.copy(alpha = .12f), RoundedCornerShape(18.dp))
    ) {
        val v = p.video
        if (v != null && allowVideo) {
            key(v) { LkVideo(v, mirror = p.local && GroupCall.front, modifier = Modifier.fillMaxSize()) }
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Avatar(p.name.ifBlank { "?" }, p.photo, p.id, 72.dp) }
        }
        Row(
            Modifier.align(Alignment.BottomStart).padding(8.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(alpha = .45f))
                .padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!p.micOn) { Ic("mic_off", Red, 14.dp); Spacer(Modifier.width(4.dp)) }
            Text(p.name, color = Color.White, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun LkVideo(track: VideoTrack, mirror: Boolean, modifier: Modifier) {
    val holder = remember { arrayOfNulls<TextureViewRenderer>(1) }
    AndroidView(
        factory = { c ->
            TextureViewRenderer(c).also { r ->
                GroupCall.renderer(r)
                r.setMirror(mirror)
                try { r.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL) } catch (_: Exception) {}
                try { track.addRenderer(r) } catch (_: Exception) {}
                holder[0] = r
            }
        },
        update = { it.setMirror(mirror) },
        modifier = modifier,
    )
    DisposableEffect(track) {
        onDispose {
            holder[0]?.let { r ->
                try { track.removeRenderer(r) } catch (_: Exception) {}
                try { r.release() } catch (_: Exception) {}
            }
        }
    }
}

@Composable
private fun CallRound(icon: String, color: Color, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(70.dp).clip(CircleShape).background(color).clickable { onClick() }, contentAlignment = Alignment.Center) {
            Ic(icon, Color.White, 32.dp)
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
private fun SmallToggle(icon: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(50.dp).clip(CircleShape).background(if (on) Color.White else Color.White.copy(alpha = .16f)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Ic(icon, if (on) Color(0xFF1D1640) else Color.White, 23.dp) }
}
