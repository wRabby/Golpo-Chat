package com.mobiletips.golpo

import android.Manifest
import android.media.projection.MediaProjectionManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import io.livekit.android.LiveKit
import io.livekit.android.RoomOptions
import io.livekit.android.events.RoomEvent
import io.livekit.android.events.collect
import io.livekit.android.renderer.TextureViewRenderer
import io.livekit.android.room.Room
import io.livekit.android.room.participant.Participant
import io.livekit.android.room.track.CameraPosition
import io.livekit.android.room.track.LocalVideoTrack
import io.livekit.android.room.track.Track
import io.livekit.android.room.track.VideoTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import livekit.org.webrtc.RendererCommon
import org.json.JSONObject

/*
 * Group calls (3 – 200 people) through the LiveKit meeting server on the VPS.
 * Firestore gcalls/{room}: {room, group, by, title, photo, video, members, ringing, joined, state, created, ringAt}
 *   room = group id ("g_…") for a group's call, or "r_…" for a one-to-one call that grew into a group call.
 */
enum class GPhase { Idle, Ringing, Connecting, Live, Ended }

data class GPerson(
    val id: String, val name: String, val photo: String, val video: VideoTrack?,
    val speaking: Boolean, val micOn: Boolean, val local: Boolean, val screen: VideoTrack? = null,
) {
    /** what to show on the tile: a shared screen beats the camera */
    val shown: VideoTrack? get() = screen ?: video
}

object GroupCall {
    var phase by mutableStateOf(GPhase.Idle)
    var room by mutableStateOf("")
    var title by mutableStateOf("")
    var photo by mutableStateOf("")
    var caller by mutableStateOf("")
    var video by mutableStateOf(false)
    var muted by mutableStateOf(false)
    var camOn by mutableStateOf(false)
    var speaker by mutableStateOf(true)
    var front by mutableStateOf(true)
    var startedAt by mutableLongStateOf(0L)
    var sharing by mutableStateOf(false)
    val people = mutableStateListOf<GPerson>()
    /** screen-share permission waiting for the room (a one-to-one call moving here to share) */
    var pendingShare: Intent? = null
    private val order = ArrayList<String>()          // tiles stay where they first appeared
    private var known = HashSet<String>()
    private var quietUntil = 0L

    lateinit var app: Context
    private var lk: Room? = null
    private val jobs = mutableListOf<Job>()
    private var docReg: ListenerRegistration? = null
    private var timeout: Job? = null
    private val rang = HashMap<String, Long>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private val db get() = FirebaseFirestore.getInstance()
    private fun ref() = db.collection("gcalls").document(room)

    val busy get() = phase != GPhase.Idle && phase != GPhase.Ended

    private fun reset() {
        muted = false; front = true; startedAt = 0L; people.clear(); caller = ""; sharing = false
        order.clear(); known.clear()
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(app, p) == PackageManager.PERMISSION_GRANTED

    private fun openScreen() {
        try { app.startActivity(Intent(app, GroupCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------ start / join a group's call
    fun startGroup(ctx: Context, gid: String, isVideo: Boolean) {
        app = ctx.applicationContext
        if (busy) { if (room == gid) openScreen(); return }
        if (CallManager.busy) { toast(ctx, t("c_busy")); return }
        val g = Repo.chats.firstOrNull { it.id == gid } ?: return
        val me = Repo.uid ?: return
        reset()
        room = gid; title = g.name; photo = g.photo; video = isVideo; speaker = true
        phase = GPhase.Connecting
        CallService.start(app)
        openScreen()
        scope.launch {
            try {
                val d = ref().get().await()
                val joined = (d.get("joined") as? List<*>)?.size ?: 0
                val running = d.exists() && d.getString("state") == "live" && joined > 0
                if (running) {
                    video = d.getBoolean("video") ?: isVideo
                    ref().update("members", FieldValue.arrayUnion(*g.members.toTypedArray())).await()
                } else {
                    val others = g.members.filter { it != me }
                    ref().set(mapOf(
                        "room" to gid, "group" to gid, "by" to me, "title" to g.name, "photo" to g.photo, "video" to isVideo,
                        "members" to g.members, "ringing" to others, "joined" to emptyList<String>(), "state" to "live",
                        "created" to FieldValue.serverTimestamp(), "ringAt" to System.currentTimeMillis(),
                    )).await()
                    ring(others)
                }
                connect()
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    /** A one-to-one call grows into a group call: me + peer + the people I picked. Returns the new room id. */
    fun upgrade(ctx: Context, peer: String, add: List<String>, isVideo: Boolean, title0: String = ""): String {
        app = ctx.applicationContext
        val me = Repo.uid ?: return ""
        reset()
        room = "r_" + db.collection("gcalls").document().id
        title = title0.ifBlank { t("group_call") }; photo = ""; video = isVideo; speaker = isVideo
        phase = GPhase.Connecting
        val id = room
        scope.launch {
            try {
                ref().set(mapOf(
                    "room" to id, "group" to "", "by" to me, "title" to "", "photo" to "", "video" to isVideo,
                    "members" to (listOf(me, peer) + add).distinct(), "ringing" to add, "joined" to emptyList<String>(),
                    "state" to "live", "created" to FieldValue.serverTimestamp(), "ringAt" to System.currentTimeMillis(),
                )).await()
                ring(add)
                connect()
            } catch (e: Exception) {
                fail(e)
            }
        }
        CallService.start(app)
        openScreen()
        return id
    }

    /** The other person of a one-to-one call was moved into a group call. */
    fun joinMoved(ctx: Context, roomId: String, isVideo: Boolean, title0: String = "") {
        app = ctx.applicationContext
        if (busy) return
        reset()
        room = roomId; title = title0.ifBlank { t("group_call") }; photo = ""; video = isVideo; speaker = isVideo
        phase = GPhase.Connecting
        CallService.start(app)
        openScreen()
        scope.launch { try { connect() } catch (e: Exception) { fail(e) } }
    }

    /** Join a call that is still going on (after leaving it, or one I never picked up). */
    fun rejoin(ctx: Context, roomId: String, title0: String, isVideo: Boolean) {
        app = ctx.applicationContext
        if (busy) { if (room == roomId) openScreen(); return }
        if (CallManager.busy) { toast(ctx, t("c_busy")); return }
        reset()
        room = roomId; title = title0; photo = Repo.chats.firstOrNull { it.id == roomId }?.photo ?: ""; video = isVideo; speaker = true
        phase = GPhase.Connecting
        CallService.start(app)
        openScreen()
        scope.launch { try { connect() } catch (e: Exception) { fail(e) } }
    }

    fun invite(add: List<String>) {
        if (add.isEmpty() || room.isEmpty()) return
        scope.launch {
            try {
                ref().update(mapOf(
                    "members" to FieldValue.arrayUnion(*add.toTypedArray()),
                    "ringing" to FieldValue.arrayUnion(*add.toTypedArray()),
                    "ringAt" to System.currentTimeMillis(),
                )).await()
                ring(add)
            } catch (_: Exception) {}
        }
    }

    private suspend fun ring(to: List<String>) {
        if (to.isEmpty()) return
        try { Api.post("/api/gcall/ring", JSONObject().put("room", room).put("to", org.json.JSONArray(to)), auth = true) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------ incoming
    fun onIncoming(ctx: Context, roomId: String, title0: String, photo0: String, by: String, isVideo: Boolean) = main.post {
        app = ctx.applicationContext
        val now = System.currentTimeMillis()
        if ((rang[roomId] ?: 0L) > now - 60_000) return@post
        rang[roomId] = now
        if (busy || CallManager.busy) return@post
        reset()
        room = roomId; title = title0.ifBlank { by }; photo = photo0; caller = by; video = isVideo; speaker = isVideo
        phase = GPhase.Ringing
        Prefs.init(app)
        CallService.start(app)
        Ringer.start(app)
        docReg = ref().addSnapshotListener { d, _ ->
            if (d == null) return@addSnapshotListener
            val me = Repo.uid ?: ""
            val stillRinging = (d.get("ringing") as? List<*>)?.contains(me) == true
            if (phase == GPhase.Ringing && (d.getString("state") != "live" || !stillRinging)) finish()
        }
        timeout = scope.launch { delay(45_000); if (phase == GPhase.Ringing) decline() }
    }

    fun accept() {
        if (phase != GPhase.Ringing) return
        Ringer.stop(app)
        timeout?.cancel()
        docReg?.remove(); docReg = null
        phase = GPhase.Connecting
        CallService.start(app)
        scope.launch { try { connect() } catch (e: Exception) { fail(e) } }
    }

    fun decline() {
        if (phase != GPhase.Ringing) return
        val me = Repo.uid ?: ""
        ref().update("ringing", FieldValue.arrayRemove(me))
        finish()
    }

    // ------------------------------------------------------------ media
    private suspend fun connect() {
        val me = Repo.uid ?: throw IllegalStateException("login")
        val j = Api.post("/api/lk/join", JSONObject().put("room", room), auth = true)
        val r = LiveKit.create(app, RoomOptions(adaptiveStream = true, dynacast = true))
        lk = r
        jobs += scope.launch {
            r.events.collect { e ->
                refresh()
                if (e is RoomEvent.Disconnected && (phase == GPhase.Live || phase == GPhase.Connecting)) leave()
            }
        }
        r.connect(j.getString("url"), j.getString("token"))
        r.localParticipant.setMicrophoneEnabled(!muted)
        if (video && granted(Manifest.permission.CAMERA)) {
            r.localParticipant.setCameraEnabled(true); camOn = true
        } else camOn = false
        phase = GPhase.Live
        startedAt = System.currentTimeMillis()
        quietUntil = startedAt + 2500                    // no join sounds for people who were already here
        CallService.start(app)
        applySpeaker()
        ref().update(mapOf("joined" to FieldValue.arrayUnion(me), "ringing" to FieldValue.arrayRemove(me),
            "state" to "live", "beat" to System.currentTimeMillis()))
        jobs += scope.launch { while (true) { refresh(); delay(700) } }
        // heartbeat: tells everyone the call is really still on (for "Call in progress · Join")
        jobs += scope.launch {
            while (true) {
                delay(60_000)
                try { ref().update(mapOf("beat" to System.currentTimeMillis(), "joined" to FieldValue.arrayUnion(me))) } catch (_: Exception) {}
            }
        }
        pendingShare?.let { d -> pendingShare = null; startShare(d) }
    }

    private fun person(p: Participant, local: Boolean): GPerson {
        val id = p.identity?.value ?: ""
        val u = Repo.user(id)
        val pub = p.getTrackPublication(Track.Source.CAMERA)
        val track = if (pub != null && !pub.muted) pub.track as? VideoTrack else null
        val sp = if (local) null else p.getTrackPublication(Track.Source.SCREEN_SHARE)
        val scr = if (sp != null && !sp.muted) sp.track as? VideoTrack else null
        return GPerson(id, if (local) t("you") else (u?.shown ?: p.name ?: "…"), u?.photo ?: "", track,
            p.isSpeaking, p.isMicrophoneEnabled, local, scr)
    }

    private fun refresh() {
        val r = lk ?: return
        val list = ArrayList<GPerson>()
        try {
            list.add(person(r.localParticipant, true))
            r.remoteParticipants.values.forEach { list.add(person(it, false)) }
        } catch (_: Exception) {}
        // tiles never jump around: everyone keeps the place where they first appeared
        val ids = list.map { it.id }
        ids.forEach { if (it !in order) order.add(it) }
        order.retainAll(ids.toSet())
        val sorted = list.sortedBy { order.indexOf(it.id) }
        if (sorted != people.toList()) { people.clear(); people.addAll(sorted) }
        // a sound for everyone when somebody joins or leaves
        val others = list.filter { !it.local }.map { it.id }.toHashSet()
        if (System.currentTimeMillis() > quietUntil) {
            if ((others - known).isNotEmpty()) Sounds.callBlip(app, true)
            else if ((known - others).isNotEmpty()) Sounds.callBlip(app, false)
        }
        known = others
    }

    // ------------------------------------------------------------ share my screen
    fun startShare(data: Intent) {
        val r = lk
        if (r == null) { pendingShare = data; return }
        scope.launch {
            try {
                r.localParticipant.setScreenShareEnabled(true, io.livekit.android.room.track.screencapture.ScreenCaptureParams(data))
                sharing = true
            } catch (_: Exception) {
                sharing = false
                try { toast(app, t("share_fail")) } catch (_: Exception) {}
            }
        }
    }

    fun stopShare() {
        sharing = false
        scope.launch { try { lk?.localParticipant?.setScreenShareEnabled(false, null as io.livekit.android.room.track.screencapture.ScreenCaptureParams?) } catch (_: Exception) {} }
    }

    fun renderer(v: TextureViewRenderer) { lk?.initVideoRenderer(v) }

    fun toggleMute() {
        muted = !muted
        scope.launch { try { lk?.localParticipant?.setMicrophoneEnabled(!muted) } catch (_: Exception) {} }
    }

    fun toggleCam() {
        if (!granted(Manifest.permission.CAMERA)) { toast(app, t("cam_need")); return }
        camOn = !camOn
        scope.launch { try { lk?.localParticipant?.setCameraEnabled(camOn) } catch (_: Exception) {} }
    }

    fun flip() {
        val tr = lk?.localParticipant?.getTrackPublication(Track.Source.CAMERA)?.track as? LocalVideoTrack ?: return
        front = !front
        try { tr.switchCamera(position = if (front) CameraPosition.FRONT else CameraPosition.BACK) } catch (_: Exception) {}
    }

    fun toggleSpeaker() { speaker = !speaker; applySpeaker() }

    private fun applySpeaker() {
        try {
            val a = app.getSystemService(AudioManager::class.java)
            if (Build.VERSION.SDK_INT >= 31) {
                val want = if (speaker) AudioDeviceInfo.TYPE_BUILTIN_SPEAKER else AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                a.availableCommunicationDevices.firstOrNull { it.type == want }?.let { a.setCommunicationDevice(it) }
            } else {
                @Suppress("DEPRECATION")
                a.isSpeakerphoneOn = speaker
            }
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------ end
    fun leave() {
        if (!busy) return
        if (phase == GPhase.Ringing) { decline(); return }
        val me = Repo.uid ?: ""
        val id = room
        if (id.isNotEmpty()) {
            val r = db.collection("gcalls").document(id)
            r.update("joined", FieldValue.arrayRemove(me)).addOnCompleteListener {
                r.get().addOnSuccessListener { d ->
                    if ((d.get("joined") as? List<*>).isNullOrEmpty()) r.update(mapOf("state" to "ended", "ringing" to emptyList<String>()))
                }
            }
        }
        finish()
    }

    private fun fail(e: Exception) {
        try { toast(app, if (e is ApiError) errText(e) else t("c_failed")) } catch (_: Exception) {}
        finish()
    }

    private fun finish() {
        if (!busy) return
        Ringer.stop(app)
        timeout?.cancel()
        docReg?.remove(); docReg = null
        val old = lk
        lk = null
        jobs.forEach { it.cancel() }; jobs.clear()
        people.clear(); sharing = false; pendingShare = null
        phase = GPhase.Ended
        scope.launch {
            delay(300)
            try { old?.disconnect() } catch (_: Exception) {}
            try { old?.release() } catch (_: Exception) {}
        }
        try {
            val a = app.getSystemService(AudioManager::class.java)
            if (Build.VERSION.SDK_INT >= 31) a.clearCommunicationDevice()
            a.mode = AudioManager.MODE_NORMAL
        } catch (_: Exception) {}
        CallService.stop(app)
        scope.launch { delay(1500); if (phase == GPhase.Ended) phase = GPhase.Idle }
    }
}

// ---------------------------------------------------------------- start a group's call (asks for the microphone first)
@Composable
fun rememberGroupCaller(gid: String): (Boolean) -> Unit {
    val ctx = LocalContext.current
    val wantVideo = remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val mic = r[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!mic) Toast.makeText(ctx, t("mic_need_call"), Toast.LENGTH_LONG).show()
        else GroupCall.startGroup(ctx, gid, wantVideo.value)
    }
    return { v ->
        wantVideo.value = v
        launcher.launch(if (v) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA) else arrayOf(Manifest.permission.RECORD_AUDIO))
    }
}

// ---------------------------------------------------------------- pick friends to add to a call
@Composable
fun AddToCallDialog(exclude: Collection<String>, onCancel: () -> Unit, onAdd: (List<String>) -> Unit) {
    val me = Repo.uid
    val friends = Repo.chats.filter { !it.group }.mapNotNull { Repo.user(it.other) }
        .filter { it.uid != me && it.uid !in exclude && it.name.isNotBlank() }.distinctBy { it.uid }.sortedBy { it.shown.lowercase() }
    val picked = remember { mutableStateListOf<String>() }
    Dialog(onDismissRequest = onCancel) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(P.card).padding(vertical = 14.dp)) {
            Text(t("add_to_call"), color = P.tx, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            if (friends.isEmpty()) Text(t("g_no_friends"), color = P.tx2, fontSize = 14.sp, modifier = Modifier.padding(20.dp))
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 380.dp)) {
                items(friends, key = { it.uid }) { u ->
                    val on = u.uid in picked
                    Row(Modifier.fillMaxWidth().clickable { if (on) picked.remove(u.uid) else picked.add(u.uid) }.padding(horizontal = 18.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Avatar(u.shown, u.photo, u.uid, 42.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(u.shown, color = P.tx, fontSize = 15.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Box(Modifier.size(24.dp).clip(CircleShape).background(if (on) Brand else Color.Transparent)
                            .border(2.dp, if (on) Brand else P.tx2, CircleShape), contentAlignment = Alignment.Center) {
                            if (on) Ic("check", Color.White, 16.dp)
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), horizontalArrangement = Arrangement.End) {
                Text(t("cancel"), color = Brand, fontWeight = FontWeight.Bold, modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { onCancel() }.padding(12.dp))
                Spacer(Modifier.width(6.dp))
                Text(t("add_call_btn") + if (picked.isNotEmpty()) " (" + num("${picked.size}") + ")" else "", color = Color.White, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(if (picked.isEmpty()) P.ln else Brand)
                        .clickable(enabled = picked.isNotEmpty()) { onAdd(picked.toList()) }.padding(horizontal = 16.dp, vertical = 12.dp))
            }
        }
    }
}

// ---------------------------------------------------------------- the group call screen
class GroupCallActivity : ComponentActivity() {
    private val answerNow = mutableStateOf(false)
    private val inPip = mutableStateOf(false)
    private var leaving = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()
        answerNow.value = intent?.action == "answer"
        if (!GroupCall.busy) { finish(); return }
        addOnPictureInPictureModeChangedListener { inPip.value = it.isInPictureInPictureMode }
        setContent { GroupCallUi(answerNow, inPip.value, minimize = { minimize() }) { finish() } }
    }

    private fun minimize() { leaving = true; openApp(this); finish() }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!leaving && Build.VERSION.SDK_INT in 26..30 && callLive()) Pip.enter(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == "answer") answerNow.value = true
    }
}

@Composable
private fun GroupCallUi(answerNow: MutableState<Boolean>, inPip: Boolean, minimize: () -> Unit, close: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx as? android.app.Activity
    val g = GroupCall
    val ph = g.phase
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var adding by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    var listing by remember { mutableStateOf(false) }
    var focus by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    LaunchedEffect(ph) {
        if (act != null) Pip.auto(act, ph == GPhase.Live || ph == GPhase.Connecting)
        if (ph == GPhase.Idle) close()
        if (ph == GPhase.Ended) { delay(1200); close() }
    }
    BackHandler(!inPip) { if (focus != null) focus = null else if (ph == GPhase.Ringing) g.decline() else minimize() }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val mic = r[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (mic) g.accept() else Toast.makeText(ctx, t("mic_need_call"), Toast.LENGTH_LONG).show()
    }
    fun accept() = perm.launch(if (g.video) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA) else arrayOf(Manifest.permission.RECORD_AUDIO))
    LaunchedEffect(answerNow.value) { if (answerNow.value && g.phase == GPhase.Ringing) { answerNow.value = false; accept() } }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) g.toggleCam() else toast(ctx, t("cam_need"))
    }
    val proj = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == android.app.Activity.RESULT_OK && d != null) g.startShare(d)
    }
    fun share() {
        if (g.sharing) { g.stopShare(); return }
        try {
            val mpm = ctx.getSystemService(MediaProjectionManager::class.java)
            proj.launch(mpm.createScreenCaptureIntent())
        } catch (_: Exception) { toast(ctx, t("share_fail")) }
    }
    fun video() {
        if (!g.camOn && ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            camPerm.launch(Manifest.permission.CAMERA)
        else g.toggleCam()
    }

    Box(Modifier.fillMaxSize().background(CallBg)) {
        if (inPip) { GroupPipContent(now); return@Box }
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            val st = when (ph) {
                GPhase.Ringing -> (if (g.caller.isNotBlank()) g.caller + " · " else "") + t(if (g.video) "in_gvideo" else "in_gaudio")
                GPhase.Connecting -> t("connecting")
                GPhase.Live -> callClock(g.startedAt, now) + " · " + num("${g.people.size}") + " " + t("g_in_call")
                GPhase.Ended -> t("c_ended")
                GPhase.Idle -> ""
            }
            CallTop(g.title.ifBlank { t("group_call") }, st, onMin = minimize, onAdd = if (ph == GPhase.Live) ({ adding = true }) else null)
            // ---- people (each tile keeps its place; only the speaker's border lights up)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (ph == GPhase.Ringing || g.people.isEmpty()) {
                    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        GroupAvatar(g.title.ifBlank { "?" }, g.photo, g.room, 130.dp)
                    }
                } else {
                    BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
                        val n = g.people.size
                        val cols = when { n <= 2 -> 1; n <= 6 -> 2; else -> 3 }
                        val rows = (n + cols - 1) / cols
                        val tileH = if (n <= 6) (maxHeight / rows) - 8.dp else 170.dp
                        LazyVerticalGrid(GridCells.Fixed(cols), Modifier.fillMaxSize()) {
                            itemsIndexed(g.people, key = { _, p -> p.id }) { i, p ->
                                Tile(p, i < 12, Modifier.padding(4.dp).fillMaxWidth().height(tileH)) { focus = p.id }
                            }
                        }
                    }
                }
            }
            // ---- buttons
            if (ph == GPhase.Ringing) {
                AnswerRow(g.video, onDecline = { g.decline() }, onAccept = { accept() })
            } else if (ph != GPhase.Ended) {
                CallPanel(
                    speaker = g.speaker, videoOn = g.camOn, muted = g.muted, sharing = g.sharing,
                    onSpeaker = { g.toggleSpeaker() }, onVideo = { video() }, onMute = { g.toggleMute() },
                    onMore = { more = true }, onShare = { share() }, onEnd = { g.leave() },
                )
            } else Spacer(Modifier.height(120.dp))
        }
        // ---- one person full screen: pinch to zoom, "Shrink" button on top
        val f = focus?.let { id -> g.people.firstOrNull { it.id == id } }
        if (f != null) FocusView(f) { focus = null }
        else if (focus != null) LaunchedEffect(focus) { focus = null }
    }
    if (more) BottomSheet(onDismiss = { more = false }, dark = true) {
        if (g.camOn) SheetRow("flip", t("flip_camera"), dark = true) { more = false; g.flip() }
        SheetRow("group", t("in_call_list") + " (" + num("${g.people.size}") + ")", dark = true) { more = false; listing = true }
        SheetRow("person_add", t("add_people"), dark = true) { more = false; adding = true }
    }
    if (listing) BottomSheet(onDismiss = { listing = false }, dark = true) {
        Text(t("in_call_list"), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
            items(g.people, key = { it.id }) { p ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(p.name.ifBlank { "?" }, p.photo, p.id, 42.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(p.name, color = Color.White, fontSize = 15.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    if (p.screen != null) { Ic("screen_share", Mint, 20.dp); Spacer(Modifier.width(8.dp)) }
                    if (p.video != null) { Ic("video", Color.White.copy(alpha = .8f), 20.dp); Spacer(Modifier.width(8.dp)) }
                    Ic(if (p.micOn) "mic" else "mic_off", if (p.micOn) Color.White.copy(alpha = .8f) else Red, 20.dp)
                }
            }
        }
    }
    if (adding) AddToCallDialog(g.people.map { it.id }, onCancel = { adding = false }) { list -> g.invite(list); adding = false; toast(ctx, t("calling")) }
}

@Composable
private fun Tile(p: GPerson, allowVideo: Boolean, modifier: Modifier, onTap: () -> Unit) {
    val glow = if (p.speaking) Color(0xFF3CB8FF) else Color.White.copy(alpha = .12f)
    Box(
        modifier.press(RoundedCornerShape(18.dp), scaleTo = 0.97f) { onTap() }.background(Color(0xFF0F2236))
            .border(if (p.speaking) 3.dp else 1.dp, glow, RoundedCornerShape(18.dp))
    ) {
        val v = p.shown
        if (v != null && allowVideo) {
            key(v) { LkVideo(v, mirror = p.local && GroupCall.front && p.screen == null, fit = p.screen != null, modifier = Modifier.fillMaxSize()) }
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Avatar(p.name.ifBlank { "?" }, p.photo, p.id, 72.dp) }
        }
        Row(
            Modifier.align(Alignment.BottomStart).padding(8.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(alpha = .45f))
                .padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!p.micOn) { Ic("mic_off", Red, 14.dp); Spacer(Modifier.width(4.dp)) }
            if (p.screen != null) { Ic("screen_share", Mint, 14.dp); Spacer(Modifier.width(4.dp)) }
            Text(p.name, color = Color.White, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** One person big: two fingers zoom, drag moves, double tap resets. */
@Composable
private fun FocusView(p: GPerson, onShrink: () -> Unit) {
    var zoom by remember(p.id) { mutableFloatStateOf(1f) }
    var pan by remember(p.id) { mutableStateOf(Offset.Zero) }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Box(Modifier.fillMaxSize()
            .pointerInput(p.id) {
                detectTransformGestures { _, pn, z, _ ->
                    zoom = (zoom * z).coerceIn(1f, 5f)
                    pan = if (zoom <= 1f) Offset.Zero else pan + pn
                }
            }
            .pointerInput(p.id) { detectTapGestures(onDoubleTap = { zoom = 1f; pan = Offset.Zero }) }
            .graphicsLayer { scaleX = zoom; scaleY = zoom; translationX = pan.x; translationY = pan.y }
        ) {
            val v = p.shown
            if (v != null) key(v, "big") { LkVideo(v, mirror = p.local && GroupCall.front && p.screen == null, fit = true, modifier = Modifier.fillMaxSize()) }
            else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Avatar(p.name.ifBlank { "?" }, p.photo, p.id, 150.dp) }
        }
        Row(Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.safeDrawing).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(
                Modifier.height(44.dp).press(RoundedCornerShape(22.dp)) { onShrink() }.background(Color.White.copy(alpha = .16f))
                    .border(1.dp, Color.White.copy(alpha = .3f), RoundedCornerShape(22.dp)).padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Ic("fullscreen_exit", Color.White, 22.dp); Spacer(Modifier.width(6.dp))
                Text(t("shrink"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Spacer(Modifier.weight(1f))
            Text(p.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = .4f)).padding(horizontal = 10.dp, vertical = 5.dp))
        }
    }
}

/** What the small floating window shows during a group call. */
@Composable
fun GroupPipContent(now: Long) {
    val g = GroupCall
    val p = g.people.firstOrNull { !it.local && it.speaking && it.shown != null }
        ?: g.people.firstOrNull { !it.local && it.shown != null }
    Box(Modifier.fillMaxSize().background(CallBg), contentAlignment = Alignment.Center) {
        val sv = p?.shown
        if (p != null && sv != null) key(sv, "pip") { LkVideo(sv, mirror = false, fit = p.screen != null, modifier = Modifier.fillMaxSize()) }
        else Column(horizontalAlignment = Alignment.CenterHorizontally) {
            GroupAvatar(g.title.ifBlank { "?" }, g.photo, g.room, 56.dp)
            Spacer(Modifier.height(6.dp))
            Text(g.title.ifBlank { t("group_call") }, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Text(callClock(g.startedAt, now) + " · " + num("${g.people.size}"), color = Color.White, fontSize = 11.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(6.dp).clip(RoundedCornerShape(8.dp))
                .background(Color.Black.copy(alpha = .45f)).padding(horizontal = 6.dp, vertical = 2.dp))
    }
}

@Composable
private fun LkVideo(track: VideoTrack, mirror: Boolean, fit: Boolean = false, modifier: Modifier) {
    val holder = remember { arrayOfNulls<TextureViewRenderer>(1) }
    AndroidView(
        factory = { c ->
            TextureViewRenderer(c).also { r ->
                GroupCall.renderer(r)
                r.setMirror(mirror)
                try { r.setScalingType(if (fit) RendererCommon.ScalingType.SCALE_ASPECT_FIT else RendererCommon.ScalingType.SCALE_ASPECT_FILL) } catch (_: Exception) {}
                try { track.addRenderer(r) } catch (_: Exception) {}
                holder[0] = r
            }
        },
        update = { it.setMirror(mirror) },
        modifier = modifier,
    )
    DisposableEffect(track) {
        onDispose {
            holder[0]?.let { r ->
                try { track.removeRenderer(r) } catch (_: Exception) {}
                try { r.release() } catch (_: Exception) {}
            }
        }
    }
}

// ---------------------------------------------------------------- "Call in progress · Join" (asks for the microphone first)
@Composable
fun rememberJoiner(): (LiveCall) -> Unit {
    val ctx = LocalContext.current
    val want = remember { mutableStateOf<LiveCall?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val mic = r[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val c = want.value ?: return@rememberLauncherForActivityResult
        if (!mic) Toast.makeText(ctx, t("mic_need_call"), Toast.LENGTH_LONG).show()
        else GroupCall.rejoin(ctx, c.room, Repo.callTitle(c), c.video)
    }
    return { c ->
        want.value = c
        launcher.launch(if (c.video) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA) else arrayOf(Manifest.permission.RECORD_AUDIO))
    }
}

/** Green card: "Call in progress · 4 in call · Join". */
@Composable
fun LiveCallCard(c: LiveCall, onJoin: () -> Unit) {
    val inf = androidx.compose.animation.core.rememberInfiniteTransition(label = "live")
    val a by inf.animateFloat(0.35f, 1f, androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(800),
        androidx.compose.animation.core.RepeatMode.Reverse), label = "a")
    Row(
        Modifier.padding(horizontal = 14.dp, vertical = 5.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(Green.copy(alpha = .10f)).border(1.dp, Green.copy(alpha = .35f), RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(10.dp).graphicsLayer { alpha = a }.clip(CircleShape).background(Green))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(Repo.callTitle(c), color = P.tx, fontWeight = FontWeight.Bold, fontSize = 14.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(t("g_call_live") + " · " + num("${c.joined.size}") + " " + t("g_in_call"), color = P.tx2, fontSize = 13.sp)
        }
        Row(
            Modifier.height(38.dp).press(RoundedCornerShape(19.dp)) { onJoin() }.background(Green).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Ic(if (c.video) "video" else "call", Color.White, 18.dp); Spacer(Modifier.width(6.dp))
            Text(t("g_join"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}
