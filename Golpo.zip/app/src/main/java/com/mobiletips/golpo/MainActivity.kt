package com.mobiletips.golpo

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val fromNotif = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        Notif.channel(this)
        enableEdgeToEdge()
        handle(intent)
        setContent { App(fromNotif) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        i?.getStringExtra("chat")?.let { fromNotif.value = it }
    }

    override fun onStart() {
        super.onStart()
        Repo.foreground = true
        Repo.setOnline(true)
    }

    override fun onStop() {
        Repo.foreground = false
        Repo.setOnline(false)
        super.onStop()
    }
}

private sealed interface Scr {
    data object Main : Scr
    data class ChatWith(val other: String) : Scr
    data object New : Scr
    data object EditProfile : Scr
    data class Contact(val uid: String) : Scr
}

@Composable
fun App(fromNotif: MutableState<String?>) {
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? android.app.Activity)?.window ?: return@SideEffect
        WindowCompat.getInsetsController(w, view).apply {
            isAppearanceLightStatusBars = !Prefs.dark
            isAppearanceLightNavigationBars = !Prefs.dark
        }
    }
    var splash by remember { mutableStateOf(true) }
    var loggedIn by remember { mutableStateOf(Repo.uid != null) }
    LaunchedEffect(Unit) { delay(1300); splash = false }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { a ->
            val li = a.currentUser != null
            if (li) Repo.start() else Repo.stop()
            loggedIn = li
        }
        Repo.auth.addAuthStateListener(l)
        onDispose { Repo.auth.removeAuthStateListener(l) }
    }

    Box(Modifier.fillMaxSize().background(if (splash) Brand else P.bg)) {
        Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            val me = Repo.me
            when {
                splash -> Splash()
                !loggedIn -> AuthFlow()
                !Repo.meLoaded -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Brand)
                        Spacer(Modifier.height(12.dp)); Text(t("setting_up"), color = P.tx2)
                    }
                }
                me == null || me.name.isBlank() -> ProfileScreen(first = true, onBack = null) {}
                else -> MainNav(fromNotif)
            }
        }
    }
}

@Composable
private fun AuthFlow() {
    var stage by remember { mutableStateOf("welcome") }
    var phone by remember { mutableStateOf("") }
    BackHandler(stage != "welcome") { stage = if (stage == "otp") "phone" else "welcome" }
    when (stage) {
        "welcome" -> Welcome { stage = "phone" }
        "phone" -> PhoneScreen(onBack = { stage = "welcome" }) { phone = it; stage = "otp" }
        else -> OtpScreen(phone, onBack = { stage = "phone" }) { /* the auth listener moves on */ }
    }
}

@Composable
private fun MainNav(fromNotif: MutableState<String?>) {
    val stack = remember { mutableStateListOf<Scr>(Scr.Main) }
    var tab by remember { mutableStateOf("chats") }
    val top = stack.last()
    BackHandler(stack.size > 1 || tab != "chats") { if (stack.size > 1) stack.removeAt(stack.lastIndex) else tab = "chats" }

    // a tapped notification opens its chat
    val pending = fromNotif.value
    LaunchedEffect(pending) {
        val me = Repo.uid
        if (pending != null && me != null) {
            val other = pending.split("_").firstOrNull { it != me }
            if (other != null) { stack.clear(); stack.add(Scr.Main); stack.add(Scr.ChatWith(other)) }
            fromNotif.value = null
        }
    }
    // Android 13+: ask once to show notifications
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !Prefs.sp.getBoolean("asked_notif", false)) {
            Prefs.sp.edit().putBoolean("asked_notif", true).apply()
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun pop() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    when (top) {
        Scr.Main -> Home(tab, { tab = it }, openChat = { stack.add(Scr.ChatWith(it)) }, newChat = { stack.add(Scr.New) },
            editProfile = { stack.add(Scr.EditProfile) })
        is Scr.ChatWith -> ChatScreen(top.other, onBack = { pop() }, onProfile = { stack.add(Scr.Contact(top.other)) })
        Scr.New -> NewChat(onBack = { pop() }) { other -> pop(); stack.add(Scr.ChatWith(other)) }
        Scr.EditProfile -> ProfileScreen(first = false, onBack = { pop() }) { pop() }
        is Scr.Contact -> ContactScreen(top.uid) { pop() }
    }
}

@Composable
private fun ContactScreen(uid: String, onBack: () -> Unit) {
    val u = Repo.user(uid)
    Column(Modifier.fillMaxSize().background(P.bg)) {
        TopBar("", onBack)
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Avatar(u?.shown ?: "?", u?.photo ?: "", uid, 130.dp)
            Spacer(Modifier.height(14.dp))
            Text(u?.shown ?: "", color = P.tx, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("+88 " + (u?.phone ?: ""), color = P.tx2, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            Text(if (u?.online == true) t("online") else lastSeenText(u?.lastSeen ?: 0), color = if (u?.online == true) Mint else P.tx2, fontSize = 13.sp)
            Spacer(Modifier.height(20.dp))
            Card {
                Column(Modifier.padding(16.dp).fillMaxWidth()) {
                    Text(u?.about ?: "", color = P.tx, fontSize = 15.sp)
                    Text(t("about"), color = P.tx2, fontSize = 13.sp)
                }
            }
        }
    }
}
