package com.mobiletips.golpo

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val fromNotif = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        Notif.channel(this)
        Sounds.init(this)
        Repo.app = applicationContext
        enableEdgeToEdge()
        handle(intent)
        setContent { App(fromNotif) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        i?.getStringExtra("chat")?.let { fromNotif.value = it }
    }

    override fun onStart() {
        super.onStart()
        Repo.foreground = true
        Repo.setOnline(true)
    }

    override fun onStop() {
        Repo.foreground = false
        Repo.setOnline(false)
        super.onStop()
    }
}

private sealed interface Scr {
    data object Main : Scr
    data class ChatWith(val other: String) : Scr
    data object New : Scr
    data object EditProfile : Scr
    data class Contact(val uid: String) : Scr
    data class Page(val name: String) : Scr
    data class ContactPage(val uid: String, val page: String) : Scr
    data object NewGroup : Scr
    data class Group(val gid: String) : Scr
    data class GroupInfo(val gid: String) : Scr
    data class GroupAdd(val gid: String) : Scr
}

@Composable
fun App(fromNotif: MutableState<String?>) {
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? android.app.Activity)?.window ?: return@SideEffect
        WindowCompat.getInsetsController(w, view).apply {
            isAppearanceLightStatusBars = !Prefs.dark
            isAppearanceLightNavigationBars = !Prefs.dark
        }
    }
    var splash by remember { mutableStateOf(true) }
    var loggedIn by remember { mutableStateOf(Repo.uid != null) }
    LaunchedEffect(Unit) { delay(1300); splash = false }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { a ->
            val li = a.currentUser != null
            if (li) Repo.start() else Repo.stop()
            loggedIn = li
        }
        Repo.auth.addAuthStateListener(l)
        onDispose { Repo.auth.removeAuthStateListener(l) }
    }

    Box(Modifier.fillMaxSize().background(if (splash) Brand else P.bg)) {
        Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            val me = Repo.me
            when {
                splash -> Splash()
                !loggedIn -> AuthFlow()
                !Repo.meLoaded -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Brand)
                        Spacer(Modifier.height(12.dp)); Text(t("setting_up"), color = P.tx2)
                    }
                }
                me == null || me.name.isBlank() -> ProfileScreen(first = true, onBack = null) {}
                else -> MainNav(fromNotif)
            }
        }
    }
}

@Composable
private fun AuthFlow() {
    var stage by remember { mutableStateOf("welcome") }
    var phone by remember { mutableStateOf("") }
    BackHandler(stage != "welcome") { stage = if (stage == "otp") "phone" else "welcome" }
    when (stage) {
        "welcome" -> Welcome { stage = "phone" }
        "phone" -> PhoneScreen(onBack = { stage = "welcome" }) { phone = it; stage = "otp" }
        else -> OtpScreen(phone, onBack = { stage = "phone" }) { /* the auth listener moves on */ }
    }
}

@Composable
private fun MainNav(fromNotif: MutableState<String?>) {
    val stack = remember { mutableStateListOf<Scr>(Scr.Main) }
    var tab by remember { mutableStateOf("chats") }
    val top = stack.last()
    BackHandler(stack.size > 1 || tab != "chats") { if (stack.size > 1) stack.removeAt(stack.lastIndex) else tab = "chats" }

    // a tapped notification opens its chat
    val pending = fromNotif.value
    LaunchedEffect(pending) {
        val me = Repo.uid
        if (pending != null && me != null) {
            if (pending.startsWith("g_")) { stack.clear(); stack.add(Scr.Main); stack.add(Scr.Group(pending)) }
            else {
                val other = pending.split("_").firstOrNull { it != me }
                if (other != null) { stack.clear(); stack.add(Scr.Main); stack.add(Scr.ChatWith(other)) }
            }
            fromNotif.value = null
        }
    }
    // Android 13+: ask once to show notifications
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !Prefs.sp.getBoolean("asked_notif", false)) {
            Prefs.sp.edit().putBoolean("asked_notif", true).apply()
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun pop() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    when (top) {
        Scr.Main -> Home(tab, { tab = it }, openChat = { stack.add(if (it.startsWith("g_")) Scr.Group(it) else Scr.ChatWith(it)) }, newChat = { stack.add(Scr.New) },
            editProfile = { stack.add(Scr.EditProfile) }, openPage = { stack.add(Scr.Page(it)) })
        is Scr.ChatWith -> ChatScreen(top.other, onBack = { pop() }, onProfile = { stack.add(Scr.Contact(top.other)) })
        Scr.New -> NewChat(onBack = { pop() }, newGroup = { pop(); stack.add(Scr.NewGroup) }) { other -> pop(); stack.add(Scr.ChatWith(other)) }
        Scr.NewGroup -> NewGroupScreen(onBack = { pop() }) { gid -> pop(); stack.add(Scr.Group(gid)) }
        is Scr.Group -> ChatScreen("", onBack = { pop() }, onProfile = { stack.add(Scr.GroupInfo(top.gid)) }, groupId = top.gid)
        is Scr.GroupInfo -> GroupInfoScreen(top.gid, onBack = { pop() }, openChat = { stack.add(Scr.ChatWith(it)) },
            addPeople = { stack.add(Scr.GroupAdd(top.gid)) }, left = { stack.clear(); stack.add(Scr.Main) })
        is Scr.GroupAdd -> AddMembersScreen(top.gid) { pop() }
        Scr.EditProfile -> ProfileScreen(first = false, onBack = { pop() }) { pop() }
        is Scr.Contact -> ContactScreen(top.uid, openChat = {
            pop(); if ((stack.last() as? Scr.ChatWith)?.other != it) stack.add(Scr.ChatWith(it))
        }, openPage = { stack.add(Scr.ContactPage(top.uid, it)) }) { pop() }
        is Scr.ContactPage -> ContactSubPage(top.uid, top.page) { pop() }
        is Scr.Page -> SettingsPage(top.name, onBack = { pop() }, open = { stack.add(Scr.Page(it)) },
            openChat = { stack.add(Scr.ChatWith(it)) })
    }
}

