package com.mobiletips.golpo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/** New-message notifications (sent by the Golpo server through Firebase Cloud Messaging). */
class Fcm : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        Repo.saveFcmToken()
    }

    override fun onMessageReceived(m: RemoteMessage) {
        val d = m.data
        if (d["type"] != "msg") return
        val chat = d["chat"] ?: return
        val mid = d["mid"] ?: ""
        if (Repo.uid == null) return
        if (mid.isNotEmpty()) Repo.markDelivered(chat, mid)
        if (Repo.foreground && Repo.openChat == chat) return
        Prefs.init(this)
        Notif.show(this, chat, d["name"] ?: "Golpo Chat", d["body"] ?: t("new_msg"))
    }
}

object Notif {
    private const val CH = "messages"
    private val lines = HashMap<String, MutableList<String>>()

    fun channel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CH) == null) {
                nm.createNotificationChannel(NotificationChannel(CH, "Messages", NotificationManager.IMPORTANCE_HIGH))
            }
        }
    }

    fun show(c: Context, chat: String, name: String, body: String) {
        channel(c)
        val list = lines.getOrPut(chat) { mutableListOf() }
        list.add(body)
        while (list.size > 6) list.removeAt(0)
        val open = Intent(c, MainActivity::class.java).apply {
            putExtra("chat", chat)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pi = PendingIntent.getActivity(c, chat.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val sender = Person.Builder().setName(name).build()
        val style = NotificationCompat.MessagingStyle(Person.Builder().setName(t("you")).build())
        list.forEach { style.addMessage(it, System.currentTimeMillis(), sender) }
        val n = NotificationCompat.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFF6C4DF6.toInt())
            .setContentTitle(name)
            .setContentText(body)
            .setStyle(style)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(chat.hashCode(), n)
        } catch (_: SecurityException) {
        }
    }

    fun clear(c: Context, chat: String) {
        lines.remove(chat)
        NotificationManagerCompat.from(c).cancel(chat.hashCode())
    }
}
