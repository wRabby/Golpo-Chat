package com.mobiletips.golpo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/** New-message notifications (sent by the Golpo server through Firebase Cloud Messaging). */
class Fcm : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        Repo.saveFcmToken()
    }

    override fun onMessageReceived(m: RemoteMessage) {
        val d = m.data
        when (d["type"]) {
            "call" -> {
                Prefs.init(this)
                if (Repo.uid == null) return
                val id = d["call"] ?: return
                val sent = d["t"]?.toLongOrNull() ?: 0L
                if (sent > 0 && System.currentTimeMillis() - sent > 50_000) return   // too old
                CallManager.onIncoming(this, id, d["sender"] ?: "", d["name"] ?: "", d["photo"] ?: "", d["video"] == "1")
                return
            }
            "call_end" -> { CallManager.remoteCanceled(d["call"] ?: return); return }
            "gcall" -> {
                Prefs.init(this)
                if (Repo.uid == null) return
                val sent = d["t"]?.toLongOrNull() ?: 0L
                if (sent > 0 && System.currentTimeMillis() - sent > 50_000) return
                GroupCall.onIncoming(this, d["room"] ?: return, d["name"] ?: "", d["photo"] ?: "", d["by"] ?: "", d["video"] == "1")
                return
            }
        }
        if (d["type"] != "msg") return
        val chat = d["chat"] ?: return
        val mid = d["mid"] ?: ""
        if (Repo.uid == null) return
        if (mid.isNotEmpty()) Repo.markDelivered(chat, mid)
        if (Repo.foreground) return   // the open app shows it itself (see Repo.start)
        Prefs.init(this)
        if (!Prefs.notifOn) return
        if (Prefs.isMuted(d["sender"] ?: "") || Prefs.isMuted(chat)) return
        Notif.show(this, chat, d["name"] ?: "Golpo Chat", if (Prefs.preview) d["body"] ?: t("new_msg") else t("new_msg"))
    }
}

object Notif {
    private val lines = HashMap<String, MutableList<String>>()

    fun channel(c: Context): String = Sounds.msgChannel(c)

    fun show(c: Context, chat: String, name: String, body: String) {
        val ch = channel(c)
        val list = lines.getOrPut(chat) { mutableListOf() }
        list.add(body)
        while (list.size > 6) list.removeAt(0)
        val open = Intent(c, MainActivity::class.java).apply {
            putExtra("chat", chat)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pi = PendingIntent.getActivity(c, chat.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val sender = Person.Builder().setName(name).build()
        val style = NotificationCompat.MessagingStyle(Person.Builder().setName(t("you")).build())
        list.forEach { style.addMessage(it, System.currentTimeMillis(), sender) }
        val b = NotificationCompat.Builder(c, ch)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFF6C4DF6.toInt())
            .setContentTitle(name)
            .setContentText(body)
            .setStyle(style)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
        if (Build.VERSION.SDK_INT < 26) {
            val res = Sounds.toneRes(Prefs.tone)
            when {
                Prefs.tone == "silent" -> {}
                res != 0 -> b.setSound(Sounds.uri(c, res))
                else -> b.setDefaults(NotificationCompat.DEFAULT_SOUND)
            }
            if (Prefs.vibrate) b.setVibrate(longArrayOf(0, 250, 150, 250))
        }
        val n = b.build()
        try {
            NotificationManagerCompat.from(c).notify(chat.hashCode(), n)
        } catch (_: SecurityException) {
        }
    }

    fun clear(c: Context, chat: String) {
        lines.remove(chat)
        NotificationManagerCompat.from(c).cancel(chat.hashCode())
    }
}
