package com.mobiletips.golpo

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

/*
 * Stories (24 hours). Firestore stories/{id}:
 *   {by, kind: t|img|video, text, bg, url, thumb, dur, at, exp, aud: [friends + me], views: [], react: {uid: emoji}}
 *   stories/{id}/c/{auto}: {from, text, at}   (comments)
 * Only the people in "aud" (my friends when I posted) can see it. The server deletes old ones every 30 minutes.
 */
data class Story(
    val id: String, val by: String, val kind: String, val text: String, val bg: Int, val url: String, val thumb: String,
    val dur: Int, val at: Long, val exp: Long, val views: List<String>, val react: Map<String, String>,
)

val STORY_BGS = listOf(
    listOf(Color(0xFF1E9BF0), Color(0xFF0A5FA8)), listOf(Color(0xFF16C79A), Color(0xFF0E7C66)),
    listOf(Color(0xFFFF6A88), Color(0xFFFF9A6A)), listOf(Color(0xFF263445), Color(0xFF0D141C)),
    listOf(Color(0xFFF7B733), Color(0xFFFC4A1A)), listOf(Color(0xFF8E9EAB), Color(0xFF4B6074)),
)
val REACTS = listOf("❤️", "😂", "😮", "😢", "👍", "🔥")

object Stories {
    val list = mutableStateListOf<Story>()
    private val db get() = Repo.db

    fun listen(me: String): ListenerRegistration =
        db.collection("stories").whereArrayContains("aud", me).addSnapshotListener { s, _ ->
            if (s == null) return@addSnapshotListener
            val now = System.currentTimeMillis()
            val all = s.documents.mapNotNull { d ->
                val exp = d.getLong("exp") ?: return@mapNotNull null
                if (exp < now) return@mapNotNull null
                @Suppress("UNCHECKED_CAST")
                Story(d.id, d.getString("by") ?: return@mapNotNull null, d.getString("kind") ?: "t", d.getString("text") ?: "",
                    (d.getLong("bg") ?: 0L).toInt(), d.getString("url") ?: "", d.getString("thumb") ?: "",
                    (d.getLong("dur") ?: 0L).toInt(), d.getLong("at") ?: 0L, exp,
                    (d.get("views") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                    (d.get("react") as? Map<String, String>) ?: emptyMap())
            }.filter { !Repo.isBlockedByMe(it.by) }.sortedBy { it.at }
            list.clear(); list.addAll(all)
        }

    /** People with live stories: me first, then unseen, then seen (newest first). */
    fun owners(): List<String> {
        val me = Repo.uid ?: return emptyList()
        val now = System.currentTimeMillis()
        val by = list.filter { it.exp > now }.groupBy { it.by }
        val others = by.keys.filter { it != me }.sortedWith(compareBy({ allSeen(it) }, { -(by[it]?.maxOf { s -> s.at } ?: 0L) }))
        return (if (by.containsKey(me)) listOf(me) else emptyList()) + others
    }

    fun of(uid: String): List<Story> { val now = System.currentTimeMillis(); return list.filter { it.by == uid && it.exp > now } }

    fun allSeen(uid: String): Boolean {
        val me = Repo.uid ?: return true
        return of(uid).all { me in it.views || it.by == me }
    }

    fun post(kind: String, text: String, bg: Int, url: String, thumb: String, dur: Int, done: (Boolean) -> Unit) {
        val me = Repo.uid ?: return
        val now = System.currentTimeMillis()
        val aud = (Repo.friends() + me).distinct().take(900)
        db.collection("stories").add(mapOf(
            "by" to me, "kind" to kind, "text" to text.take(700), "bg" to bg, "url" to url, "thumb" to thumb, "dur" to dur,
            "at" to now, "exp" to now + 24 * 3600_000L, "aud" to aud, "views" to emptyList<String>(), "react" to emptyMap<String, String>(),
        )).addOnSuccessListener { done(true) }.addOnFailureListener { done(false) }
    }

    fun seen(s: Story) {
        val me = Repo.uid ?: return
        if (s.by == me || me in s.views) return
        db.collection("stories").document(s.id).update("views", FieldValue.arrayUnion(me))
    }

    fun react(s: Story, emoji: String) {
        val me = Repo.uid ?: return
        db.collection("stories").document(s.id).update("react.$me", emoji)
    }

    fun comment(s: Story, text: String) {
        val me = Repo.uid ?: return
        db.collection("stories").document(s.id).collection("c").add(mapOf("from" to me, "text" to text.take(500), "at" to System.currentTimeMillis()))
    }

    fun delete(s: Story) { db.collection("stories").document(s.id).delete() }
}

// ---------------------------------------------------------------- the round story row under the search bar
@Composable
fun StoryBar(openStory: (String) -> Unit, newStory: () -> Unit) {
    val me = Repo.uid ?: return
    val owners = Stories.owners()
    val mine = Stories.of(me).isNotEmpty()
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // my story: tap = add (or view if I have one), the small + always adds
        val myU = Repo.me
        StoryCircle(t("my_story"), myU?.shown ?: "?", myU?.photo ?: "", me, ring = if (mine) 1 else 0, plus = true,
            onPlus = newStory) { if (mine) openStory(me) else newStory() }
        owners.filter { it != me }.forEach { id ->
            val u = Repo.user(id)
            StoryCircle(u?.shown ?: "…", u?.shown ?: "?", u?.photo ?: "", id, ring = if (Stories.allSeen(id)) 2 else 1, plus = false, onPlus = {}) {
                openStory(id)
            }
        }
    }
}

/** ring: 0 none, 1 new (sky blue), 2 seen (grey) */
@Composable
private fun StoryCircle(label: String, name: String, photo: String, seed: String, ring: Int, plus: Boolean, onPlus: () -> Unit, onClick: () -> Unit) {
    Column(Modifier.width(74.dp).press(RoundedCornerShape(16.dp), scaleTo = 0.94f) { onClick() }.padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(64.dp)) {
            val b = when (ring) {
                1 -> Modifier.border(2.5.dp, Brush.linearGradient(listOf(Color(0xFF3CB8FF), Mint)), CircleShape)
                2 -> Modifier.border(2.dp, P.tx2.copy(alpha = .35f), CircleShape)
                else -> Modifier.border(1.dp, P.ln, CircleShape)
            }
            Box(Modifier.size(64.dp).then(b).padding(4.dp)) { Avatar(name, photo, seed, 56.dp) }
            if (plus) Box(
                Modifier.align(Alignment.BottomEnd).size(22.dp).press(CircleShape) { onPlus() }.background(P.bg).padding(2.dp)
                    .clip(CircleShape).background(Brand),
                contentAlignment = Alignment.Center
            ) { Ic("add", Color.White, 15.dp) }
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = P.tx, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

// ---------------------------------------------------------------- make a story: text / photo / video (30 s)
@Composable
fun StoryCreate(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var bg by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var pct by remember { mutableFloatStateOf(0f) }
    var picked by remember { mutableStateOf<android.net.Uri?>(null) }
    var pickedVideo by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val isVideo = (ctx.contentResolver.getType(uri) ?: "").startsWith("video")
        if (isVideo) {
            scope.launch {
                val (sec, _) = Media.videoInfo(ctx, uri)
                when {
                    sec > 31 -> toast(ctx, t("story_too_long"))
                    Media.size(ctx, uri) > 60L * 1024 * 1024 -> toast(ctx, t("video_too_big"))
                    else -> { picked = uri; pickedVideo = true }
                }
            }
        } else { picked = uri; pickedVideo = false }
    }
    fun publish() {
        if (busy) return
        busy = true
        scope.launch {
            try {
                val u = picked
                when {
                    u == null -> Stories.post("t", text.trim(), bg, "", "", 0) { ok -> busy = false; if (ok) onBack() else toast(ctx, t("e_send")) }
                    pickedVideo -> {
                        val (sec, thumbBytes) = Media.videoInfo(ctx, u)
                        val thumb = if (thumbBytes != null) Api.upload(thumbBytes, "thumb") else ""
                        val url = Api.uploadFile(ctx, u, "svideo", Media.size(ctx, u)) { pct = it }
                        Stories.post("video", text.trim(), bg, url, thumb, sec) { ok -> busy = false; if (ok) onBack() else toast(ctx, t("e_send")) }
                    }
                    else -> {
                        val url = Api.upload(Media.jpeg(ctx, u, 1600), "story")
                        Stories.post("img", text.trim(), bg, url, "", 0) { ok -> busy = false; if (ok) onBack() else toast(ctx, t("e_send")) }
                    }
                }
            } catch (e: Exception) {
                busy = false; toast(ctx, t("e_send"))
            }
        }
    }
    BackHandler { onBack() }
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(STORY_BGS[bg]))) {
        val p = picked
        if (p != null) {
            if (pickedVideo) VideoPlayer(p.toString(), Modifier.fillMaxSize(), controls = false)
            else AsyncImage(p, null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().background(Color.Black))
        }
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn("close", Color.White) { onBack() }
                Text(t("new_story"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (p == null) Box(Modifier.size(40.dp).press(CircleShape) { bg = (bg + 1) % STORY_BGS.size }
                    .background(Color.White.copy(alpha = .2f)), contentAlignment = Alignment.Center) { Ic("o_palette", Color.White, 22.dp) }
                if (p != null) IconBtn("del", Color.White) { picked = null }
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                if (p == null) {
                    if (text.isEmpty()) Text(t("story_hint"), color = Color.White.copy(alpha = .7f), fontSize = 26.sp, textAlign = TextAlign.Center)
                    BasicTextField(text, { text = it.take(700) },
                        textStyle = TextStyle(color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center),
                        cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth())
                }
            }
            if (p != null) {
                Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp).clip(RoundedCornerShape(22.dp)).background(Color.Black.copy(alpha = .45f))
                    .padding(horizontal = 16.dp, vertical = 12.dp)) {
                    if (text.isEmpty()) Text(t("caption"), color = Color.White.copy(alpha = .6f), fontSize = 15.sp)
                    BasicTextField(text, { text = it.take(300) }, textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                        cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(8.dp))
            }
            Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(
                    Modifier.weight(1f).height(52.dp).press(RoundedCornerShape(16.dp)) {
                        pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    }.border(1.5.dp, Color.White.copy(alpha = .7f), RoundedCornerShape(16.dp)),
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                ) {
                    Ic("o_image", Color.White, 22.dp); Spacer(Modifier.width(8.dp))
                    Text(t("photo_video"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                val can = (p != null || text.isNotBlank()) && !busy
                Box(Modifier.size(52.dp).press(CircleShape, enabled = can) { publish() }.background(if (can) Color.White else Color.White.copy(alpha = .35f)),
                    contentAlignment = Alignment.Center) {
                    if (busy) CircularProgressIndicator(progress = { if (pct > 0f) pct else 0.1f }, color = Brand, strokeWidth = 3.dp, modifier = Modifier.size(26.dp))
                    else Ic("send", Brand, 24.dp)
                }
            }
            Text(t("story_24h"), color = Color.White.copy(alpha = .75f), fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp))
        }
    }
}

// ---------------------------------------------------------------- watching stories
@Composable
fun StoryViewer(startUser: String, onBack: () -> Unit, openChat: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me = Repo.uid ?: ""
    val order = remember { Stories.owners().ifEmpty { listOf(startUser) } }
    var ui by remember { mutableIntStateOf(order.indexOf(startUser).coerceAtLeast(0)) }
    val uid = order.getOrElse(ui) { startUser }
    val items = Stories.of(uid)
    // start at the first one not seen yet
    var si by remember(uid) { mutableIntStateOf(items.indexOfFirst { me !in it.views && it.by != me }.let { if (it < 0) 0 else it }) }
    var paused by remember { mutableStateOf(false) }
    var comment by remember { mutableStateOf("") }
    var sheet by remember { mutableStateOf("") }      // "" | send | viewers | comments
    val bursts = remember { mutableStateListOf<Pair<Long, String>>() }
    val bar = remember { Animatable(0f) }
    BackHandler { onBack() }

    fun next() {
        if (si < items.size - 1) si++
        else if (ui < order.size - 1) ui++
        else onBack()
    }
    fun prev() {
        if (si > 0) si-- else if (ui > 0) ui--
    }
    if (items.isEmpty()) { LaunchedEffect(Unit) { onBack() }; return }
    val st = items[si.coerceIn(0, items.size - 1)]
    val mine = st.by == me
    var videoMs by remember(st.id) { mutableIntStateOf(0) }
    var barFor by remember { mutableStateOf("") }
    LaunchedEffect(st.id) { delay(8000); if (videoMs == 0) videoMs = 15_000 }   // a video that won't load still moves on
    val length = when { st.kind == "video" && videoMs > 0 -> videoMs; st.kind == "video" -> 30_000; else -> 6_000 }
    val hold = paused || sheet.isNotEmpty() || comment.isNotEmpty() || (st.kind == "video" && videoMs == 0)
    LaunchedEffect(st.id, hold, length) {
        if (barFor != st.id) { barFor = st.id; bar.snapTo(0f); Stories.seen(st) }
        if (hold) return@LaunchedEffect
        val left = ((1f - bar.value) * length).toInt().coerceAtLeast(1)
        bar.animateTo(1f, tween(left, easing = LinearEasing))
        next()
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // ---- the story itself
        key(st.id) {
            when (st.kind) {
                "img" -> AsyncImage(st.url, null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                "video" -> VideoPlayer(st.url, Modifier.fillMaxSize(), controls = false, onReady = { videoMs = it.coerceIn(1000, 31_000) })
                else -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(STORY_BGS.getOrElse(st.bg) { STORY_BGS[0] })).padding(30.dp),
                    contentAlignment = Alignment.Center) {
                    Text(st.text, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, lineHeight = 36.sp)
                }
            }
        }
        // tap left / right, hold to pause
        Row(Modifier.fillMaxSize().padding(top = 90.dp, bottom = 130.dp)) {
            Box(Modifier.weight(1f).fillMaxHeight().pointerInput(st.id) {
                detectTapGestures(onTap = { prev() }, onPress = { paused = true; tryAwaitRelease(); paused = false })
            })
            Box(Modifier.weight(2f).fillMaxHeight().pointerInput(st.id) {
                detectTapGestures(onTap = { next() }, onPress = { paused = true; tryAwaitRelease(); paused = false })
            })
        }
        // ---- top: progress + who
        Column(Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.safeDrawing)
            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .55f), Color.Transparent))).padding(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items.forEachIndexed { i, _ ->
                    Box(Modifier.weight(1f).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Color.White.copy(alpha = .35f))) {
                        val f = when { i < si -> 1f; i == si -> bar.value; else -> 0f }
                        Box(Modifier.fillMaxHeight().fillMaxWidth(f).background(Color.White))
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                val u = Repo.user(st.by)
                Avatar(u?.shown ?: "?", u?.photo ?: "", st.by, 38.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (mine) t("my_story") else u?.shown ?: "…", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(shortTime(st.at), color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                }
                if (mine) IconBtn("del", Color.White) { Stories.delete(st); next() }
                IconBtn("close", Color.White) { onBack() }
            }
        }
        if (st.text.isNotBlank() && st.kind != "t") {
            Text(st.text, color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 150.dp, start = 20.dp, end = 20.dp)
                    .clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = .45f)).padding(horizontal = 14.dp, vertical = 8.dp))
        }
        // ---- floating reaction animation
        bursts.forEach { (id, e) -> key(id) { Burst(e) { bursts.removeAll { it.first == id } } } }

        // ---- bottom: reactions, comment, share, send to a friend
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().windowInsetsPadding(WindowInsets.safeDrawing)
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .6f)))).padding(10.dp)) {
            if (mine) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StoryPill("eye", num("${st.views.size}") + " " + t("views"), Modifier.weight(1f)) { sheet = "viewers" }
                    StoryPill("o_chat", t("comments"), Modifier.weight(1f)) { sheet = "comments" }
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    REACTS.forEach { e ->
                        val on = st.react[me] == e
                        Text(e, fontSize = 30.sp, modifier = Modifier.press(CircleShape, scaleTo = 0.75f) {
                            Stories.react(st, e)
                            repeat(6) { k -> bursts.add(System.nanoTime() + k to e) }
                        }.background(if (on) Color.White.copy(alpha = .25f) else Color.Transparent).padding(6.dp))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f).heightIn(min = 46.dp).clip(RoundedCornerShape(23.dp)).border(1.dp, Color.White.copy(alpha = .6f), RoundedCornerShape(23.dp))
                        .padding(horizontal = 16.dp, vertical = 12.dp)) {
                        if (comment.isEmpty()) Text(t("write_comment"), color = Color.White.copy(alpha = .7f), fontSize = 15.sp)
                        BasicTextField(comment, { comment = it.take(500) }, textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                            cursorBrush = SolidColor(Color.White), maxLines = 3, modifier = Modifier.fillMaxWidth())
                    }
                    Spacer(Modifier.width(8.dp))
                    if (comment.isNotBlank()) {
                        Box(Modifier.size(46.dp).press(CircleShape) {
                            Stories.comment(st, comment.trim()); comment = ""; toast(ctx, t("comment_sent"))
                        }.background(Brand), contentAlignment = Alignment.Center) { Ic("send", Color.White, 22.dp) }
                    } else {
                        Box(Modifier.size(46.dp).press(CircleShape) { sheet = "comments" }.background(Color.White.copy(alpha = .15f)),
                            contentAlignment = Alignment.Center) { Ic("o_chat", Color.White, 22.dp) }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StoryPill("share", t("share"), Modifier.weight(1f)) {
                    if (st.kind == "t") Saver.shareText(ctx, st.text) else scope.launch { Saver.share(ctx, st.url, st.kind == "video") }
                }
                StoryPill("forward", t("send_friend"), Modifier.weight(1f)) { sheet = "send" }
            }
        }
    }

    when (sheet) {
        "send" -> FriendPicker(t("send_friend"), onCancel = { sheet = "" }) { list ->
            list.forEach { to ->
                when (st.kind) {
                    "img" -> Repo.sendTo(to, "img", url = st.url)
                    "video" -> Repo.sendTo(to, "video", url = st.url, thumb = st.thumb, dur = st.dur)
                    else -> Repo.sendTo(to, "t", text = st.text)
                }
            }
            sheet = ""; toast(ctx, t("sent"))
        }
        "viewers" -> BottomSheet(onDismiss = { sheet = "" }) {
            Text(num("${st.views.size}") + " " + t("views"), color = P.tx, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                items(st.views) { v ->
                    val u = Repo.user(v)
                    Row(Modifier.fillMaxWidth().pressRow { sheet = ""; openChat(v) }.padding(horizontal = 20.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Avatar(u?.shown ?: "?", u?.photo ?: "", v, 42.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(u?.shown ?: "…", color = P.tx, fontSize = 15.5.sp, modifier = Modifier.weight(1f))
                        st.react[v]?.let { Text(it, fontSize = 22.sp) }
                    }
                }
            }
        }
        "comments" -> CommentsSheet(st) { sheet = "" }
    }
}

@Composable
private fun StoryPill(icon: String, text: String, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.height(44.dp).press(RoundedCornerShape(22.dp)) { onClick() }.background(Color.White.copy(alpha = .14f))
        .border(1.dp, Color.White.copy(alpha = .35f), RoundedCornerShape(22.dp)),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Ic(icon, Color.White, 19.dp); Spacer(Modifier.width(7.dp))
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** One emoji floating up and fading out. */
@Composable
private fun Burst(e: String, done: () -> Unit) {
    val y = remember { Animatable(0f) }
    val x = remember { (Random.nextFloat() - 0.5f) * 220f }
    val big = remember { 0.8f + Random.nextFloat() * 0.8f }
    val wait = remember { Random.nextLong(0, 260) }
    LaunchedEffect(Unit) { delay(wait); y.animateTo(1f, tween(1400)); done() }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
        Text(e, fontSize = 40.sp, modifier = Modifier
            .offset(x = x.dp / 2, y = (-260 * y.value - 150).dp)
            .graphicsLayer { scaleX = big * (1f + y.value * .4f); scaleY = scaleX }
            .alpha((if (y.value < .1f) y.value * 10 else (1f - y.value) * 1.3f).coerceIn(0f, 1f)))
    }
}

@Composable
private fun CommentsSheet(st: Story, onClose: () -> Unit) {
    val list = remember { mutableStateListOf<Triple<String, String, Long>>() }
    DisposableEffect(st.id) {
        val reg = Repo.db.collection("stories").document(st.id).collection("c").orderBy("at", Query.Direction.ASCENDING).limitToLast(200)
            .addSnapshotListener { s, _ ->
                if (s == null) return@addSnapshotListener
                list.clear()
                list.addAll(s.documents.map { Triple(it.getString("from") ?: "", it.getString("text") ?: "", it.getLong("at") ?: 0L) })
            }
        onDispose { reg.remove() }
    }
    BottomSheet(onDismiss = onClose) {
        Text(t("comments") + " · " + num("${list.size}"), color = P.tx, fontSize = 17.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
        if (list.isEmpty()) Text(t("no_comments"), color = P.tx2, modifier = Modifier.padding(22.dp))
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 440.dp)) {
            items(list) { (from, text, at) ->
                val u = Repo.user(from)
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                    Avatar(u?.shown ?: "?", u?.photo ?: "", from, 36.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.clip(RoundedCornerShape(14.dp)).background(P.bg2).padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Row {
                            Text(if (from == Repo.uid) t("you") else u?.shown ?: "…", color = P.tx, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(shortTime(at), color = P.tx2, fontSize = 11.5.sp)
                        }
                        Text(text, color = P.tx, fontSize = 14.5.sp)
                    }
                }
            }
        }
    }
}

/** Choose friends (and groups) to send something to. */
@Composable
fun FriendPicker(title: String, onCancel: () -> Unit, onSend: (List<String>) -> Unit) {
    val picked = remember { mutableStateListOf<String>() }
    val targets = Repo.chats.map { if (it.group) it.id else it.other }.filter { it.isNotEmpty() }.distinct()
    BottomSheet(onDismiss = onCancel) {
        Text(title, color = P.tx, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
        if (targets.isEmpty()) Text(t("g_no_friends"), color = P.tx2, modifier = Modifier.padding(22.dp))
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
            items(targets) { id ->
                val g = if (id.startsWith("g_")) Repo.chats.firstOrNull { it.id == id } else null
                val u = if (g == null) Repo.user(id) else null
                val name = g?.name ?: u?.shown ?: "…"
                val on = id in picked
                Row(Modifier.fillMaxWidth().pressRow { if (on) picked.remove(id) else picked.add(id) }.padding(horizontal = 18.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    if (g != null) GroupAvatar(name, g.photo, id, 42.dp) else Avatar(name, u?.photo ?: "", id, 42.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(name, color = P.tx, fontSize = 15.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Box(Modifier.size(24.dp).clip(CircleShape).background(if (on) Brand else Color.Transparent)
                        .border(2.dp, if (on) Brand else P.tx2, CircleShape), contentAlignment = Alignment.Center) {
                        if (on) Ic("check", Color.White, 16.dp)
                    }
                }
            }
        }
        Box(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            GradButton(t("send") + if (picked.isNotEmpty()) " (" + num("${picked.size}") + ")" else "", enabled = picked.isNotEmpty()) { onSend(picked.toList()) }
        }
    }
}
