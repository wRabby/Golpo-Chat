package com.mobiletips.golpo

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- colours
val Brand = Color(0xFF6C4DF6)
val Mint = Color(0xFF22C9A5)
val Red = Color(0xFFFF3B5C)
val Green = Color(0xFF1FCB6A)
val Blue = Color(0xFF3BA4FF)
val Grad = Brush.linearGradient(listOf(Color(0xFF6C4DF6), Color(0xFF9B6BFF), Color(0xFF22C9A5)))

class Pal(
    val bg: Color, val bg2: Color, val card: Color, val tx: Color, val tx2: Color,
    val ln: Color, val inB: Color, val outB: Color, val wall: Color, val pill: Color,
)

val LightPal = Pal(
    Color.White, Color(0xFFF4F2FB), Color.White, Color(0xFF17142A), Color(0xFF6E6A85),
    Color(0xFFECEAF4), Color.White, Color(0xFFEAE4FF), Color(0xFFF1EEFA), Color(0xFFEAE4FF),
)
val DarkPal = Pal(
    Color(0xFF0F0E17), Color(0xFF1A1826), Color(0xFF1C1A29), Color(0xFFF2F0FA), Color(0xFF9A96B0),
    Color(0xFF2A2738), Color(0xFF22202F), Color(0xFF3B2F86), Color(0xFF14121E), Color(0xFF2F2760),
)
val P: Pal get() = if (Prefs.dark) DarkPal else LightPal

val WALLS_LIGHT = listOf(Color(0xFFF1EEFA), Color(0xFFE6F6F1), Color(0xFFFFF2E4), Color(0xFFE6F1FF), Color(0xFFFDEAF1), Color(0xFFF0F0F0))
val WALLS_DARK = listOf(Color(0xFF14121E), Color(0xFF0E1C19), Color(0xFF1D160F), Color(0xFF0E1522), Color(0xFF1E1016), Color(0xFF151515))
fun wallColor(i: Int = Prefs.wall): Color = (if (Prefs.dark) WALLS_DARK else WALLS_LIGHT).getOrElse(i) { P.wall }

// ---------------------------------------------------------------- saved settings
object Prefs {
    lateinit var sp: SharedPreferences
    var lang by mutableStateOf("en")
    var dark by mutableStateOf(false)
    var ring by mutableStateOf("golpo_classic")     // call ringtone
    var tone by mutableStateOf("chime")             // message tone
    var vibrate by mutableStateOf(true)
    var preview by mutableStateOf(true)             // show message text in notifications
    var notifOn by mutableStateOf(true)
    var chatSounds by mutableStateOf(true)          // send / receive sounds inside a chat
    var font by mutableStateOf("m")                 // s / m / l
    var wall by mutableStateOf(0)                   // chat wallpaper index
    var enterSends by mutableStateOf(false)

    val fontScale get() = when (font) { "s" -> 0.9f; "l" -> 1.18f; else -> 1f }

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.getSharedPreferences("golpo", Context.MODE_PRIVATE)
        lang = sp.getString("lang", "en") ?: "en"
        dark = sp.getBoolean("dark", false)
        ring = sp.getString("ring", "golpo_classic") ?: "golpo_classic"
        tone = sp.getString("tone", "chime") ?: "chime"
        vibrate = sp.getBoolean("vibrate", true)
        preview = sp.getBoolean("preview", true)
        notifOn = sp.getBoolean("notifOn", true)
        chatSounds = sp.getBoolean("chatSounds", true)
        font = sp.getString("font", "m") ?: "m"
        wall = sp.getInt("wall", 0)
        enterSends = sp.getBoolean("enterSends", false)
    }

    var tick by mutableStateOf(0)                   // bumps when a per-chat setting changes

    fun chatWall(chat: String): Int { tick; return sp.getInt("wall_$chat", -1) }
    fun setChatWall(chat: String, i: Int) { sp.edit().putInt("wall_$chat", i).apply(); tick++ }
    fun isMuted(other: String): Boolean { tick; return sp.getStringSet("muted", emptySet())?.contains(other) == true }
    fun setMuted(other: String, on: Boolean) {
        val set = HashSet(sp.getStringSet("muted", emptySet()) ?: emptySet())
        if (on) set.add(other) else set.remove(other)
        sp.edit().putStringSet("muted", set).apply(); tick++
    }

    fun put(key: String, v: Any) {
        val e = sp.edit()
        when (v) {
            is Boolean -> e.putBoolean(key, v)
            is Int -> e.putInt(key, v)
            else -> e.putString(key, v.toString())
        }
        e.apply()
        when (key) {
            "ring" -> ring = v as String
            "tone" -> tone = v as String
            "vibrate" -> vibrate = v as Boolean
            "preview" -> preview = v as Boolean
            "notifOn" -> notifOn = v as Boolean
            "chatSounds" -> chatSounds = v as Boolean
            "font" -> font = v as String
            "wall" -> wall = v as Int
            "enterSends" -> enterSends = v as Boolean
        }
    }

    fun toggleLang() {
        lang = if (lang == "en") "bn" else "en"
        sp.edit().putString("lang", lang).apply()
    }

    fun setDarkMode(v: Boolean) {
        dark = v
        sp.edit().putBoolean("dark", v).apply()
    }
}

// ---------------------------------------------------------------- language (English first, Bangla on tap)
private val S = mapOf(
    "tag" to ("Chat & Video Call" to "চ্যাট ও ভিডিও কল"),
    "welcome_t" to ("Welcome to Golpo Chat" to "Golpo Chat-এ স্বাগতম"),
    "welcome_s" to ("Free chat, voice & video calls with your friends and family — fast and secure." to "বন্ধু ও পরিবারের সাথে ফ্রি চ্যাট, অডিও ও ভিডিও কল — দ্রুত আর নিরাপদ।"),
    "agree" to ("By tapping Start you agree to our Terms and Privacy Policy." to "শুরু করুন চাপলে আপনি আমাদের শর্তাবলি ও প্রাইভেসি পলিসিতে সম্মত হচ্ছেন।"),
    "start" to ("Start" to "শুরু করুন"),
    "phone_t" to ("Your phone number" to "আপনার মোবাইল নাম্বার"),
    "phone_s" to ("We will send a 6-digit code to this number by SMS." to "এই নাম্বারে ৬ সংখ্যার একটা কোড SMS-এ যাবে।"),
    "bd" to ("Bangladesh" to "বাংলাদেশ"),
    "next" to ("Next" to "পরবর্তী"),
    "confirm_num" to ("Is this number correct? We will send the code here." to "নাম্বারটা কি ঠিক আছে? এই নাম্বারে কোড পাঠানো হবে।"),
    "yes" to ("Yes" to "হ্যাঁ, ঠিক আছে"),
    "edit" to ("Edit" to "বদলাবো"),
    "cancel" to ("Cancel" to "বাতিল"),
    "save" to ("Save" to "সেভ করুন"),
    "otp_t" to ("Enter the code" to "কোডটা লিখুন"),
    "otp_sent" to ("Code sent to" to "কোড পাঠানো হয়েছে"),
    "wrong_num" to ("Wrong number?" to "নাম্বার ভুল?"),
    "waiting" to ("Waiting for SMS… the code fills in by itself" to "SMS-এর অপেক্ষায়… কোড নিজে থেকেই বসে যাবে"),
    "resend_in" to ("Resend code in" to "আবার কোড পাঠানো যাবে"),
    "resend" to ("Resend SMS" to "আবার SMS পাঠান"),
    "verifying" to ("Verifying…" to "যাচাই হচ্ছে…"),
    "e_wrong_code" to ("Wrong code. Please try again." to "কোড ভুল হয়েছে, আবার চেষ্টা করুন।"),
    "e_expired" to ("The code has expired. Tap Resend SMS." to "কোডের মেয়াদ শেষ। আবার SMS পাঠান চাপুন।"),
    "e_too_many" to ("Too many tries. Please try later." to "অনেকবার চেষ্টা হয়েছে, পরে আবার চেষ্টা করুন।"),
    "e_wait" to ("Please wait a little before asking again." to "আবার চাওয়ার আগে একটু অপেক্ষা করুন।"),
    "e_limit" to ("Daily code limit reached. Try tomorrow." to "আজকের কোডের সীমা শেষ, কাল আবার চেষ্টা করুন।"),
    "e_bad_number" to ("Enter a valid Bangladeshi mobile number." to "সঠিক বাংলাদেশি মোবাইল নাম্বার দিন।"),
    "e_net" to ("Cannot reach the server. Check your internet." to "সার্ভারের সাথে যোগাযোগ হচ্ছে না। ইন্টারনেট দেখুন।"),
    "e_server" to ("The server is not ready yet. Please try later." to "সার্ভার এখনো প্রস্তুত না, পরে চেষ্টা করুন।"),
    "e_login" to ("Login failed. Please try again." to "লগইন হয়নি, আবার চেষ্টা করুন।"),
    "prof_t" to ("Profile info" to "প্রোফাইল সেট করুন"),
    "prof_s" to ("Add your name and an optional photo" to "আপনার নাম আর চাইলে একটা ছবি দিন"),
    "your_name" to ("Your name" to "আপনার নাম"),
    "about" to ("About" to "সম্পর্কে"),
    "about_def" to ("Hey there! I am using Golpo Chat" to "আমি Golpo Chat ব্যবহার করছি"),
    "tap_photo" to ("Tap the photo to change it" to "ছবিতে চাপলে বদলাবে"),
    "setting_up" to ("Setting up…" to "সব রেডি করা হচ্ছে…"),
    "chats" to ("Chats" to "চ্যাট"),
    "calls" to ("Calls" to "কল"),
    "settings" to ("Settings" to "সেটিংস"),
    "search" to ("Search name or number…" to "নাম বা নাম্বার খুঁজুন…"),
    "all" to ("All" to "সব"),
    "unread" to ("Unread" to "অপঠিত"),
    "no_chats" to ("No chats yet. Tap the add-friend button to start one." to "এখনো কোনো চ্যাট নেই। বন্ধু যোগ করার বোতাম চেপে শুরু করুন।"),
    "new_chat" to ("New chat" to "নতুন চ্যাট"),
    "on_golpo" to ("People on Golpo Chat" to "Golpo Chat-এ যারা আছেন"),
    "add_friend" to ("Add friend" to "বন্ধু যোগ করুন"),
    "add_friend_s" to ("Find someone by their phone number" to "মোবাইল নাম্বার দিয়ে খুঁজুন"),
    "find" to ("Search" to "খুঁজুন"),
    "e_invalid_num" to ("Invalid number. Enter a correct 11-digit mobile number." to "নাম্বারটি সঠিক নয়। ১১ সংখ্যার সঠিক মোবাইল নাম্বার দিন।"),
    "e_own_num" to ("This is your own number." to "এটা আপনার নিজের নাম্বার।"),
    "e_not_found" to ("No one was found with this number." to "এই নাম্বারে কোনো ব্যক্তি খুঁজে পাওয়া যায়নি।"),
    "invite_btn" to ("Invite" to "আমন্ত্রণ"),
    "message_btn" to ("Message" to "মেসেজ"),
    "my_friends" to ("Your friends" to "আপনার বন্ধুরা"),
    "nobody" to ("Nobody else has joined yet. Invite your friends!" to "এখনো আর কেউ যোগ দেয়নি। বন্ধুদের আমন্ত্রণ জানান!"),
    "invite" to ("Invite a friend" to "বন্ধুকে আমন্ত্রণ"),
    "invite_text" to ("Let's chat on Golpo Chat! Download it here: https://play.google.com/store/apps/details?id=com.mobiletips.golpo" to "চলো Golpo Chat-এ কথা বলি! এখান থেকে নামাও: https://play.google.com/store/apps/details?id=com.mobiletips.golpo"),
    "contacts" to ("contacts" to "জন"),
    "online" to ("online" to "অনলাইন"),
    "typing" to ("typing…" to "টাইপ করছে…"),
    "last_seen" to ("last seen" to "শেষ দেখা"),
    "today" to ("Today" to "আজ"),
    "yesterday" to ("Yesterday" to "গতকাল"),
    "type_msg" to ("Message" to "মেসেজ লিখুন"),
    "photo" to ("📷 Photo" to "📷 ছবি"),
    "voice" to ("🎤 Voice message" to "🎤 ভয়েস মেসেজ"),
    "deleted_me" to ("🚫 You deleted this message" to "🚫 আপনি মেসেজটি মুছে ফেলেছেন"),
    "deleted" to ("🚫 This message was deleted" to "🚫 এই মেসেজটি মুছে ফেলা হয়েছে"),
    "recording" to ("Recording…" to "রেকর্ড হচ্ছে…"),
    "reply" to ("Reply" to "রিপ্লাই"),
    "copy" to ("Copy" to "কপি"),
    "copied" to ("Copied" to "কপি হয়েছে"),
    "del_all" to ("Delete for everyone" to "সবার জন্য মুছুন"),
    "you" to ("You" to "আপনি"),
    "sending" to ("Sending…" to "পাঠানো হচ্ছে…"),
    "e_send" to ("Could not send. Please try again." to "পাঠানো যায়নি, আবার চেষ্টা করুন।"),
    "mic_need" to ("Allow the microphone to record voice messages." to "ভয়েস রেকর্ড করতে মাইক্রোফোনের অনুমতি দিন।"),
    "calls_t" to ("Voice & video calls are coming" to "অডিও আর ভিডিও কল আসছে"),
    "calls_s" to ("Calls arrive in the next update. Chat is ready to use now!" to "পরের আপডেটে কল আসবে। এখন চ্যাট ব্যবহার করুন!"),
    "calls_soon" to ("Calls are coming in the next update" to "কল পরের আপডেটে আসবে"),
    "lang" to ("App language" to "অ্যাপের ভাষা"),
    "lang_now" to ("English" to "বাংলা"),
    "dark" to ("Dark mode" to "ডার্ক মোড"),
    "profile" to ("Profile" to "প্রোফাইল"),
    "phone" to ("Phone" to "ফোন"),
    "logout" to ("Log out" to "লগআউট"),
    "logout_q" to ("You will need a new SMS code to log in again." to "আবার ঢুকতে নতুন SMS কোড লাগবে।"),
    "help" to ("Help & support" to "সাহায্য"),
    "notif_t" to ("Notifications" to "নোটিফিকেশন"),
    "notif_s" to ("Allow notifications so you never miss a message." to "নোটিফিকেশন চালু রাখুন, যাতে কোনো মেসেজ মিস না হয়।"),
    "new_msg" to ("New message" to "নতুন মেসেজ"),
    "messages_ch" to ("Messages" to "মেসেজ"),
    "group" to ("Group" to "গ্রুপ"),
    "group_call" to ("Group call" to "গ্রুপ কল"),
    "add_to_call" to ("Add people to this call" to "কলে মানুষ যোগ করুন"),
    "add_call_btn" to ("Call" to "কল দিন"),
    "in_gaudio" to ("Group voice call" to "গ্রুপ অডিও কল"),
    "in_gvideo" to ("Group video call" to "গ্রুপ ভিডিও কল"),
    "g_in_call" to ("in call" to "জন কলে"),
    "g_call_live" to ("Call in progress" to "কল চলছে"),
    "g_join" to ("Join" to "যোগ দিন"),
    "cam_need" to ("Allow the camera to turn on video." to "ভিডিও চালু করতে ক্যামেরার অনুমতি দিন।"),
    "g_new_title" to ("New group" to "নতুন গ্রুপ"),
    "g_new_s" to ("Chat with many friends together" to "অনেক বন্ধুর সাথে একসাথে চ্যাট"),
    "g_new" to ("New group created" to "নতুন গ্রুপ তৈরি হয়েছে"),
    "g_name" to ("Group name" to "গ্রুপের নাম"),
    "g_create" to ("Create group" to "গ্রুপ তৈরি করুন"),
    "g_members" to ("members" to "জন সদস্য"),
    "g_info" to ("Group info" to "গ্রুপের তথ্য"),
    "g_add" to ("Add members" to "সদস্য যোগ করুন"),
    "g_admin" to ("Admin" to "অ্যাডমিন"),
    "g_make_admin" to ("Make group admin" to "অ্যাডমিন বানান"),
    "g_unadmin" to ("Remove as admin" to "অ্যাডমিন থেকে সরান"),
    "g_remove" to ("Remove from group" to "গ্রুপ থেকে বাদ দিন"),
    "g_leave" to ("Leave group" to "গ্রুপ ছেড়ে দিন"),
    "g_leave_q" to ("You will stop getting this group's messages." to "এই গ্রুপের মেসেজ আর আসবে না।"),
    "g_gone" to ("You are no longer in this group." to "আপনি আর এই গ্রুপে নেই।"),
    "g_already" to ("Already in the group." to "আগে থেকেই গ্রুপে আছে।"),
    "g_no_friends" to ("Chat with someone first, or type their number above." to "আগে কারো সাথে চ্যাট করুন, বা ওপরে তার নাম্বার লিখুন।"),
    "notif_off" to ("Notifications are off. You will miss messages." to "নোটিফিকেশন বন্ধ আছে, মেসেজ মিস হবে।"),
    "turn_on" to ("Turn on" to "চালু করুন"),
    "p_seen" to ("Last seen & online" to "শেষ দেখা ও অনলাইন"),
    "p_photo" to ("Profile photo" to "প্রোফাইল ছবি"),
    "p_receipts" to ("Read receipts" to "রিড রিসিপ্ট (নীল টিক)"),
    "p_receipts_s" to ("If off, you also won't see others' blue ticks" to "বন্ধ করলে আপনিও অন্যদের নীল টিক দেখবেন না"),
    "who_all" to ("Everyone" to "সবাই"),
    "who_friends" to ("My friends" to "শুধু বন্ধুরা"),
    "who_none" to ("Nobody" to "কেউ না"),
    "p_seen_note" to ("Friends are people you have chatted with." to "যাদের সাথে আপনার চ্যাট হয়েছে, তারাই বন্ধু।"),
    "p_photo_note" to ("People who can't see your photo will see your first letter instead." to "যারা ছবি দেখতে পারবে না, তারা আপনার নামের প্রথম অক্ষর দেখবে।"),
    "s_storage" to ("Storage & data" to "স্টোরেজ ও ডাটা"),
    "s_storage_s" to ("Clear cache" to "ক্যাশ পরিষ্কার"),
    "clear_cache" to ("Clear cache" to "ক্যাশ পরিষ্কার"),
    "clear_cache_s" to ("Removes saved copies of photos and voice messages. They download again when you open them." to "ছবি ও ভয়েসের জমা কপি মুছে যাবে। খুললে আবার নামবে।"),
    "delete_acc" to ("Delete my account" to "অ্যাকাউন্ট ডিলিট"),
    "delete_t" to ("Deleting your account will:" to "অ্যাকাউন্ট ডিলিট করলে:"),
    "delete_s" to ("• remove your profile, name and photo\n• log you out on this phone\n• let you sign up again later with the same number as a new account" to "• আপনার প্রোফাইল, নাম ও ছবি মুছে যাবে\n• এই ফোন থেকে লগআউট হবে\n• পরে একই নাম্বারে নতুন করে অ্যাকাউন্ট খোলা যাবে"),
    "delete_q" to ("This cannot be undone." to "এটা আর ফেরত আনা যাবে না।"),
    "group_call_soon" to ("Adding people to a call is coming in a later update" to "কলে আরও মানুষ যোগ করা পরের আপডেটে আসবে"),
    "shared_photos" to ("Shared photos" to "শেয়ার করা ছবি"),
    "no_photos" to ("No photos shared yet." to "এখনো কোনো ছবি শেয়ার হয়নি।"),
    "chat_wall" to ("Wallpaper" to "ওয়ালপেপার"),
    "wall_default" to ("Same as Settings" to "সেটিংসের মতো"),
    "shortcut" to ("Shortcut" to "শর্টকাট"),
    "shortcut_s" to ("Add this chat to the home screen" to "হোম স্ক্রিনে এই চ্যাট রাখুন"),
    "shortcut_fail" to ("Your phone does not allow shortcuts." to "আপনার ফোনে শর্টকাট রাখা যায় না।"),
    "add_fav" to ("Add to Favorites" to "প্রিয় তালিকায় রাখুন"),
    "add_fav_s" to ("Pin this chat at the top" to "চ্যাটটি সবার ওপরে থাকবে"),
    "mute_notif" to ("Mute notifications" to "নোটিফিকেশন বন্ধ"),
    "call_privacy" to ("Call Privacy" to "কল প্রাইভেসি"),
    "calls_allowed" to ("Can call you" to "আপনাকে কল দিতে পারবে"),
    "calls_blocked" to ("Can't call you" to "আপনাকে কল দিতে পারবে না"),
    "allow_calls" to ("Allow calls" to "কল আসতে দিন"),
    "no_calls_from" to ("Don't allow calls" to "কল আসতে দেবেন না"),
    "invisible" to ("Invisible to this friend" to "এই বন্ধুর কাছে অদৃশ্য"),
    "invisible_s" to ("Hide your online status and last seen" to "আপনার অনলাইন ও শেষ দেখা লুকান"),
    "source" to ("Source" to "সূত্র"),
    "source_s" to ("Connected through phone number" to "মোবাইল নাম্বারের মাধ্যমে যুক্ত"),
    "report" to ("Report" to "রিপোর্ট"),
    "report_t" to ("Why are you reporting?" to "কেন রিপোর্ট করছেন?"),
    "r_spam" to ("Spam" to "স্প্যাম"),
    "r_harass" to ("Harassment or bullying" to "হয়রানি বা উত্ত্যক্ত করা"),
    "r_fake" to ("Fake account" to "ভুয়া অ্যাকাউন্ট"),
    "r_bad" to ("Inappropriate content" to "অশালীন কিছু"),
    "r_other" to ("Something else" to "অন্য কিছু"),
    "send" to ("Send" to "পাঠান"),
    "reported" to ("Thanks. Your report was sent." to "ধন্যবাদ, আপনার রিপোর্ট পাঠানো হয়েছে।"),
    "phone_ringtone" to ("Phone ringtone" to "ফোনের রিংটোন"),
    "phone_default" to ("Phone default" to "ফোনের ডিফল্ট"),
    "silent" to ("Silent" to "নীরব"),
    "s_privacy" to ("Privacy" to "প্রাইভেসি"),
    "s_privacy_s" to ("Blocked contacts" to "ব্লক করা তালিকা"),
    "s_notif" to ("Notifications & Sounds" to "নোটিফিকেশন ও সাউন্ড"),
    "s_notif_s" to ("Message tone, ringtone, vibrate" to "মেসেজ টোন, রিংটোন, ভাইব্রেশন"),
    "s_chats" to ("Chats" to "চ্যাট"),
    "s_chats_s" to ("Font size, wallpaper, dark mode" to "লেখার আকার, ওয়ালপেপার, ডার্ক মোড"),
    "s_help_s" to ("Help center, contact us" to "সাহায্য কেন্দ্র, যোগাযোগ"),
    "msg_notif" to ("Message notifications" to "মেসেজ নোটিফিকেশন"),
    "msg_tone" to ("Message tone" to "মেসেজ টোন"),
    "ringtone" to ("Ringtone" to "রিংটোন"),
    "vibrate" to ("Vibrate" to "ভাইব্রেশন"),
    "show_preview" to ("Show message preview" to "নোটিফিকেশনে মেসেজ দেখান"),
    "chat_sounds" to ("In-chat sounds" to "চ্যাটের ভেতরের শব্দ"),
    "chat_sounds_s" to ("Play a soft sound when a message arrives in an open chat" to "খোলা চ্যাটে মেসেজ এলে হালকা শব্দ হবে"),
    "font_size" to ("Font size" to "লেখার আকার"),
    "f_s" to ("Small" to "ছোট"),
    "f_m" to ("Medium" to "মাঝারি"),
    "f_l" to ("Large" to "বড়"),
    "wallpaper" to ("Chat wallpaper" to "চ্যাটের ওয়ালপেপার"),
    "enter_sends" to ("Enter key sends message" to "এন্টার চাপলে মেসেজ যাবে"),
    "clear_all" to ("Clear all chats" to "সব চ্যাট মুছুন"),
    "clear_all_q" to ("Messages in all chats will be removed from this account." to "সব চ্যাটের মেসেজ আপনার অ্যাকাউন্ট থেকে মুছে যাবে।"),
    "clear_chat" to ("Clear chat" to "চ্যাট মুছুন"),
    "clear_q" to ("Messages in this chat will be removed for you." to "এই চ্যাটের মেসেজ আপনার জন্য মুছে যাবে।"),
    "clear" to ("Clear" to "মুছুন"),
    "block" to ("Block" to "ব্লক"),
    "unblock" to ("Unblock" to "আনব্লক"),
    "block_q" to ("They won't be able to message or call you." to "সে আপনাকে আর মেসেজ বা কল দিতে পারবে না।"),
    "unblock_q" to ("They will be able to message and call you again." to "সে আবার আপনাকে মেসেজ ও কল দিতে পারবে।"),
    "blocked_list" to ("Blocked contacts" to "ব্লক করা তালিকা"),
    "no_blocked" to ("No one is blocked." to "কাউকে ব্লক করা হয়নি।"),
    "you_blocked" to ("You blocked this contact." to "আপনি এই ব্যক্তিকে ব্লক করেছেন।"),
    "cant_send" to ("You can't send messages to this person." to "এই ব্যক্তিকে মেসেজ পাঠানো যাবে না।"),
    "cant_call" to ("You can't call this person." to "এই ব্যক্তিকে কল করা যাবে না।"),
    "view_contact" to ("View contact" to "প্রোফাইল দেখুন"),
    "help_center" to ("Help center" to "সাহায্য কেন্দ্র"),
    "contact_us" to ("Contact us" to "যোগাযোগ করুন"),
    "app_info" to ("App info" to "অ্যাপের তথ্য"),
    "q1" to ("How do I add a friend?" to "কীভাবে বন্ধু যোগ করব?"),
    "a1" to ("Tap the add-friend button on the Chats page and type their mobile number." to "চ্যাট পেজের বন্ধু যোগ করার বোতাম চেপে তার মোবাইল নাম্বার লিখুন।"),
    "q2" to ("Do calls cost money?" to "কল করতে কি টাকা লাগে?"),
    "a2" to ("No. Calls and messages use only your internet data (Wi-Fi or mobile data)." to "না। কল আর মেসেজে শুধু ইন্টারনেট ডাটা খরচ হয় (Wi-Fi বা মোবাইল ডাটা)।"),
    "q3" to ("I don't get notifications." to "নোটিফিকেশন আসে না।"),
    "a3" to ("Turn on notifications for Golpo Chat in phone Settings, and set Battery to Unrestricted." to "ফোনের Settings-এ Golpo Chat-এর নোটিফিকেশন চালু করুন, আর Battery-তে Unrestricted দিন।"),
    "q4" to ("How do I block someone?" to "কাউকে কীভাবে ব্লক করব?"),
    "a4" to ("Open the chat, tap ⋮ at the top and choose Block." to "চ্যাট খুলে ওপরের ⋮ চেপে ব্লক বেছে নিন।"),
    "calling" to ("Calling…" to "কল যাচ্ছে…"),
    "in_audio" to ("Incoming voice call" to "অডিও কল আসছে"),
    "in_video" to ("Incoming video call" to "ভিডিও কল আসছে"),
    "connecting" to ("Connecting…" to "সংযোগ হচ্ছে…"),
    "c_declined" to ("Call declined" to "কলটি কেটে দেওয়া হয়েছে"),
    "c_busy" to ("On another call" to "অন্য কলে ব্যস্ত"),
    "c_noanswer" to ("No answer" to "কেউ ধরেনি"),
    "c_failed" to ("Call could not connect" to "কল সংযোগ হয়নি"),
    "c_ended" to ("Call ended" to "কল শেষ"),
    "missed_call" to ("Missed call" to "মিসড কল"),
    "voice_call" to ("Voice call" to "অডিও কল"),
    "video_call" to ("Video call" to "ভিডিও কল"),
    "accept" to ("Accept" to "ধরুন"),
    "decline" to ("Decline" to "কাটুন"),
    "mute" to ("Mute" to "মিউট"),
    "speaker" to ("Speaker" to "স্পিকার"),
    "camera" to ("Camera" to "ক্যামেরা"),
    "flip" to ("Flip" to "ঘোরান"),
    "end" to ("End" to "শেষ"),
    "mic_need_call" to ("Allow the microphone to make calls." to "কল করতে মাইক্রোফোনের অনুমতি দিন।"),
    "no_calls" to ("No calls yet. Open a chat and tap the call button." to "এখনো কোনো কল নেই। চ্যাট খুলে কল বোতাম চাপুন।"),
)

fun t(key: String): String {
    val e = S[key] ?: return key
    return if (Prefs.lang == "bn") e.second else e.first
}

private const val BN = "০১২৩৪৫৬৭৮৯"
fun num(s: String): String = if (Prefs.lang == "bn") s.map { if (it in '0'..'9') BN[it - '0'] else it }.joinToString("") else s

fun clock(ms: Long): String = num(SimpleDateFormat("HH:mm", Locale.US).format(Date(ms)))

fun dayLabel(ms: Long): String {
    val c = Calendar.getInstance(); val n = Calendar.getInstance(); c.timeInMillis = ms
    val sameDay = { a: Calendar, b: Calendar -> a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR) }
    if (sameDay(c, n)) return t("today")
    n.add(Calendar.DAY_OF_YEAR, -1)
    if (sameDay(c, n)) return t("yesterday")
    return num(SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(ms)))
}

fun shortTime(ms: Long): String {
    if (ms <= 0) return ""
    val d = dayLabel(ms)
    return if (d == t("today")) clock(ms) else d
}

fun lastSeenText(ms: Long): String {
    if (ms <= 0) return ""
    val d = dayLabel(ms)
    return t("last_seen") + " " + (if (d == t("today")) clock(ms) else d + " " + clock(ms))
}

// ---------------------------------------------------------------- icons (Material paths)
private val PATHS = mapOf(
    "search" to "M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z",
    "call" to "M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z",
    "video" to "M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z",
    "back" to "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z",
    "send" to "M2.01 21L23 12 2.01 3 2 10l15 2-15 2z",
    "mic" to "M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z",
    "camera" to "M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4zM9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z",
    "image" to "M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z",
    "more" to "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z",
    "chat" to "M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 9h12v2H6V9zm8 5H6v-2h8v2zm4-6H6V6h12v2z",
    "gear" to "M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.488.488 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z",
    "add" to "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z",
    "check" to "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z",
    "check2" to "M18 7l-1.41-1.41-6.34 6.34 1.41 1.41L18 7zm4.24-1.41L11.66 16.17 7.48 12l-1.41 1.41L11.66 19l12-12-1.42-1.41zM.41 13.41L6 19l1.41-1.41L1.83 12 .41 13.41z",
    "clock" to "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z",
    "play" to "M8 5v14l11-7z",
    "pause" to "M6 19h4V5H6v14zm8-14v14h4V5h-4z",
    "lock" to "M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z",
    "bell" to "M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z",
    "moon" to "M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 0 1-4.4 2.26 5.403 5.403 0 0 1-3.14-9.8c-.44-.06-.9-.1-1.36-.1z",
    "call_end" to "M12 9c-1.6 0-3.15.25-4.6.72v3.1c0 .39-.23.74-.56.9-.98.49-1.87 1.12-2.66 1.85-.18.18-.43.28-.7.28-.28 0-.53-.11-.71-.29L.29 13.08a.956.956 0 0 1-.29-.7c0-.28.11-.53.29-.71C3.34 8.78 7.46 7 12 7s8.66 1.78 11.71 4.67c.18.18.29.43.29.71 0 .28-.11.53-.29.71l-2.48 2.48c-.18.18-.43.29-.71.29-.27 0-.52-.11-.7-.28a11.27 11.27 0 0 0-2.67-1.85.996.996 0 0 1-.56-.9v-3.1C15.15 9.25 13.6 9 12 9z",
    "mic_off" to "M19 11h-1.7c0 .74-.16 1.43-.43 2.05l1.23 1.23c.56-.98.9-2.09.9-3.28zm-4.02.17c0-.06.02-.11.02-.17V5c0-1.66-1.34-3-3-3S9 3.34 9 5v.18l5.98 5.99zM4.27 3L3 4.27l6.01 6.01V11c0 1.66 1.33 3 2.99 3 .22 0 .44-.03.65-.08l1.66 1.66c-.71.33-1.5.52-2.31.52-2.76 0-5.3-2.1-5.3-5.1H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c.91-.13 1.77-.45 2.54-.9L19.73 21 21 19.73 4.27 3z",
    "volume" to "M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z",
    "video_off" to "M21 6.5l-4 4V7c0-.55-.45-1-1-1H9.82L21 17.18V6.5zM3.27 2L2 3.27 4.73 6H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.21 0 .39-.08.54-.18L19.73 21 21 19.73 3.27 2z",
    "flip" to "M20 4h-3.17L15 2H9L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-5 11.5V13H9v2.5L5.5 12 9 8.5V11h6V8.5l3.5 3.5-3.5 3.5z",
    "call_made" to "M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5z",
    "call_received" to "M20 5.41L18.59 4 7 15.59V9H5v10h10v-2H8.41z",
    "call_missed" to "M19.59 7L12 14.59 6.41 9H11V7H3v8h2v-4.59l7 7 9-9z",
    "block" to "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM4 12c0-4.42 3.58-8 8-8 1.85 0 3.55.63 4.9 1.69L5.69 16.9A7.902 7.902 0 0 1 4 12zm8 8c-1.85 0-3.55-.63-4.9-1.69L18.31 7.1A7.902 7.902 0 0 1 20 12c0 4.42-3.58 8-8 8z",
    "font" to "M2.5 4v3h5v12h3V7h5V4h-13zm19 5h-9v3h3v7h3v-7h3V9z",
    "wallpaper" to "M4 4h7V2H4c-1.1 0-2 .9-2 2v7h2V4zm6 9l-4 5h12l-3-4-2.03 2.71L10 13zm7-4.5c0-.83-.67-1.5-1.5-1.5S14 7.67 14 8.5s.67 1.5 1.5 1.5S17 9.33 17 8.5zM20 2h-7v2h7v7h2V4c0-1.1-.9-2-2-2zm0 18h-7v2h7c1.1 0 2-.9 2-2v-7h-2v7zM4 13H2v7c0 1.1.9 2 2 2h7v-2H4v-7z",
    "enter" to "M19 7v4H5.83l3.58-3.59L8 6l-6 6 6 6 1.41-1.41L5.83 13H21V7z",
    "music" to "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z",
    "vibration" to "M0 15h2V9H0v6zm3 2h2V7H3v10zm19-8v6h2V9h-2zm-3 8h2V7h-2v10zM16.5 3h-9C6.67 3 6 3.67 6 4.5v15c0 .83.67 1.5 1.5 1.5h9c.83 0 1.5-.67 1.5-1.5v-15c0-.83-.67-1.5-1.5-1.5zM16 19H8V5h8v14z",
    "eye" to "M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z",
    "mail" to "M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z",
    "info" to "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z",
    "right" to "M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z",
    "o_image" to "M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-4.86 8.86l-3 3.87L9 13.14 6 17h12l-3.86-5.14z",
    "o_palette" to "M12 22C6.49 22 2 17.51 2 12S6.49 2 12 2s10 4.04 10 9c0 3.31-2.69 6-6 6h-1.77c-.28 0-.5.22-.5.5 0 .12.05.23.13.33.41.47.64 1.06.64 1.67A2.5 2.5 0 0 1 12 22zm0-18c-4.41 0-8 3.59-8 8s3.59 8 8 8c.28 0 .5-.22.5-.5a.54.54 0 0 0-.14-.35c-.41-.46-.63-1.05-.63-1.65a2.5 2.5 0 0 1 2.5-2.5H16c2.21 0 4-1.79 4-4 0-3.86-3.59-7-8-7zM6.5 10a1.5 1.5 0 1 0 3 0 1.5 1.5 0 1 0-3 0zM9.5 6.5a1.5 1.5 0 1 0 3 0 1.5 1.5 0 1 0-3 0zM14.5 6.5a1.5 1.5 0 1 0 3 0 1.5 1.5 0 1 0-3 0zM16 10.5a1.5 1.5 0 1 0 3 0 1.5 1.5 0 1 0-3 0z",
    "o_shortcut" to "M19 19H5V5h7V3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z",
    "o_star" to "M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z",
    "star" to "M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z",
    "o_mute" to "M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68c-.24.06-.47.15-.69.23L18 13.1V11zM5.41 3.35L4 4.76l2.81 2.81C6.29 8.57 6 9.73 6 11v5l-2 2v1h14.24l1.74 1.74 1.41-1.41L5.41 3.35z",
    "o_call" to "M6.54 5c.06.89.21 1.76.45 2.59l-1.2 1.2c-.41-1.2-.67-2.47-.76-3.79h1.51m9.86 12.02c.85.24 1.72.39 2.6.45v1.49c-1.32-.09-2.59-.35-3.8-.75l1.2-1.19M7.5 3H4c-.55 0-1 .45-1 1 0 9.39 7.61 17 17 17 .55 0 1-.45 1-1v-3.49c0-.55-.45-1-1-1-1.24 0-2.45-.2-3.57-.57a.84.84 0 0 0-.31-.05c-.26 0-.51.1-.71.29l-2.2 2.2a15.149 15.149 0 0 1-6.59-6.59l2.2-2.2c.28-.28.36-.67.25-1.02A11.36 11.36 0 0 1 8.5 4c0-.55-.45-1-1-1z",
    "o_video" to "M15 8v8H5V8h10m1-2H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4V7c0-.55-.45-1-1-1z",
    "o_eye_off" to "M12 6a9.77 9.77 0 0 1 8.82 5.5 9.647 9.647 0 0 1-2.41 3.12l1.41 1.41c1.39-1.23 2.49-2.77 3.18-4.53C21.27 7.11 17 4 12 4c-1.27 0-2.49.2-3.64.57l1.65 1.65C10.66 6.09 11.32 6 12 6zm-1.07 1.14L13 9.21c.57.25 1.03.71 1.28 1.28l2.07 2.07c.08-.34.14-.7.14-1.07C16.5 9.01 14.48 7 12 7c-.37 0-.72.05-1.07.14zM2.01 3.87l2.68 2.68A11.738 11.738 0 0 0 1 11.5C2.73 15.89 7 19 12 19c1.52 0 2.98-.29 4.32-.82l3.42 3.42 1.41-1.41L3.42 2.45 2.01 3.87zm7.5 7.5l2.61 2.61c-.04.01-.08.02-.12.02a2.5 2.5 0 0 1-2.5-2.5c0-.05.01-.08.01-.13zm-3.4-3.4l1.75 1.75a4.6 4.6 0 0 0-.36 1.78 4.507 4.507 0 0 0 6.27 4.14l.98.98c-.88.24-1.8.38-2.75.38a9.77 9.77 0 0 1-8.82-5.5c.7-1.43 1.72-2.61 2.93-3.53z",
    "o_person" to "M12 6c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2m0 10c2.7 0 5.8 1.29 6 2H6c.23-.72 3.31-2 6-2m0-12C9.79 4 8 5.79 8 8s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm0 10c-2.67 0-8 1.34-8 4v3h16v-3c0-2.66-5.33-4-8-4z",
    "o_delete" to "M16 9v10H8V9h8m-1.5-6h-5l-1 1H5v2h14V4h-3.5l-1-1zM18 7H6v12c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7z",
    "o_flag" to "M14 6l-1-2H5v17h2v-7h5l1 2h7V6h-6zm4 8h-4l-1-2H7V6h5l1 2h5v6z",
    "o_chat" to "M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z",
    "group" to "M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z",
    "group_add" to "M8 10H5V7H3v3H0v2h3v3h2v-3h3v-2zm10 1c1.66 0 2.99-1.34 2.99-3S19.66 5 18 5c-.32 0-.63.05-.91.14.57.81.9 1.79.9 2.86s-.34 2.04-.9 2.86c.28.09.59.14.91.14zm-5 0c1.66 0 2.99-1.34 2.99-3S14.66 5 13 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm6.62 2.16c.83.73 1.38 1.66 1.38 2.84v2h3v-2c0-1.54-2.37-2.49-4.38-2.84zM13 13c-2 0-6 1-6 3v2h12v-2c0-2-4-3-6-3z",
    "person_add" to "M15 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm-9-2V7H4v3H1v2h3v3h2v-3h3v-2H6zm9 4c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z",
    "person" to "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z",
    "close" to "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z",
    "reply" to "M10 9V5l-7 7 7 7v-4.1c5 0 8.5 1.6 11 5.1-1-5-4-10-11-11z",
    "del" to "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z",
    "copy" to "M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z",
    "help" to "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z",
    "share" to "M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z",
    "lang" to "M12.87 15.07l-2.54-2.51.03-.03A17.52 17.52 0 0 0 14.07 6H17V4h-7V2H8v2H1v1.99h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z",
    "logout" to "M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z",
    "edit" to "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a.996.996 0 0 0 0-1.41l-2.34-2.34a.996.996 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z",
    "emoji" to "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z",
    "down" to "M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z",
)

private val iconCache = HashMap<String, ImageVector>()

fun icon(name: String): ImageVector = iconCache.getOrPut(name) {
    ImageVector.Builder(name = name, defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
        .addPath(pathData = addPathNodes(PATHS[name] ?: PATHS.getValue("help")), fill = SolidColor(Color.Black))
        .build()
}

@Composable
fun Ic(name: String, tint: Color = P.tx, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Icon(icon(name), contentDescription = null, modifier = modifier.size(size), tint = tint)
}

// ---------------------------------------------------------------- avatar
private val AV = listOf(
    Color(0xFFFF8FA3) to Color(0xFFFF4D79), Color(0xFF4FACFE) to Color(0xFF0082E6),
    Color(0xFF43E97B) to Color(0xFF13B58A), Color(0xFFF6D365) to Color(0xFFFDA085),
    Color(0xFFA18CD1) to Color(0xFFD36BD8), Color(0xFFFA709A) to Color(0xFFF5A623),
    Color(0xFF30CFD0) to Color(0xFF5B4BDB), Color(0xFF6C4DF6) to Color(0xFF22C9A5),
)

@Composable
fun Avatar(name: String, photo: String, seed: String, size: Dp, online: Boolean = false, onClick: (() -> Unit)? = null) {
    Box(Modifier.size(size)) {
        val c = AV[(seed.hashCode() and 0x7fffffff) % AV.size]
        var m = Modifier.size(size).clip(CircleShape)
        if (onClick != null) m = m.clickable { onClick() }
        Box(m.background(Brush.linearGradient(listOf(c.first, c.second))), contentAlignment = Alignment.Center) {
            val first = name.trim().firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "?"
            Text(first, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp)
            if (photo.isNotEmpty()) {
                AsyncImage(model = photo, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(size).clip(CircleShape))
            }
        }
        if (online) {
            Box(
                Modifier.align(Alignment.BottomEnd).size(size * 0.26f).clip(CircleShape).background(P.bg)
                    .padding(2.dp).clip(CircleShape).background(Green)
            )
        }
    }
}
