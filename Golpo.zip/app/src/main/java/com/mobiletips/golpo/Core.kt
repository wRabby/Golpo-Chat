package com.mobiletips.golpo

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- colours
val Brand = Color(0xFF6C4DF6)
val Mint = Color(0xFF22C9A5)
val Red = Color(0xFFFF3B5C)
val Green = Color(0xFF1FCB6A)
val Blue = Color(0xFF3BA4FF)
val Grad = Brush.linearGradient(listOf(Color(0xFF6C4DF6), Color(0xFF9B6BFF), Color(0xFF22C9A5)))

class Pal(
    val bg: Color, val bg2: Color, val card: Color, val tx: Color, val tx2: Color,
    val ln: Color, val inB: Color, val outB: Color, val wall: Color, val pill: Color,
)

val LightPal = Pal(
    Color.White, Color(0xFFF4F2FB), Color.White, Color(0xFF17142A), Color(0xFF6E6A85),
    Color(0xFFECEAF4), Color.White, Color(0xFFEAE4FF), Color(0xFFF1EEFA), Color(0xFFEAE4FF),
)
val DarkPal = Pal(
    Color(0xFF0F0E17), Color(0xFF1A1826), Color(0xFF1C1A29), Color(0xFFF2F0FA), Color(0xFF9A96B0),
    Color(0xFF2A2738), Color(0xFF22202F), Color(0xFF3B2F86), Color(0xFF14121E), Color(0xFF2F2760),
)
val P: Pal get() = if (Prefs.dark) DarkPal else LightPal

// ---------------------------------------------------------------- saved settings
object Prefs {
    lateinit var sp: SharedPreferences
    var lang by mutableStateOf("en")
    var dark by mutableStateOf(false)

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.getSharedPreferences("golpo", Context.MODE_PRIVATE)
        lang = sp.getString("lang", "en") ?: "en"
        dark = sp.getBoolean("dark", false)
    }

    fun toggleLang() {
        lang = if (lang == "en") "bn" else "en"
        sp.edit().putString("lang", lang).apply()
    }

    fun setDarkMode(v: Boolean) {
        dark = v
        sp.edit().putBoolean("dark", v).apply()
    }
}

// ---------------------------------------------------------------- language (English first, Bangla on tap)
private val S = mapOf(
    "tag" to ("Chat & Video Call" to "চ্যাট ও ভিডিও কল"),
    "welcome_t" to ("Welcome to Golpo Chat" to "Golpo Chat-এ স্বাগতম"),
    "welcome_s" to ("Free chat, voice & video calls with your friends and family — fast and secure." to "বন্ধু ও পরিবারের সাথে ফ্রি চ্যাট, অডিও ও ভিডিও কল — দ্রুত আর নিরাপদ।"),
    "agree" to ("By tapping Start you agree to our Terms and Privacy Policy." to "শুরু করুন চাপলে আপনি আমাদের শর্তাবলি ও প্রাইভেসি পলিসিতে সম্মত হচ্ছেন।"),
    "start" to ("Start" to "শুরু করুন"),
    "phone_t" to ("Your phone number" to "আপনার মোবাইল নাম্বার"),
    "phone_s" to ("We will send a 6-digit code to this number by SMS." to "এই নাম্বারে ৬ সংখ্যার একটা কোড SMS-এ যাবে।"),
    "bd" to ("Bangladesh" to "বাংলাদেশ"),
    "next" to ("Next" to "পরবর্তী"),
    "confirm_num" to ("Is this number correct? We will send the code here." to "নাম্বারটা কি ঠিক আছে? এই নাম্বারে কোড পাঠানো হবে।"),
    "yes" to ("Yes" to "হ্যাঁ, ঠিক আছে"),
    "edit" to ("Edit" to "বদলাবো"),
    "cancel" to ("Cancel" to "বাতিল"),
    "save" to ("Save" to "সেভ করুন"),
    "otp_t" to ("Enter the code" to "কোডটা লিখুন"),
    "otp_sent" to ("Code sent to" to "কোড পাঠানো হয়েছে"),
    "wrong_num" to ("Wrong number?" to "নাম্বার ভুল?"),
    "waiting" to ("Waiting for SMS… the code fills in by itself" to "SMS-এর অপেক্ষায়… কোড নিজে থেকেই বসে যাবে"),
    "resend_in" to ("Resend code in" to "আবার কোড পাঠানো যাবে"),
    "resend" to ("Resend SMS" to "আবার SMS পাঠান"),
    "verifying" to ("Verifying…" to "যাচাই হচ্ছে…"),
    "e_wrong_code" to ("Wrong code. Please try again." to "কোড ভুল হয়েছে, আবার চেষ্টা করুন।"),
    "e_expired" to ("The code has expired. Tap Resend SMS." to "কোডের মেয়াদ শেষ। আবার SMS পাঠান চাপুন।"),
    "e_too_many" to ("Too many tries. Please try later." to "অনেকবার চেষ্টা হয়েছে, পরে আবার চেষ্টা করুন।"),
    "e_wait" to ("Please wait a little before asking again." to "আবার চাওয়ার আগে একটু অপেক্ষা করুন।"),
    "e_limit" to ("Daily code limit reached. Try tomorrow." to "আজকের কোডের সীমা শেষ, কাল আবার চেষ্টা করুন।"),
    "e_bad_number" to ("Enter a valid Bangladeshi mobile number." to "সঠিক বাংলাদেশি মোবাইল নাম্বার দিন।"),
    "e_net" to ("Cannot reach the server. Check your internet." to "সার্ভারের সাথে যোগাযোগ হচ্ছে না। ইন্টারনেট দেখুন।"),
    "e_server" to ("The server is not ready yet. Please try later." to "সার্ভার এখনো প্রস্তুত না, পরে চেষ্টা করুন।"),
    "e_login" to ("Login failed. Please try again." to "লগইন হয়নি, আবার চেষ্টা করুন।"),
    "prof_t" to ("Profile info" to "প্রোফাইল সেট করুন"),
    "prof_s" to ("Add your name and an optional photo" to "আপনার নাম আর চাইলে একটা ছবি দিন"),
    "your_name" to ("Your name" to "আপনার নাম"),
    "about" to ("About" to "সম্পর্কে"),
    "about_def" to ("Hey there! I am using Golpo Chat" to "আমি Golpo Chat ব্যবহার করছি"),
    "tap_photo" to ("Tap the photo to change it" to "ছবিতে চাপলে বদলাবে"),
    "setting_up" to ("Setting up…" to "সব রেডি করা হচ্ছে…"),
    "chats" to ("Chats" to "চ্যাট"),
    "calls" to ("Calls" to "কল"),
    "settings" to ("Settings" to "সেটিংস"),
    "search" to ("Search name or number…" to "নাম বা নাম্বার খুঁজুন…"),
    "all" to ("All" to "সব"),
    "unread" to ("Unread" to "অপঠিত"),
    "no_chats" to ("No chats yet. Tap + to start one." to "এখনো কোনো চ্যাট নেই। + চেপে শুরু করুন।"),
    "new_chat" to ("New chat" to "নতুন চ্যাট"),
    "on_golpo" to ("People on Golpo Chat" to "Golpo Chat-এ যারা আছেন"),
    "nobody" to ("Nobody else has joined yet. Invite your friends!" to "এখনো আর কেউ যোগ দেয়নি। বন্ধুদের আমন্ত্রণ জানান!"),
    "invite" to ("Invite a friend" to "বন্ধুকে আমন্ত্রণ"),
    "invite_text" to ("Let's chat on Golpo Chat! Download it here: https://play.google.com/store/apps/details?id=com.mobiletips.golpo" to "চলো Golpo Chat-এ কথা বলি! এখান থেকে নামাও: https://play.google.com/store/apps/details?id=com.mobiletips.golpo"),
    "contacts" to ("contacts" to "জন"),
    "online" to ("online" to "অনলাইন"),
    "typing" to ("typing…" to "টাইপ করছে…"),
    "last_seen" to ("last seen" to "শেষ দেখা"),
    "today" to ("Today" to "আজ"),
    "yesterday" to ("Yesterday" to "গতকাল"),
    "type_msg" to ("Message" to "মেসেজ লিখুন"),
    "photo" to ("📷 Photo" to "📷 ছবি"),
    "voice" to ("🎤 Voice message" to "🎤 ভয়েস মেসেজ"),
    "deleted_me" to ("🚫 You deleted this message" to "🚫 আপনি মেসেজটি মুছে ফেলেছেন"),
    "deleted" to ("🚫 This message was deleted" to "🚫 এই মেসেজটি মুছে ফেলা হয়েছে"),
    "recording" to ("Recording…" to "রেকর্ড হচ্ছে…"),
    "reply" to ("Reply" to "রিপ্লাই"),
    "copy" to ("Copy" to "কপি"),
    "copied" to ("Copied" to "কপি হয়েছে"),
    "del_all" to ("Delete for everyone" to "সবার জন্য মুছুন"),
    "you" to ("You" to "আপনি"),
    "sending" to ("Sending…" to "পাঠানো হচ্ছে…"),
    "e_send" to ("Could not send. Please try again." to "পাঠানো যায়নি, আবার চেষ্টা করুন।"),
    "mic_need" to ("Allow the microphone to record voice messages." to "ভয়েস রেকর্ড করতে মাইক্রোফোনের অনুমতি দিন।"),
    "calls_t" to ("Voice & video calls are coming" to "অডিও আর ভিডিও কল আসছে"),
    "calls_s" to ("Calls arrive in the next update. Chat is ready to use now!" to "পরের আপডেটে কল আসবে। এখন চ্যাট ব্যবহার করুন!"),
    "calls_soon" to ("Calls are coming in the next update" to "কল পরের আপডেটে আসবে"),
    "lang" to ("App language" to "অ্যাপের ভাষা"),
    "lang_now" to ("English" to "বাংলা"),
    "dark" to ("Dark mode" to "ডার্ক মোড"),
    "profile" to ("Profile" to "প্রোফাইল"),
    "phone" to ("Phone" to "ফোন"),
    "logout" to ("Log out" to "লগআউট"),
    "logout_q" to ("You will need a new SMS code to log in again." to "আবার ঢুকতে নতুন SMS কোড লাগবে।"),
    "help" to ("Help & support" to "সাহায্য"),
    "notif_t" to ("Notifications" to "নোটিফিকেশন"),
    "notif_s" to ("Allow notifications so you never miss a message." to "নোটিফিকেশন চালু রাখুন, যাতে কোনো মেসেজ মিস না হয়।"),
    "new_msg" to ("New message" to "নতুন মেসেজ"),
)

fun t(key: String): String {
    val e = S[key] ?: return key
    return if (Prefs.lang == "bn") e.second else e.first
}

private const val BN = "০১২৩৪৫৬৭৮৯"
fun num(s: String): String = if (Prefs.lang == "bn") s.map { if (it in '0'..'9') BN[it - '0'] else it }.joinToString("") else s

fun clock(ms: Long): String = num(SimpleDateFormat("HH:mm", Locale.US).format(Date(ms)))

fun dayLabel(ms: Long): String {
    val c = Calendar.getInstance(); val n = Calendar.getInstance(); c.timeInMillis = ms
    val sameDay = { a: Calendar, b: Calendar -> a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR) }
    if (sameDay(c, n)) return t("today")
    n.add(Calendar.DAY_OF_YEAR, -1)
    if (sameDay(c, n)) return t("yesterday")
    return num(SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(ms)))
}

fun shortTime(ms: Long): String {
    if (ms <= 0) return ""
    val d = dayLabel(ms)
    return if (d == t("today")) clock(ms) else d
}

fun lastSeenText(ms: Long): String {
    if (ms <= 0) return ""
    val d = dayLabel(ms)
    return t("last_seen") + " " + (if (d == t("today")) clock(ms) else d + " " + clock(ms))
}

// ---------------------------------------------------------------- icons (Material paths)
private val PATHS = mapOf(
    "search" to "M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z",
    "call" to "M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z",
    "video" to "M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z",
    "back" to "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z",
    "send" to "M2.01 21L23 12 2.01 3 2 10l15 2-15 2z",
    "mic" to "M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z",
    "camera" to "M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4zM9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z",
    "image" to "M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z",
    "more" to "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z",
    "chat" to "M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 9h12v2H6V9zm8 5H6v-2h8v2zm4-6H6V6h12v2z",
    "gear" to "M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.488.488 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z",
    "add" to "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z",
    "check" to "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z",
    "check2" to "M18 7l-1.41-1.41-6.34 6.34 1.41 1.41L18 7zm4.24-1.41L11.66 16.17 7.48 12l-1.41 1.41L11.66 19l12-12-1.42-1.41zM.41 13.41L6 19l1.41-1.41L1.83 12 .41 13.41z",
    "clock" to "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z",
    "play" to "M8 5v14l11-7z",
    "pause" to "M6 19h4V5H6v14zm8-14v14h4V5h-4z",
    "lock" to "M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z",
    "bell" to "M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z",
    "moon" to "M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 0 1-4.4 2.26 5.403 5.403 0 0 1-3.14-9.8c-.44-.06-.9-.1-1.36-.1z",
    "person" to "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z",
    "close" to "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z",
    "reply" to "M10 9V5l-7 7 7 7v-4.1c5 0 8.5 1.6 11 5.1-1-5-4-10-11-11z",
    "del" to "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z",
    "copy" to "M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z",
    "help" to "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z",
    "share" to "M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z",
    "lang" to "M12.87 15.07l-2.54-2.51.03-.03A17.52 17.52 0 0 0 14.07 6H17V4h-7V2H8v2H1v1.99h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z",
    "logout" to "M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z",
    "edit" to "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a.996.996 0 0 0 0-1.41l-2.34-2.34a.996.996 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z",
    "emoji" to "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z",
    "down" to "M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z",
)

private val iconCache = HashMap<String, ImageVector>()

fun icon(name: String): ImageVector = iconCache.getOrPut(name) {
    ImageVector.Builder(name = name, defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
        .addPath(pathData = addPathNodes(PATHS[name] ?: PATHS.getValue("help")), fill = SolidColor(Color.Black))
        .build()
}

@Composable
fun Ic(name: String, tint: Color = P.tx, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Icon(icon(name), contentDescription = null, modifier = modifier.size(size), tint = tint)
}

// ---------------------------------------------------------------- avatar
private val AV = listOf(
    Color(0xFFFF8FA3) to Color(0xFFFF4D79), Color(0xFF4FACFE) to Color(0xFF0082E6),
    Color(0xFF43E97B) to Color(0xFF13B58A), Color(0xFFF6D365) to Color(0xFFFDA085),
    Color(0xFFA18CD1) to Color(0xFFD36BD8), Color(0xFFFA709A) to Color(0xFFF5A623),
    Color(0xFF30CFD0) to Color(0xFF5B4BDB), Color(0xFF6C4DF6) to Color(0xFF22C9A5),
)

@Composable
fun Avatar(name: String, photo: String, seed: String, size: Dp, online: Boolean = false, onClick: (() -> Unit)? = null) {
    Box(Modifier.size(size)) {
        val c = AV[(seed.hashCode() and 0x7fffffff) % AV.size]
        var m = Modifier.size(size).clip(CircleShape)
        if (onClick != null) m = m.clickable { onClick() }
        Box(m.background(Brush.linearGradient(listOf(c.first, c.second))), contentAlignment = Alignment.Center) {
            val first = name.trim().firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "?"
            Text(first, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp)
            if (photo.isNotEmpty()) {
                AsyncImage(model = photo, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(size).clip(CircleShape))
            }
        }
        if (online) {
            Box(
                Modifier.align(Alignment.BottomEnd).size(size * 0.26f).clip(CircleShape).background(P.bg)
                    .padding(2.dp).clip(CircleShape).background(Green)
            )
        }
    }
}
