package com.mobiletips.golpo

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import kotlin.math.roundToInt

class CallActivity : ComponentActivity() {
    private val answerNow = mutableStateOf(false)
    private val inPip = mutableStateOf(false)
    private var leaving = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()
        answerNow.value = intent?.action == "answer"
        if (!CallManager.busy) { finish(); return }
        addOnPictureInPictureModeChangedListener { inPip.value = it.isInPictureInPictureMode }
        setContent { CallUi(answerNow, inPip.value, minimize = { minimize() }, leave = { leaving = true; finish() }) { finish() } }
    }

    private fun minimize() { leaving = true; openApp(this); finish() }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!leaving && Build.VERSION.SDK_INT in 26..30 && callLive()) Pip.enter(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == "answer") answerNow.value = true
    }
}

@Composable
private fun CallUi(answerNow: MutableState<Boolean>, inPip: Boolean, minimize: () -> Unit, leave: () -> Unit, close: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx as? android.app.Activity
    val m = CallManager
    val ph = m.phase
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var swapped by remember { mutableStateOf(false) }      // true = my camera is the big one
    var showCtl by remember { mutableStateOf(true) }
    var corner by remember { mutableIntStateOf(1) }        // 0 TL, 1 TR, 2 BL, 3 BR
    var drag by remember { mutableStateOf(Offset.Zero) }
    var adding by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    var listing by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    LaunchedEffect(ph) {
        if (act != null) Pip.auto(act, ph == CallPhase.Active || ph == CallPhase.Connecting || ph == CallPhase.Outgoing)
        if (ph == CallPhase.Idle) close()
        if (ph == CallPhase.Ended) { delay(1400); close() }
    }
    BackHandler(!inPip) { if (ph == CallPhase.Incoming) m.decline() else minimize() }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val mic = r[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (mic) m.accept() else Toast.makeText(ctx, t("mic_need_call"), Toast.LENGTH_LONG).show()
    }
    fun accept() {
        val p = if (m.video) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA) else arrayOf(Manifest.permission.RECORD_AUDIO)
        perm.launch(p)
    }
    LaunchedEffect(answerNow.value) {
        if (answerNow.value && m.phase == CallPhase.Incoming) { answerNow.value = false; accept() }
    }
    // a voice call turns into a video call: both of us move to the meeting room with my camera on
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) toast(ctx, t("cam_need"))
        else if (m.phase == CallPhase.Active) { m.handOver(ctx, emptyList(), video = true); leave() }
    }
    fun videoBtn() {
        if (m.video) { m.toggleCam(); showCtl = true; return }
        if (m.phase != CallPhase.Active) return
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            m.handOver(ctx, emptyList(), video = true); leave()
        } else camPerm.launch(Manifest.permission.CAMERA)
    }
    // share my screen: the call moves to the meeting room, then the screen goes out
    val proj = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == android.app.Activity.RESULT_OK && d != null && m.phase == CallPhase.Active) {
            GroupCall.pendingShare = d
            m.handOver(ctx, emptyList())
            leave()
        }
    }
    fun shareBtn() {
        if (m.phase != CallPhase.Active) { toast(ctx, t("connecting")); return }
        try { proj.launch(ctx.getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent()) }
        catch (_: Exception) { toast(ctx, t("share_fail")) }
    }

    val remote = m.remoteVideo
    val local = if (m.camOn) m.localVideo else null
    val live = ph == CallPhase.Active && remote != null && m.video
    // what goes full screen and what goes in the small window
    val big: VideoTrack? = when {
        !m.video || ph == CallPhase.Ended -> null
        live -> if (swapped && local != null) local else remote
        ph != CallPhase.Incoming -> local          // before the other side answers: my own camera, full screen
        else -> null
    }
    val small: VideoTrack? = if (live) (if (big === local) remote else local) else null
    val immersive = live && !showCtl
    LaunchedEffect(showCtl, live) { if (showCtl && live) { delay(6000); showCtl = false } }

    if (inPip) { OnePipContent(now); return }

    BoxWithConstraints(Modifier.fillMaxSize().background(CallBg)) {
        val density = LocalDensity.current
        val wPx = with(density) { maxWidth.toPx() }
        val hPx = with(density) { maxHeight.toPx() }
        val sw = with(density) { 108.dp.toPx() }
        val sh = with(density) { 156.dp.toPx() }
        val pad = with(density) { 14.dp.toPx() }
        val topPad = with(density) { 90.dp.toPx() }
        val botPad = with(density) { if (showCtl) 290.dp.toPx() else 30.dp.toPx() }
        fun cornerPos(c: Int) = Offset(
            if (c % 2 == 0) pad else wPx - sw - pad,
            if (c < 2) topPad else hPx - sh - botPad,
        )

        if (big != null) {
            key(big, false) { VideoView(big, mirror = big === local && m.front, overlay = false, modifier = Modifier.fillMaxSize()) }
            if (live) Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = if (showCtl) .35f else 0f), Color.Transparent, Color.Black.copy(alpha = if (showCtl) .45f else 0f)))))
        }
        // tap anywhere on the video: show / hide the buttons
        Box(Modifier.fillMaxSize().pointerInput(live) { detectTapGestures { if (live) showCtl = !showCtl } })

        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            if (!immersive) {
                CallTop(m.peerName.ifBlank { "Golpo Chat" }, statusText(ph, now), onMin = minimize,
                    onAdd = if (ph == CallPhase.Active) ({ adding = true }) else null)
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                if (big == null && !immersive) {
                    Box(Modifier.size(170.dp).clip(androidx.compose.foundation.shape.CircleShape)
                        .border(3.dp, Brush.linearGradient(listOf(Color(0xFF3CB8FF), Mint)), androidx.compose.foundation.shape.CircleShape).padding(6.dp)) {
                        Avatar(m.peerName.ifBlank { "?" }, m.peerPhoto, m.peer, 158.dp)
                    }
                }
            }
            if (ph == CallPhase.Incoming) {
                AnswerRow(m.video, onDecline = { m.decline() }, onAccept = { accept() })
            } else if (ph != CallPhase.Ended && !immersive) {
                CallPanel(
                    speaker = m.speaker, videoOn = m.video && m.camOn, muted = m.muted, sharing = false,
                    onSpeaker = { m.toggleSpeaker(); showCtl = true }, onVideo = { videoBtn() }, onMute = { m.toggleMute(); showCtl = true },
                    onMore = { more = true }, onShare = { shareBtn() }, onEnd = { m.hangup() },
                )
                Spacer(Modifier.height(8.dp))
            } else if (ph == CallPhase.Ended) {
                Spacer(Modifier.height(140.dp))
            }
        }

        // ---- small window: tap = swap, drag = move to any corner
        if (small != null) {
            val base = cornerPos(corner)
            key(small, true) {
                Box(
                    Modifier
                        .offset { IntOffset((base.x + drag.x).roundToInt(), (base.y + drag.y).roundToInt()) }
                        .size(108.dp, 156.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(2.dp, Color.White.copy(alpha = .7f), RoundedCornerShape(16.dp))
                        .background(Color.Black)
                ) {
                    VideoView(small, mirror = small === local && m.front, overlay = true, modifier = Modifier.fillMaxSize())
                    Box(
                        Modifier.fillMaxSize()
                            .pointerInput(Unit) { detectTapGestures { swapped = !swapped } }
                            .pointerInput(wPx, hPx, botPad) {
                                detectDragGestures(
                                    onDragEnd = {
                                        val p = cornerPos(corner) + drag
                                        val cx = p.x + sw / 2; val cy = p.y + sh / 2
                                        corner = (if (cy < hPx / 2) 0 else 2) + (if (cx < wPx / 2) 0 else 1)
                                        drag = Offset.Zero
                                    },
                                    onDragCancel = { drag = Offset.Zero },
                                ) { ch, d -> ch.consume(); drag += d }
                            }
                    )
                }
            }
        }
    }
    if (more) BottomSheet(onDismiss = { more = false }, dark = true) {
        if (m.video && m.camOn) SheetRow("flip", t("flip_camera"), dark = true) { more = false; m.flipCam() }
        SheetRow("group", t("in_call_list") + " (" + num("2") + ")", dark = true) { more = false; listing = true }
        SheetRow("person_add", t("add_people"), dark = true) { more = false; if (ph == CallPhase.Active) adding = true else toast(ctx, t("connecting")) }
    }
    if (listing) BottomSheet(onDismiss = { listing = false }, dark = true) {
        Text(t("in_call_list"), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
        val meU = Repo.me
        listOf(Triple(Repo.uid ?: "", t("you"), meU?.photo ?: ""), Triple(m.peer, m.peerName, m.peerPhoto)).forEach { (id, name, photo) ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(name.ifBlank { "?" }, photo, id, 42.dp)
                Spacer(Modifier.width(12.dp))
                Text(name, color = Color.White, fontSize = 15.5.sp, modifier = Modifier.weight(1f))
                if (id == Repo.uid && m.muted) Ic("mic_off", Red, 20.dp)
            }
        }
    }
    if (adding) AddToCallDialog(listOf(m.peer), onCancel = { adding = false }) { list ->
        adding = false
        m.handOver(ctx, list)
        leave()
    }
}

/** What the small floating window shows during a one-to-one call. */
@Composable
fun OnePipContent(now: Long) {
    val m = CallManager
    val remote = m.remoteVideo
    Box(Modifier.fillMaxSize().background(CallBg), contentAlignment = Alignment.Center) {
        if (m.video && remote != null && m.phase == CallPhase.Active) {
            key(remote, "pip") { VideoView(remote, mirror = false, overlay = false, modifier = Modifier.fillMaxSize()) }
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Avatar(m.peerName.ifBlank { "?" }, m.peerPhoto, m.peer, 56.dp)
                Spacer(Modifier.height(6.dp))
                Text(m.peerName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
        Text(statusText(m.phase, now), color = Color.White, fontSize = 11.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(6.dp).clip(RoundedCornerShape(8.dp))
                .background(Color.Black.copy(alpha = .45f)).padding(horizontal = 6.dp, vertical = 2.dp))
    }
}

private fun statusText(ph: CallPhase, now: Long): String = when (ph) {
    CallPhase.Outgoing -> t("calling")
    CallPhase.Incoming -> t(if (CallManager.video) "in_video" else "in_audio")
    CallPhase.Connecting -> t("connecting")
    CallPhase.Active -> callClock(CallManager.startedAt, now)
    CallPhase.Ended -> t(when (CallManager.endReason) {
        "declined" -> "c_declined"; "busy" -> "c_busy"; "noanswer" -> "c_noanswer"; "failed" -> "c_failed"
        "missed" -> "missed_call"; else -> "c_ended"
    })
    CallPhase.Idle -> ""
}

@Composable
private fun VideoView(track: VideoTrack, mirror: Boolean, overlay: Boolean, modifier: Modifier) {
    val holder = remember { arrayOfNulls<SurfaceViewRenderer>(1) }
    AndroidView(
        factory = { c ->
            SurfaceViewRenderer(c).apply {
                init(CallManager.egl.eglBaseContext, null)
                setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                setEnableHardwareScaler(true)
                setMirror(mirror)
                if (overlay) setZOrderMediaOverlay(true)
                holder[0] = this
                try { track.addSink(this) } catch (_: Exception) {}
            }
        },
        update = { it.setMirror(mirror) },
        modifier = modifier,
    )
    DisposableEffect(track) {
        onDispose {
            val r = holder[0]
            if (r != null) {
                try { track.removeSink(r) } catch (_: Exception) {}
                try { r.release() } catch (_: Exception) {}
            }
        }
    }
}
