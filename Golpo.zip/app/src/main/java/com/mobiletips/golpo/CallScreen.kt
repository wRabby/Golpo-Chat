package com.mobiletips.golpo

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

class CallActivity : ComponentActivity() {
    private val answerNow = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()
        answerNow.value = intent?.action == "answer"
        if (!CallManager.busy) { finish(); return }
        setContent { CallUi(answerNow) { finish() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == "answer") answerNow.value = true
    }
}

@Composable
private fun CallUi(answerNow: MutableState<Boolean>, close: () -> Unit) {
    val ctx = LocalContext.current
    val m = CallManager
    val ph = m.phase
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    LaunchedEffect(ph) {
        if (ph == CallPhase.Idle) close()
        if (ph == CallPhase.Ended) { delay(1400); close() }
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val mic = r[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (mic) m.accept() else Toast.makeText(ctx, t("mic_need_call"), Toast.LENGTH_LONG).show()
    }
    fun accept() {
        val p = if (m.video) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA) else arrayOf(Manifest.permission.RECORD_AUDIO)
        perm.launch(p)
    }
    LaunchedEffect(answerNow.value) {
        if (answerNow.value && m.phase == CallPhase.Incoming) { answerNow.value = false; accept() }
    }

    val remote = m.remoteVideo
    val local = m.localVideo
    val showRemote = m.video && remote != null && ph == CallPhase.Active
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1D1640), Color(0xFF2B1F6B), Color(0xFF0F3B3A))))) {
        if (showRemote && remote != null) {
            key(remote) { VideoView(remote, mirror = false, overlay = false, modifier = Modifier.fillMaxSize()) }
        }
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(if (showRemote) 16.dp else 70.dp))
            if (!showRemote) {
                Avatar(m.peerName.ifBlank { "?" }, m.peerPhoto, m.peer, 124.dp)
                Spacer(Modifier.height(18.dp))
            }
            Text(m.peerName.ifBlank { "Golpo Chat" }, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(6.dp))
            Text(statusText(ph, now), color = Color.White.copy(alpha = .8f), fontSize = 15.sp)
            Spacer(Modifier.weight(1f))
            if (ph == CallPhase.Incoming) {
                Row(Modifier.fillMaxWidth().padding(bottom = 50.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    RoundBtn("call_end", Red, t("decline"), 72.dp) { m.decline() }
                    RoundBtn(if (m.video) "video" else "call", Green, t("accept"), 72.dp) { accept() }
                }
            } else if (ph != CallPhase.Ended) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Toggle(if (m.muted) "mic_off" else "mic", m.muted, t("mute")) { m.toggleMute() }
                    Toggle("volume", m.speaker, t("speaker")) { m.toggleSpeaker() }
                    if (m.video) {
                        Toggle(if (m.camOn) "video" else "video_off", !m.camOn, t("camera")) { m.toggleCam() }
                        Toggle("flip", false, t("flip")) { m.flipCam() }
                    }
                }
                Spacer(Modifier.height(26.dp))
                RoundBtn("call_end", Red, t("end"), 70.dp) { m.hangup() }
                Spacer(Modifier.height(40.dp))
            } else {
                Spacer(Modifier.height(140.dp))
            }
        }
        if (m.video && local != null && m.camOn && ph != CallPhase.Ended) {
            key(local) {
                VideoView(local, mirror = m.front, overlay = true,
                    modifier = Modifier.windowInsetsPadding(WindowInsets.safeDrawing).padding(14.dp).align(Alignment.TopEnd)
                        .size(width = 104.dp, height = 150.dp).clip(RoundedCornerShape(16.dp)))
            }
        }
    }
}

private fun statusText(ph: CallPhase, now: Long): String = when (ph) {
    CallPhase.Outgoing -> t("calling")
    CallPhase.Incoming -> t(if (CallManager.video) "in_video" else "in_audio")
    CallPhase.Connecting -> t("connecting")
    CallPhase.Active -> {
        val s = ((now - CallManager.startedAt) / 1000).coerceAtLeast(0)
        val txt = if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s / 60 % 60, s % 60) else "%02d:%02d".format(s / 60, s % 60)
        num(txt)
    }
    CallPhase.Ended -> t(when (CallManager.endReason) {
        "declined" -> "c_declined"; "busy" -> "c_busy"; "noanswer" -> "c_noanswer"; "failed" -> "c_failed"
        "missed" -> "missed_call"; else -> "c_ended"
    })
    CallPhase.Idle -> ""
}

@Composable
private fun RoundBtn(icon: String, color: Color, label: String, size: Dp, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(size).clip(CircleShape).background(color).clickable { onClick() }, contentAlignment = Alignment.Center) {
            Ic(icon, Color.White, size * 0.45f)
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
private fun Toggle(icon: String, on: Boolean, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp)) {
        Box(
            Modifier.size(58.dp).clip(CircleShape).background(if (on) Color.White else Color.White.copy(alpha = .16f)).clickable { onClick() },
            contentAlignment = Alignment.Center
        ) { Ic(icon, if (on) Color(0xFF1D1640) else Color.White, 26.dp) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
private fun VideoView(track: VideoTrack, mirror: Boolean, overlay: Boolean, modifier: Modifier) {
    val holder = remember { arrayOfNulls<SurfaceViewRenderer>(1) }
    AndroidView(
        factory = { c ->
            SurfaceViewRenderer(c).apply {
                init(CallManager.egl.eglBaseContext, null)
                setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                setEnableHardwareScaler(true)
                setMirror(mirror)
                if (overlay) setZOrderMediaOverlay(true)
                holder[0] = this
                try { track.addSink(this) } catch (_: Exception) {}
            }
        },
        update = { it.setMirror(mirror) },
        modifier = modifier,
    )
    DisposableEffect(track) {
        onDispose {
            val r = holder[0]
            if (r != null) {
                try { track.removeSink(r) } catch (_: Exception) {}
                try { r.release() } catch (_: Exception) {}
            }
        }
    }
}
