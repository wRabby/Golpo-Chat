#!/usr/bin/env python3
"""Golpo Chat server.

Jobs:
  * login codes (OTP): makes a 6-digit code and hands it to the SMS Sender phone
  * SMS Sender phone: long-polls /api/sender/poll and sends the SMS from its SIM
  * after the code is right: gives the app a Firebase login token
  * photos / voice messages: stored in ./media
  * new-message notifications: Firebase Cloud Messaging

First start creates config.json (keys). Open  http://SERVER-IP:8090/setup?key=ADMIN_KEY
in a browser once and upload the Firebase service-account file.
"""
import asyncio
import base64
import collections
import functools
import hashlib
import hmac
import html
import json
import os
import re
import secrets
import time
import uuid
from urllib.parse import urlparse

from aiohttp import web

BASE = os.path.dirname(os.path.abspath(__file__))
CFG_PATH = os.path.join(BASE, "config.json")
SA_PATH = os.path.join(BASE, "service-account.json")
MEDIA = os.path.join(BASE, "media")
os.makedirs(MEDIA, exist_ok=True)


def load_cfg():
    cfg = {}
    if os.path.exists(CFG_PATH):
        with open(CFG_PATH) as f:
            cfg = json.load(f)
    changed = False
    for k, v in (("port", 8090), ("public_url", ""), ("test_numbers", {}),
                 ("sender_key", None), ("admin_key", None), ("turn_secret", None)):
        if k not in cfg:
            cfg[k] = v if v is not None else secrets.token_urlsafe(12)
            changed = True
    if changed:
        save_cfg(cfg)
    return cfg


def save_cfg(cfg):
    with open(CFG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)
    os.chmod(CFG_PATH, 0o600)


cfg = load_cfg()

async def to_thread(fn, *args):
    """asyncio.to_thread for Python 3.8 too."""
    return await asyncio.get_running_loop().run_in_executor(None, functools.partial(fn, *args))


# ---------------------------------------------------------------- Firebase
fb = {"ready": False, "error": "service-account.json not uploaded yet", "db": None}


def init_firebase():
    try:
        import firebase_admin
        from firebase_admin import credentials, firestore
        if not firebase_admin._apps:
            firebase_admin.initialize_app(credentials.Certificate(SA_PATH))
        fb["db"] = firestore.client()
        fb["ready"] = True
        fb["error"] = ""
        publish_url()
        print("Firebase ready", flush=True)
    except Exception as e:  # noqa
        fb["ready"] = False
        fb["error"] = str(e)
        print("Firebase error:", e, flush=True)


def publish_url():
    """The app reads the server address from Firestore config/app, so a new IP needs no new APK."""
    if fb["ready"] and cfg.get("public_url"):
        fb["db"].collection("config").document("app").set({"server": cfg["public_url"]}, merge=True)


# ---------------------------------------------------------------- OTP state
codes = {}                                   # phone -> {code, exp, tries}
sends = collections.defaultdict(list)        # phone -> [time, ...]
ip_sends = collections.defaultdict(list)     # ip -> [time, ...]
jobs = []                                    # SMS waiting for the Sender phone
job_event = None                             # made at startup (Python 3.8 safe)
log = collections.deque(maxlen=60)           # shown on the admin page
sender = {"seen": 0.0, "sent": 0, "failed": 0}

PHONE_RE = re.compile(r"^01[3-9]\d{8}$")
HASH_RE = re.compile(r"^[A-Za-z0-9+/]{11}$")


def norm_phone(p):
    d = re.sub(r"\D", "", str(p or ""))
    if d.startswith("880"):
        d = "0" + d[3:]
    elif d.startswith("88"):
        d = d[2:]
    if len(d) == 10 and d.startswith("1"):
        d = "0" + d
    return d if PHONE_RE.match(d) else ""


def client_ip(request):
    return request.headers.get("X-Forwarded-For", request.remote or "?").split(",")[0].strip()


def err(msg, status=400, **extra):
    return web.json_response({"error": msg, **extra}, status=status)


async def otp_send(request):
    try:
        data = await request.json()
    except Exception:
        return err("bad_request")
    phone = norm_phone(data.get("phone"))
    if not phone:
        return err("bad_number")
    app_hash = str(data.get("hash") or "")
    if not HASH_RE.match(app_hash):
        app_hash = ""
    now = time.time()
    test = cfg.get("test_numbers", {}).get(phone)
    if not test:
        recent = [t for t in sends[phone] if now - t < 86400]
        sends[phone] = recent
        if recent and now - recent[-1] < 60:
            return err("wait", 429, wait=int(60 - (now - recent[-1])))
        if len(recent) >= 5:
            return err("limit", 429)
        ip = client_ip(request)
        ip_sends[ip] = [t for t in ip_sends[ip] if now - t < 86400]
        if len(ip_sends[ip]) >= 20:
            return err("limit", 429)
        ip_sends[ip].append(now)
        sends[phone].append(now)
    code = str(test) if test else f"{secrets.randbelow(10 ** 6):06d}"
    codes[phone] = {"code": code, "exp": now + 300, "tries": 0}
    entry = {"t": now, "phone": phone, "code": code, "status": "test" if test else "queued"}
    log.appendleft(entry)
    if not test:
        text = f"Your Golpo Chat code is {code}. Do not share it."
        if app_hash:
            text += f"\n\n{app_hash}"
        jobs.append({"id": uuid.uuid4().hex[:12], "to": phone, "text": text, "t": now, "entry": entry})
        job_event.set()
    online = now - sender["seen"] < 90
    return web.json_response({"ok": True, "sender": "online" if online else "offline"})


async def otp_verify(request):
    try:
        data = await request.json()
    except Exception:
        return err("bad_request")
    phone = norm_phone(data.get("phone"))
    code = re.sub(r"\D", "", str(data.get("code") or ""))
    item = codes.get(phone)
    if not item:
        return err("expired")
    if time.time() > item["exp"]:
        codes.pop(phone, None)
        return err("expired")
    if item["tries"] >= 5:
        return err("too_many", 429)
    if not secrets.compare_digest(item["code"], code):
        item["tries"] += 1
        return err("wrong_code")
    if not fb["ready"]:
        return err("server_not_ready", 503)
    codes.pop(phone, None)
    from firebase_admin import auth
    uid = "u88" + phone
    token = await to_thread(auth.create_custom_token, uid, {"phone": phone})
    if isinstance(token, bytes):
        token = token.decode()
    return web.json_response({"token": token, "uid": uid, "phone": phone})


# ---------------------------------------------------------------- SMS Sender phone
def sender_ok(key):
    return bool(key) and secrets.compare_digest(str(key), cfg["sender_key"])


async def sender_poll(request):
    if not sender_ok(request.query.get("key")):
        return err("bad_key", 403)
    sender["seen"] = time.time()
    if not jobs:
        job_event.clear()
        try:
            await asyncio.wait_for(job_event.wait(), 25)
        except asyncio.TimeoutError:
            pass
    sender["seen"] = time.time()
    now = time.time()
    out = []
    while jobs:
        j = jobs.pop(0)
        if now - j["t"] > 300:
            j["entry"]["status"] = "expired"
            continue
        j["entry"]["status"] = "sending"
        out.append({"id": j["id"], "to": j["to"], "text": j["text"]})
        pending[j["id"]] = j["entry"]
    return web.json_response({"jobs": out})


pending = {}


async def sender_done(request):
    try:
        data = await request.json()
    except Exception:
        return err("bad_request")
    if not sender_ok(data.get("key")):
        return err("bad_key", 403)
    entry = pending.pop(str(data.get("id")), None)
    ok = bool(data.get("ok"))
    if ok:
        sender["sent"] += 1
    else:
        sender["failed"] += 1
    if entry:
        entry["status"] = "sent" if ok else "failed: " + str(data.get("error") or "")[:80]
    return web.json_response({"ok": True})


# ---------------------------------------------------------------- media
async def user_from(request):
    hdr = request.headers.get("Authorization", "")
    if not hdr.startswith("Bearer ") or not fb["ready"]:
        raise web.HTTPUnauthorized()
    from firebase_admin import auth
    try:
        dec = await to_thread(auth.verify_id_token, hdr[7:])
    except Exception:
        raise web.HTTPUnauthorized()
    return dec["uid"]


KINDS = {"img": "jpg", "avatar": "jpg", "voice": "m4a"}


async def upload(request):
    await user_from(request)
    kind = request.query.get("kind", "img")
    if kind not in KINDS:
        return err("bad_kind")
    body = await request.read()
    if not body or len(body) > 15 * 1024 * 1024:
        return err("bad_size")
    name = f"{kind}_{uuid.uuid4().hex}.{KINDS[kind]}"
    await to_thread(_write, os.path.join(MEDIA, name), body)
    base = cfg.get("public_url") or f"http://{request.host}"
    return web.json_response({"url": f"{base}/m/{name}"})


def _write(path, body):
    with open(path, "wb") as f:
        f.write(body)


NAME_RE = re.compile(r"^[a-z]+_[0-9a-f]{32}\.(jpg|m4a)$")


async def media(request):
    name = request.match_info["name"]
    path = os.path.join(MEDIA, name)
    if not NAME_RE.match(name) or not os.path.exists(path):
        raise web.HTTPNotFound()
    return web.FileResponse(path, headers={"Cache-Control": "public, max-age=31536000"})


# ---------------------------------------------------------------- notifications
pushst = {"sent": 0, "failed": 0, "notoken": 0, "error": ""}


def _send_fcm(tok, data, ttl):
    from firebase_admin import messaging
    try:
        messaging.send(messaging.Message(token=tok, data=data,
                                         android=messaging.AndroidConfig(priority="high", ttl=ttl)))
        pushst["sent"] += 1
    except Exception as e:  # noqa
        pushst["failed"] += 1
        pushst["error"] = time.strftime("%d/%m %H:%M ") + str(e)[:300]
        print("push failed:", e, flush=True)


def _push(uid, chat_id, mid):
    from firebase_admin import messaging
    db = fb["db"]
    cref = db.collection("chats").document(chat_id)
    chat = cref.get()
    if not chat.exists:
        return 404
    members = chat.to_dict().get("members", [])
    if uid not in members:
        return 403
    msg = cref.collection("messages").document(mid).get()
    if not msg.exists:
        return 404
    m = msg.to_dict()
    me = db.collection("users").document(uid).get().to_dict() or {}
    kind = m.get("kind", "t")
    body = m.get("text", "") if kind == "t" else ("📷 Photo" if kind == "img" else "🎤 Voice message")
    for other in members:
        if other == uid:
            continue
        u = db.collection("users").document(other).get().to_dict() or {}
        tok = u.get("fcm")
        if not tok:
            pushst["notoken"] += 1
            continue
        _send_fcm(tok, {"type": "msg", "chat": chat_id, "mid": mid, "from": uid,
                        "name": me.get("name", "") or me.get("phone", ""), "body": body[:300],
                        "photo": me.get("photo", "")}, 86400)
    return 200


async def push(request):
    uid = await user_from(request)
    try:
        data = await request.json()
    except Exception:
        return err("bad_request")
    chat_id, mid = str(data.get("chat", "")), str(data.get("mid", ""))
    if not chat_id or not mid or "/" in chat_id + mid:
        return err("bad_request")
    code = await to_thread(_push, uid, chat_id, mid)
    return web.json_response({"ok": code == 200}, status=code)


# ---------------------------------------------------------------- calls
def _call_push(uid, call_id, action):
    from firebase_admin import messaging
    db = fb["db"]
    c = db.collection("calls").document(call_id).get()
    if not c.exists:
        return 404
    d = c.to_dict()
    if d.get("from") != uid:
        return 403
    to = d.get("to", "")
    u = db.collection("users").document(to).get().to_dict() or {}
    tok = u.get("fcm")
    if not tok:
        pushst["notoken"] += 1
        return 200
    me = db.collection("users").document(uid).get().to_dict() or {}
    data = {"type": "call" if action == "ring" else "call_end", "call": call_id, "from": uid,
            "name": me.get("name", "") or me.get("phone", ""), "photo": me.get("photo", ""),
            "video": "1" if d.get("video") else "0", "t": str(int(time.time() * 1000))}
    _send_fcm(tok, data, 60)
    return 200


async def call_push(request):
    uid = await user_from(request)
    try:
        data = await request.json()
    except Exception:
        return err("bad_request")
    call_id = str(data.get("call", ""))
    action = str(data.get("action", "ring"))
    if not call_id or "/" in call_id or action not in ("ring", "end"):
        return err("bad_request")
    code = await to_thread(_call_push, uid, call_id, action)
    return web.json_response({"ok": code == 200}, status=code)


def turn_host(request=None):
    h = urlparse(cfg.get("public_url") or "").hostname
    if not h and request is not None:
        h = request.host.split(":")[0]
    return h or ""


async def ice(request):
    uid = await user_from(request)
    host = turn_host(request)
    user = "%d:%s" % (int(time.time()) + 6 * 3600, uid)
    cred = base64.b64encode(hmac.new(cfg["turn_secret"].encode(), user.encode(), hashlib.sha1).digest()).decode()
    return web.json_response({"ice": [
        {"urls": ["stun:%s:3478" % host]},
        {"urls": ["turn:%s:3478?transport=udp" % host, "turn:%s:3478?transport=tcp" % host],
         "username": user, "credential": cred},
    ]})


def write_turn_conf():
    """Writes turnserver.conf next to this file; copy it to /etc/turnserver.conf (see the guide)."""
    conf = "\n".join([
        "listening-port=3478",
        "fingerprint",
        "use-auth-secret",
        "static-auth-secret=" + cfg["turn_secret"],
        "realm=golpo.chat",
        "total-quota=200",
        "stale-nonce=600",
        "min-port=49160",
        "max-port=49400",
        "no-tls",
        "no-dtls",
        "no-cli",
        "no-multicast-peers",
        "denied-peer-ip=0.0.0.0-0.255.255.255",
        "denied-peer-ip=10.0.0.0-10.255.255.255",
        "denied-peer-ip=127.0.0.0-127.255.255.255",
        "denied-peer-ip=172.16.0.0-172.31.255.255",
        "denied-peer-ip=192.168.0.0-192.168.255.255",
        "log-file=/var/log/turnserver.log",
        "",
    ])
    path = os.path.join(BASE, "turnserver.conf")
    with open(path, "w") as f:
        f.write(conf)
    os.chmod(path, 0o644)


# ---------------------------------------------------------------- setup & admin pages
def admin_ok(request):
    k = request.query.get("key", "")
    return bool(k) and secrets.compare_digest(k, cfg["admin_key"])


PAGE = """<!doctype html><html><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">{refresh}<title>Golpo Chat server</title>
<style>body{{font-family:system-ui,sans-serif;margin:0;background:#f4f2fb;color:#17142a}}
.w{{max-width:640px;margin:auto;padding:18px}}h1{{color:#6c4df6;font-size:22px}}
.c{{background:#fff;border-radius:16px;padding:16px;margin:12px 0;box-shadow:0 2px 8px #0001}}
.ok{{color:#1b9e55;font-weight:700}}.bad{{color:#e0344f;font-weight:700}}
button,input[type=submit]{{background:#6c4df6;color:#fff;border:0;border-radius:12px;padding:12px 18px;font-size:16px}}
input[type=text]{{width:100%;padding:10px;border:1px solid #ddd;border-radius:10px;font-size:15px;box-sizing:border-box}}
table{{width:100%;border-collapse:collapse;font-size:14px}}td,th{{padding:6px;border-bottom:1px solid #eee;text-align:left}}</style>
</head><body><div class=w><h1>Golpo Chat server</h1>{body}</div></body></html>"""


async def setup_get(request):
    if not admin_ok(request):
        raise web.HTTPForbidden(text="Wrong key")
    url = cfg.get("public_url") or f"http://{request.host}"
    st = "<span class=ok>✓ Firebase connected</span>" if fb["ready"] else f"<span class=bad>✗ {html.escape(fb['error'])}</span>"
    body = f"""<div class=c>{st}</div>
<div class=c><form method=post enctype=multipart/form-data>
<p><b>1.</b> Firebase service-account file (.json):</p><input type=file name=sa accept=".json,application/json">
<p><b>2.</b> Server address (the app uses this):</p><input type=text name=url value="{html.escape(url)}">
<p><input type=submit value="Save"></p></form></div>
<div class=c>Admin page: <a href="/admin?key={html.escape(cfg['admin_key'])}">open</a></div>"""
    return web.Response(text=PAGE.format(body=body, refresh=""), content_type="text/html")


async def setup_post(request):
    if not admin_ok(request):
        raise web.HTTPForbidden(text="Wrong key")
    form = await request.post()
    f = form.get("sa")
    msg = []
    if f is not None and getattr(f, "file", None):
        raw = f.file.read()
        try:
            sa = json.loads(raw)
            assert sa.get("type") == "service_account" and sa.get("project_id")
        except Exception:
            return web.Response(text=PAGE.format(body="<div class=c><span class=bad>That is not a Firebase service-account file.</span></div>", refresh=""), content_type="text/html")
        with open(SA_PATH, "wb") as out:
            out.write(raw)
        os.chmod(SA_PATH, 0o600)
        msg.append("service-account saved")
    url = str(form.get("url") or "").strip().rstrip("/")
    if url.startswith("http"):
        cfg["public_url"] = url
        save_cfg(cfg)
        msg.append("address saved")
    if os.path.exists(SA_PATH):
        await to_thread(init_firebase)
    raise web.HTTPFound(f"/setup?key={cfg['admin_key']}")


def _reports():
    out = []
    try:
        from firebase_admin import firestore
        q = fb["db"].collection("reports").order_by("at", direction=firestore.Query.DESCENDING).limit(30)
        for d in q.stream():
            r = d.to_dict()
            at = r.get("at")
            def ph(uid):
                return "0" + uid[4:] if uid.startswith("u880") else uid
            out.append({"t": at.strftime("%d/%m %H:%M") if at else "", "from": ph(r.get("from", "")),
                        "about": ph(r.get("about", "")), "reason": str(r.get("reason", ""))[:80]})
    except Exception as e:  # noqa
        print("reports:", e, flush=True)
    return out


async def admin(request):
    if not admin_ok(request):
        raise web.HTTPForbidden(text="Wrong key")
    now = time.time()
    seen = now - sender["seen"]
    sst = f"<span class=ok>✓ online</span>" if seen < 90 else f"<span class=bad>✗ offline</span>"
    rows = "".join(
        f"<tr><td>{time.strftime('%d/%m %H:%M', time.localtime(e['t']))}</td><td>{e['phone']}</td><td><b>{e['code']}</b></td><td>{html.escape(e['status'])}</td></tr>"
        for e in log)
    fbst = "<span class=ok>✓ connected</span>" if fb["ready"] else f"<span class=bad>✗ {html.escape(fb['error'])}</span>"
    reps = await to_thread(_reports) if fb["ready"] else []
    rrows = "".join(
        f"<tr><td>{html.escape(r['t'])}</td><td>{html.escape(r['from'])}</td><td>{html.escape(r['about'])}</td><td>{html.escape(r['reason'])}</td></tr>"
        for r in reps)
    body = f"""<div class=c>Firebase: {fbst}<br>Server address: {html.escape(cfg.get('public_url') or '(not set)')}</div>
<div class=c>Notifications: sent {pushst['sent']} · failed {pushst['failed']} · no token {pushst['notoken']}<br><small>{html.escape(pushst['error'] or 'no errors')}</small></div>
<div class=c>SMS Sender phone: {sst}<br>Sent: {sender['sent']} · Failed: {sender['failed']} · Waiting: {len(jobs)}</div>
<div class=c><b>Reports</b><table><tr><th>Time</th><th>From</th><th>About</th><th>Reason</th></tr>{rrows or '<tr><td colspan=4>None</td></tr>'}</table></div>
<div class=c><b>Recent login codes</b><table><tr><th>Time</th><th>Number</th><th>Code</th><th>Status</th></tr>{rows or '<tr><td colspan=4>None yet</td></tr>'}</table></div>"""
    return web.Response(text=PAGE.format(body=body, refresh='<meta http-equiv=refresh content=10>'), content_type="text/html")


async def home(request):
    return web.Response(text="Golpo Chat server OK")


def make_app():
    app = web.Application(client_max_size=20 * 1024 * 1024)

    async def startup(_app):
        global job_event
        job_event = asyncio.Event()
    app.on_startup.append(startup)
    app.add_routes([
        web.get("/", home),
        web.post("/api/otp/send", otp_send),
        web.post("/api/otp/verify", otp_verify),
        web.get("/api/sender/poll", sender_poll),
        web.post("/api/sender/done", sender_done),
        web.post("/api/upload", upload),
        web.post("/api/push", push),
        web.post("/api/call", call_push),
        web.post("/api/ice", ice),
        web.get("/m/{name}", media),
        web.get("/setup", setup_get),
        web.post("/setup", setup_post),
        web.get("/admin", admin),
    ])
    return app


if __name__ == "__main__":
    write_turn_conf()
    if os.path.exists(SA_PATH):
        init_firebase()
    print("=" * 60)
    print("Golpo Chat server on port", cfg["port"])
    print("Setup page : http://YOUR-SERVER-IP:%s/setup?key=%s" % (cfg["port"], cfg["admin_key"]))
    print("Sender key :", cfg["sender_key"])
    print("=" * 60, flush=True)
    web.run_app(make_app(), port=int(cfg["port"]), print=None)
