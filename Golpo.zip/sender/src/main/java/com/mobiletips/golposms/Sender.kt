package com.mobiletips.golposms

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.telephony.SmsManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Golpo SMS Sender: keeps asking the Golpo server for login codes and sends them as SMS from this phone's SIM.
 * Installed only on the owner's spare phone (not on Play Store).
 */
object State {
    var running by mutableStateOf(false)
    var status by mutableStateOf("Stopped")
    val log = mutableStateListOf<String>()
    fun add(s: String) {
        log.add(0, SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date()) + "  " + s)
        while (log.size > 80) log.removeAt(log.lastIndex)
    }
}

fun prefs(c: Context) = c.getSharedPreferences("sender", Context.MODE_PRIVATE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = prefs(this)
        setContent {
            var url by remember { mutableStateOf(p.getString("url", "http://") ?: "http://") }
            var key by remember { mutableStateOf(p.getString("key", "") ?: "") }
            val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
                if (r[Manifest.permission.SEND_SMS] == true) startSender(url, key) else State.add("SMS permission was not given")
            }
            Column(Modifier.fillMaxSize().background(Color(0xFFF4F2FB)).safeDrawingPadding().padding(16.dp)) {
                Text("Golpo SMS Sender", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF6C4DF6))
                Text("Keep this phone charged and on the internet. It sends Golpo Chat login codes from its SIM.",
                    fontSize = 13.sp, color = Color(0xFF6E6A85))
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(url, { url = it.trim() }, label = { Text("Server address (http://IP:8090)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(key, { key = it.trim() }, label = { Text("Sender key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!State.running) {
                        Button(onClick = {
                            p.edit().putString("url", url.trimEnd('/')).putString("key", key).apply()
                            val need = mutableListOf(Manifest.permission.SEND_SMS)
                            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
                            perms.launch(need.toTypedArray())
                        }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C4DF6))) { Text("▶  Start") }
                    } else {
                        Button(onClick = { stopService(Intent(this@MainActivity, SenderService::class.java)); p.edit().putBoolean("on", false).apply() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF3B5C))) { Text("■  Stop") }
                    }
                    Button(onClick = { askBattery() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C9A5))) { Text("🔋 Always on") }
                }
                Spacer(Modifier.height(12.dp))
                Text("Status: " + State.status, fontWeight = FontWeight.Bold,
                    color = if (State.running) Color(0xFF1B9E55) else Color(0xFFE0344F),
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(Color.White).padding(10.dp).fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                LazyColumn(Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)).background(Color.White).padding(10.dp)) {
                    items(State.log) { Text(it, fontSize = 12.sp, modifier = Modifier.padding(vertical = 3.dp)) }
                }
            }
        }
    }

    private fun startSender(url: String, key: String) {
        if (!url.startsWith("http") || key.isBlank()) { State.add("Fill in the server address and key"); return }
        prefs(this).edit().putBoolean("on", true).apply()
        ContextCompat.startForegroundService(this, Intent(this, SenderService::class.java))
    }

    @SuppressLint("BatteryLife")
    private fun askBattery() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
}

class SenderService : Service() {
    @Volatile private var alive = false
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundNow("Waiting for login codes…")
        if (!alive) {
            alive = true
            State.running = true
            wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "golpo:sender").apply { acquire() }
            Thread { loop() }.start()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        alive = false
        State.running = false
        State.status = "Stopped"
        try { wake?.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun startForegroundNow(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel("sender") == null) {
            nm.createNotificationChannel(NotificationChannel("sender", "SMS Sender", NotificationManager.IMPORTANCE_LOW))
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = NotificationCompat.Builder(this, "sender")
            .setSmallIcon(android.R.drawable.sym_action_chat)
            .setContentTitle("Golpo SMS Sender is on")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, n, type)
    }

    private fun loop() {
        val p = prefs(this)
        val base = (p.getString("url", "") ?: "").trimEnd('/')
        val key = p.getString("key", "") ?: ""
        State.add("Started → $base")
        State.status = "Running · connecting…"
        var fails = 0
        while (alive) {
            try {
                if (fails == 0 && !State.status.startsWith("Wrong")) State.status = "Running · waiting for codes"
                val res = http("$base/api/sender/poll?key=" + URLEncoder.encode(key, "UTF-8"), null)
                if (res.optString("error") == "bad_key") {
                    State.status = "Wrong sender key"; State.add("Wrong sender key — check it"); Thread.sleep(30000); continue
                }
                State.status = "Running · waiting for codes"
                fails = 0
                val jobs = res.optJSONArray("jobs") ?: continue
                for (i in 0 until jobs.length()) {
                    val j = jobs.getJSONObject(i)
                    val to = j.getString("to")
                    val (ok, err) = sendSms(to, j.getString("text"))
                    State.add(if (ok) "Sent code to $to" else "FAILED $to: $err")
                    try {
                        http("$base/api/sender/done", JSONObject().put("key", key).put("id", j.getString("id")).put("ok", ok).put("error", err))
                    } catch (_: Exception) {}
                }
            } catch (e: Exception) {
                fails++
                State.status = "Cannot reach server (retrying)"
                if (fails == 1 || fails % 20 == 0) State.add("Server not reachable: ${e.javaClass.simpleName}")
                try { Thread.sleep(5000) } catch (_: Exception) {}
            }
        }
    }

    private fun sendSms(to: String, text: String): Pair<Boolean, String> {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return false to "no SMS permission"
        return try {
            val sms: SmsManager = if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java)
            else @Suppress("DEPRECATION") SmsManager.getDefault()
            val parts = sms.divideMessage(text)
            if (parts.size > 1) sms.sendMultipartTextMessage(to, null, parts, null, null)
            else sms.sendTextMessage(to, null, text, null, null)
            true to ""
        } catch (e: Exception) {
            false to (e.message ?: e.javaClass.simpleName)
        }
    }

    private fun http(url: String, body: JSONObject?): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 40000
            if (body != null) {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: "{}"
            return try { JSONObject(txt) } catch (_: Exception) { JSONObject() }
        } finally {
            c.disconnect()
        }
    }
}

/** Starts again by itself after the phone restarts. */
class Boot : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && prefs(c).getBoolean("on", false)) {
            try { ContextCompat.startForegroundService(c, Intent(c, SenderService::class.java)) } catch (_: Exception) {}
        }
    }
}
