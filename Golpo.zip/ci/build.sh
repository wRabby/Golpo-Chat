#!/usr/bin/env bash
# Build steps live here (inside the zip), so build.yml never needs editing again.
set -e
# Firebase settings: app/src/main/res/values/firebase.xml
mkdir -p dist

# 1) Golpo Chat APK + SMS Sender APK
set +e
gradle :app:assembleDebug :sender:assembleDebug --no-daemon --stacktrace > debug.log 2>&1
dcode=$?
set -e
cat debug.log
if [ $dcode -ne 0 ]; then
  reason=$(grep -E "^e: |What went wrong" -A3 debug.log | head -30 | tr '\n' ' ' | cut -c1-1500)
  echo "::error::APK build failed: ${reason:-see the Build step log}"
  exit 1
fi
cp app/build/outputs/apk/debug/app-debug.apk dist/Golpo-Chat.apk
cp sender/build/outputs/apk/debug/sender-debug.apk dist/Golpo-SMS-Sender.apk

# 2) server file for the VPS
cp server/golpo_server.py dist/golpo_server.py
cp firestore.rules dist/firestore.rules

# 3) Play Store bundle (.aab) — only when the UPLOAD_PASSWORD secret is set in GitHub
opens() { keytool -list -keystore app/upload.jks -storepass "$1" >/dev/null 2>&1; }
PW=$(printf '%s' "$UPLOAD_PASSWORD" | tr -d '[:space:]')
if [ -z "$PW" ] || ! opens "$PW"; then echo "No UPLOAD_PASSWORD secret yet - .aab skipped (APK is ready)."; exit 0; fi
export UPLOAD_PASSWORD="$PW"
set +e
gradle :app:bundleRelease --no-daemon --stacktrace > bundle.log 2>&1
code=$?
set -e
cat bundle.log
if [ $code -ne 0 ]; then
  reason=$(grep -A6 "What went wrong" bundle.log | tr '\n' ' ' | cut -c1-600)
  echo "::error::AAB build failed: ${reason:-see the Build step log}"
  exit 0
fi
cp app/build/outputs/bundle/release/app-release.aab dist/Golpo-Chat.aab
echo "Play Store bundle ready"
